const path = require('path');
const { app, BrowserWindow, Menu, shell } = require('electron');
const config = require('./config.json');
const { checkForUpdates } = require('./updater');

let mainWindow = null;

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: '#0D0B08',
    show: false,
    autoHideMenuBar: process.platform !== 'darwin',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'app', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });
};

const buildMenu = () => {
  const updateItem = {
    label: 'Проверить обновления…',
    click: () => checkForUpdates(config.releasesUrl, { silent: false }),
  };

  const template = [
    ...(process.platform === 'darwin'
      ? [{
          label: 'MBA',
          submenu: [
            { role: 'about', label: 'О программе MBA' },
            { type: 'separator' },
            updateItem,
            { type: 'separator' },
            { role: 'hide', label: 'Скрыть MBA' },
            { role: 'quit', label: 'Выйти' },
          ],
        }]
      : []),
    {
      label: 'Файл',
      submenu: [
        { role: 'reload', label: 'Обновить' },
        ...(process.platform === 'darwin' ? [] : [updateItem]),
        { type: 'separator' },
        { role: 'quit', label: 'Выход' },
      ],
    },
    {
      label: 'Правка',
      submenu: [
        { role: 'undo', label: 'Отменить' },
        { role: 'redo', label: 'Повторить' },
        { type: 'separator' },
        { role: 'cut', label: 'Вырезать' },
        { role: 'copy', label: 'Копировать' },
        { role: 'paste', label: 'Вставить' },
        { role: 'selectAll', label: 'Выделить всё' },
      ],
    },
    {
      label: 'Вид',
      submenu: [
        { role: 'zoomIn', label: 'Увеличить' },
        { role: 'zoomOut', label: 'Уменьшить' },
        { role: 'resetZoom', label: 'Обычный размер' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Во весь экран' },
      ],
    },
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
};

app.whenReady().then(() => {
  buildMenu();
  createWindow();
  setTimeout(() => checkForUpdates(config.releasesUrl, { silent: true }), 4000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
