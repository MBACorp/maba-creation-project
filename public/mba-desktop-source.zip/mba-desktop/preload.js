const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('MBA_DESKTOP', {
  isDesktop: true,
  platform: process.platform,
});
