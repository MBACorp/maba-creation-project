const https = require('https');
const { app, dialog, shell } = require('electron');

const versionKey = (version) => {
  const nums = (String(version || '').match(/\d+/g) || []).slice(0, 4).map(Number);
  while (nums.length < 4) nums.push(0);
  return nums;
};

const isNewer = (remote, local) => {
  const a = versionKey(remote);
  const b = versionKey(local);
  for (let i = 0; i < 4; i += 1) {
    if (a[i] > b[i]) return true;
    if (a[i] < b[i]) return false;
  }
  return false;
};

const fetchJson = (url) =>
  new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        let raw = '';
        res.on('data', (chunk) => { raw += chunk; });
        res.on('end', () => {
          try { resolve(JSON.parse(raw)); } catch (error) { reject(error); }
        });
      })
      .on('error', reject);
  });

const platformKey = () => (process.platform === 'darwin' ? 'macos' : 'windows');

async function checkForUpdates(releasesUrl, { silent = true } = {}) {
  try {
    const data = await fetchJson(releasesUrl);
    const latest = (data.latest || {})[platformKey()];

    if (!latest || !isNewer(latest.version, app.getVersion())) {
      if (!silent) {
        await dialog.showMessageBox({
          type: 'info',
          title: 'Обновления',
          message: 'У вас последняя версия',
          detail: 'Установлена версия ' + app.getVersion() + '.',
        });
      }
      return;
    }

    const result = await dialog.showMessageBox({
      type: 'info',
      buttons: ['Скачать обновление', 'Позже'],
      defaultId: 0,
      cancelId: 1,
      title: 'Доступно обновление',
      message: 'Вышла версия ' + latest.version,
      detail: latest.notes || 'Скачайте новый установщик и запустите его — данные сохранятся.',
    });

    if (result.response === 0) shell.openExternal(latest.fileUrl);
  } catch (error) {
    if (!silent) {
      await dialog.showMessageBox({
        type: 'error',
        title: 'Обновления',
        message: 'Не удалось проверить обновления',
        detail: String((error && error.message) || error),
      });
    }
  }
}

module.exports = { checkForUpdates };
