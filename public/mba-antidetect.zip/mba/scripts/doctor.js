#!/usr/bin/env node
/*
 * Диагностика: находит настоящую причину, по которой браузер закрывается.
 *
 * Скрипт запускает браузер напрямую, в обход приложения, и показывает
 * то, что обычно скрыто: проверку подписи macOS и сообщение самой системы
 * при запуске. Именно там лежит ответ, которого не видно в окне программы.
 */
const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const say = (m) => process.stdout.write(m + '\n');
const line = () => say('─'.repeat(58));

say('');
say('ДИАГНОСТИКА MBA');
line();

/* 1. Ищем ядро браузера */
const roots = [
  path.join(__dirname, '..', 'node_modules'),
  path.join(__dirname, '..', 'dist', 'mac-arm64', 'MBA.app', 'Contents', 'Resources', 'app.asar.unpacked', 'node_modules'),
  '/Applications/MBA.app/Contents/Resources/app.asar.unpacked/node_modules',
];

const found = [];

for (const root of roots) {
  const local = path.join(root, 'patchright-core', '.local-browsers');
  if (!fs.existsSync(local)) continue;

  for (const folder of fs.readdirSync(local).filter((n) => n.startsWith('chromium'))) {
    const candidates = [
      path.join(local, folder, 'chrome-mac-arm64', 'Google Chrome for Testing.app'),
      path.join(local, folder, 'chrome-mac', 'Google Chrome for Testing.app'),
      path.join(local, folder, 'chrome-mac', 'Chromium.app'),
    ];
    for (const app of candidates) {
      if (fs.existsSync(app)) found.push({ root, app });
    }
  }
}

if (!found.length) {
  say('Ядро браузера не найдено нигде.');
  say('Выполните: npm install');
  process.exit(1);
}

say('Найдено копий браузера: ' + found.length);
say('');

for (const { root, app } of found) {
  const where = root.includes('app.asar.unpacked') ? 'ВНУТРИ приложения' : 'в папке проекта';
  say('• ' + where);
  say('  ' + app);

  const bin = path.join(
    app,
    'Contents',
    'MacOS',
    path.basename(app, '.app')
  );

  say('  запускаемый файл: ' + (fs.existsSync(bin) ? 'на месте' : 'ОТСУТСТВУЕТ'));

  if (fs.existsSync(bin)) {
    try {
      const mode = fs.statSync(bin).mode;
      say('  права на запуск: ' + (mode & 0o111 ? 'есть' : 'НЕТ — это ошибка'));
    } catch (e) {
      say('  права прочитать не удалось');
    }
  }

  /* Проверка подписи — здесь чаще всего и кроется причина */
  try {
    execSync(`codesign --verify --deep --strict "${app}"`, { stdio: 'pipe' });
    say('  подпись: в порядке');
  } catch (e) {
    const msg = (e.stderr ? e.stderr.toString() : e.message).trim().split('\n')[0];
    say('  подпись: НАРУШЕНА → ' + msg);
  }

  /* Метка карантина */
  try {
    const attrs = execSync(`xattr "${app}"`, { stdio: 'pipe' }).toString();
    say('  карантин: ' + (attrs.includes('quarantine') ? 'ЕСТЬ — надо снять' : 'нет'));
  } catch (e) {
    say('  карантин: нет');
  }

  say('');
}

/* 2. Пробуем реально запустить */
line();
say('ПРОБНЫЙ ЗАПУСК');
say('');

const target = found.find((f) => f.root.includes('app.asar.unpacked')) || found[0];
const bin = path.join(target.app, 'Contents', 'MacOS', path.basename(target.app, '.app'));
const tmpProfile = path.join(require('os').tmpdir(), 'mba-doctor-' + Date.now());

say('Запускаю браузер напрямую…');

const res = spawnSync(
  bin,
  ['--headless=new', '--no-sandbox', '--disable-gpu', `--user-data-dir=${tmpProfile}`, '--dump-dom', 'about:blank'],
  { encoding: 'utf8', timeout: 30000 }
);

say('');
say('код завершения: ' + res.status);

if (res.error) say('ошибка запуска: ' + res.error.message);

const err = (res.stderr || '').trim();
const out = (res.stdout || '').trim();

if (err) {
  say('');
  say('сообщение системы:');
  err.split('\n').slice(0, 12).forEach((l) => say('  ' + l));
}

say('');
line();

if (res.status === 0 && out) {
  say('ИТОГ: браузер запускается нормально.');
  say('Значит, дело не в самом браузере, а в настройках профиля.');
} else {
  say('ИТОГ: браузер не стартует.');
  say('');
  if (/killed|Killed|signal/i.test(err + String(res.signal))) {
    say('Его закрывает macOS — проблема с подписью.');
    say('Выполните: npm run fix:mac');
  } else if (/dyld|library|Library not loaded/i.test(err)) {
    say('Повреждены внутренние файлы браузера.');
    say('Выполните: rm -rf node_modules && npm install');
  } else {
    say('Пришлите этот вывод целиком — разберём по сообщению выше.');
  }
}

say('');
try {
  fs.rmSync(tmpProfile, { recursive: true, force: true });
} catch (e) {
  /* временную папку могло не создаться — это не важно */
}
