#!/usr/bin/env node
/*
 * Готовит интерфейс к работе внутри настольного приложения.
 *
 * Причина: сборка для сайта ссылается на файлы от корня — "/assets/...".
 * Когда страница открывается не с сервера, а прямо с диска, такой путь
 * указывает в корень диска, файлы не находятся и окно остаётся чёрным.
 * Здесь пути переводятся в относительные и убираются внешние скрипты,
 * которые в приложении не нужны и только тормозят запуск.
 */
const fs = require('fs');
const path = require('path');

const indexFile = path.join(__dirname, '..', 'app', 'index.html');

if (!fs.existsSync(indexFile)) {
  console.error('Интерфейс не найден: app/index.html');
  process.exit(1);
}

let html = fs.readFileSync(indexFile, 'utf8');
const before = html;

html = html.replace(/(src|href)="\/(?!\/)/g, '$1="./');

html = html.replace(
  /\s*<script[^>]*src="https:\/\/cdn\.poehali\.dev\/[^"]*"[^>]*><\/script>/g,
  ''
);
html = html.replace(
  /\s*<script[^>]*src="https:\/\/mc\.yandex\.ru\/[^"]*"[^>]*><\/script>/g,
  ''
);
html = html.replace(/\s*<noscript>[\s\S]*?yandex[\s\S]*?<\/noscript>/gi, '');

if (html !== before) {
  fs.writeFileSync(indexFile, html);
  console.log('Интерфейс подготовлен: пути исправлены, лишние скрипты убраны');
} else {
  console.log('Интерфейс уже готов, изменений не потребовалось');
}
