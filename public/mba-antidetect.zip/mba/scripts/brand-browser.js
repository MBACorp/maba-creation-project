/*
 * Переименование встроенного браузера в MBA.
 *
 * Что меняем: только видимые пользователю названия внутри служебного
 * файла Info.plist — имя в доке, в меню и в переключателе программ.
 *
 * Чего НЕ трогаем: имена папок и файлов. Приложение ищет браузер по
 * точным путям вида «Google Chrome for Testing.app», и переименование
 * папки сломало бы запуск. Снаружи имя новое, внутри пути прежние.
 *
 * ВАЖНО про порядок. Правка Info.plist нарушает подпись браузера, и
 * тогда macOS закрывает его сразу после старта. Поэтому переименование
 * обязано выполняться ДО подписи — так и вызывается в fix-mac.js.
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const BRAND = 'MBA';

const sh = (cmd) => execSync(cmd, { stdio: 'pipe' }).toString();

/* Читаем значение ключа из Info.plist */
const readKey = (plist, key) => {
  try {
    return sh(`/usr/libexec/PlistBuddy -c "Print :${key}" "${plist}"`).trim();
  } catch (e) {
    return null;
  }
};

/* Записываем значение: если ключа нет — добавляем */
const writeKey = (plist, key, value) => {
  const escaped = String(value).replace(/"/g, '\\"');
  try {
    sh(`/usr/libexec/PlistBuddy -c "Set :${key} ${escaped}" "${plist}"`);
    return true;
  } catch (e) {
    try {
      sh(`/usr/libexec/PlistBuddy -c "Add :${key} string ${escaped}" "${plist}"`);
      return true;
    } catch (e2) {
      return false;
    }
  }
};

/*
 * Имя для вспомогательных процессов браузера. macOS показывает их
 * в мониторе системы, и если оставить старое имя — продукт выглядит
 * сшитым из чужих кусков.
 */
const helperName = (original) => {
  const suffix = String(original || '').match(/\(([^)]+)\)\s*$/);
  const kind = suffix ? ' (' + suffix[1] + ')' : '';
  return BRAND + ' Helper' + kind;
};

/* Собираем все вложенные приложения браузера: сам браузер и его помощники */
const collectApps = (browserApp) => {
  const apps = [browserApp];
  const frameworks = path.join(browserApp, 'Contents', 'Frameworks');

  const walk = (dir, depth) => {
    if (depth > 6) return;
    let items;
    try {
      items = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const it of items) {
      if (!it.isDirectory()) continue;
      const full = path.join(dir, it.name);
      if (it.name.endsWith('.app')) apps.push(full);
      walk(full, depth + 1);
    }
  };

  if (fs.existsSync(frameworks)) walk(frameworks, 0);
  return apps;
};

/*
 * Подменяем иконку браузера на логотип MBA.
 *
 * Имя файла иконки записано в Info.plist (ключ CFBundleIconFile).
 * Мы не переименовываем файлы внутри браузера, а кладём свой рядом
 * и переключаем ключ на него — так ничего не ломается, а вернуть
 * прежний вид можно одной правкой.
 */
function replaceIcon(browserApp, iconSource) {
  if (!iconSource || !fs.existsSync(iconSource)) return false;

  const resources = path.join(browserApp, 'Contents', 'Resources');
  if (!fs.existsSync(resources)) return false;

  const target = path.join(resources, 'mba.icns');
  fs.copyFileSync(iconSource, target);

  const plist = path.join(browserApp, 'Contents', 'Info.plist');
  if (!fs.existsSync(plist)) return false;

  /* Ключ хранит имя без расширения */
  return writeKey(plist, 'CFBundleIconFile', 'mba');
}

/*
 * Переименовываем браузер. Возвращаем отчёт, чтобы сборка могла
 * показать, что именно получилось.
 */
function brandBrowser(browserApp, iconSource) {
  const report = { renamed: 0, skipped: 0, icon: false, items: [] };

  for (const app of collectApps(browserApp)) {
    const plist = path.join(app, 'Contents', 'Info.plist');
    if (!fs.existsSync(plist)) {
      report.skipped += 1;
      continue;
    }

    const current = readKey(plist, 'CFBundleName') || '';
    const isHelper = /helper/i.test(current) || /helper/i.test(path.basename(app));
    const target = isHelper ? helperName(current) : BRAND;

    /* Уже переименовано — второй раз не трогаем */
    if (current === target) {
      report.skipped += 1;
      continue;
    }

    const ok =
      writeKey(plist, 'CFBundleName', target) &&
      writeKey(plist, 'CFBundleDisplayName', target);

    if (ok) {
      report.renamed += 1;
      report.items.push(path.basename(app) + ' → ' + target);
    } else {
      report.skipped += 1;
    }
  }

  /* Иконку меняем только у самого браузера: помощники в доке не видны */
  try {
    report.icon = replaceIcon(browserApp, iconSource);
  } catch (e) {
    report.icon = false;
  }

  return report;
}

module.exports = { brandBrowser, replaceIcon, BRAND };
