/*
 * Ставит ядро Chromium внутрь node_modules, а не в системный кэш.
 * Только так браузер попадает в установщик и работает у пользователя,
 * которому ничего доустанавливать не нужно.
 */
const { execSync } = require('child_process');

process.env.PLAYWRIGHT_BROWSERS_PATH = '0';

try {
  execSync('npx patchright install chromium', {
    stdio: 'inherit',
    env: { ...process.env, PLAYWRIGHT_BROWSERS_PATH: '0' },
  });
  console.log('Ядро браузера установлено внутрь проекта');
} catch (error) {
  console.error('Не удалось установить ядро браузера:', error.message);
  process.exit(1);
}
