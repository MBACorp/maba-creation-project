#!/usr/bin/env node
/*
 * Снимает блокировку macOS с собранного приложения.
 * Причина блокировки: приложение не подписано сертификатом Apple ($99/год),
 * поэтому система помечает его как «загруженное из интернета» и не запускает.
 * Мы снимаем эту метку и ставим локальную подпись — приложение начинает работать.
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const say = (m) => process.stdout.write(m + '\n');

if (process.platform !== 'darwin') {
  say('Эта команда только для macOS.');
  process.exit(0);
}

const roots = ['dist/mac-arm64', 'dist/mac', 'dist/mac-x64', '/Applications'];
const found = [];

for (const dir of roots) {
  if (!fs.existsSync(dir)) continue;
  for (const name of fs.readdirSync(dir)) {
    if (name.endsWith('.app') && (name.startsWith('MBA') || dir !== '/Applications')) {
      found.push(path.join(dir, name));
    }
  }
}

if (!found.length) {
  say('Приложение не найдено.');
  say('Соберите его: npm run build:mac:offline');
  say('Или перетащите MBA в «Программы» из окна .dmg и запустите команду снова.');
  process.exit(1);
}

let done = 0;

for (const app of found) {
  say('');
  say('Обрабатываю: ' + app);

  try {
    execSync(`xattr -cr "${app}"`, { stdio: 'pipe' });
    say('  метка «скачано из интернета» снята');
  } catch (e) {
    say('  не удалось снять метку: ' + e.message.split('\n')[0]);
  }

  try {
    execSync(`codesign --force --deep --sign - "${app}"`, { stdio: 'pipe' });
    say('  локальная подпись поставлена');
    done += 1;
  } catch (e) {
    say('  подпись не удалась: ' + e.message.split('\n')[0]);
    say('  установите инструменты разработчика: xcode-select --install');
  }
}

say('');
if (done) {
  say('Готово. Приложений обработано: ' + done);
  say('Запускайте MBA обычным двойным кликом.');
  say('Если macOS всё ещё ругается — откройте:');
  say('Системные настройки → Конфиденциальность и безопасность,');
  say('пролистайте вниз и нажмите «Всё равно открыть».');
} else {
  say('Обработать не получилось. Пришлите вывод — разберём.');
  process.exit(1);
}
