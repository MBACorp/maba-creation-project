#!/usr/bin/env node
/*
 * Снимает блокировку macOS с собранного приложения.
 *
 * Причина блокировки: приложение не подписано сертификатом Apple ($99/год),
 * поэтому система помечает его как «загруженное из интернета» и не запускает.
 * Мы снимаем эту метку и ставим локальную подпись.
 *
 * ВАЖНО про встроенный браузер.
 * Внутри лежит Chrome for Testing — отдельное приложение со своей подписью.
 * Если пройтись по нему общей подписью «насквозь» (--deep), его собственная
 * подпись затирается неправильной: браузер стартует и тут же закрывается,
 * не показав окна. Поэтому браузер мы подписываем отдельно, изнутри наружу,
 * и выдаём ему разрешения, без которых движок страниц не работает.
 */
const { execSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { brandBrowser } = require('./brand-browser');

const say = (m) => process.stdout.write(m + '\n');

say('Подготовка приложения — версия скрипта 1.0.4');
say('');

if (process.platform !== 'darwin') {
  say('Эта команда только для macOS.');
  process.exit(0);
}

const sh = (cmd) => execSync(cmd, { stdio: 'pipe' });

/* Разрешения, без которых Chromium падает при старте */
const ENTITLEMENTS = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>com.apple.security.cs.allow-jit</key><true/>
  <key>com.apple.security.cs.allow-unsigned-executable-memory</key><true/>
  <key>com.apple.security.cs.disable-library-validation</key><true/>
  <key>com.apple.security.cs.allow-dyld-environment-variables</key><true/>
  <key>com.apple.security.cs.debugger</key><true/>
</dict>
</plist>`;

const entPath = path.join(os.tmpdir(), 'mba-browser.entitlements');
fs.writeFileSync(entPath, ENTITLEMENTS);

/* Ищем вложенные браузеры внутри собранного приложения */
const findBrowsers = (root) => {
  const out = [];
  const walk = (dir, depth) => {
    if (depth > 12) return;
    let items;
    try {
      items = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const it of items) {
      if (!it.isDirectory()) continue;
      const full = path.join(dir, it.name);
      if (it.name.endsWith('.app') && /Chrome|Chromium/i.test(it.name)) {
        out.push(full);
        continue;
      }
      walk(full, depth + 1);
    }
  };
  walk(path.join(root, 'Contents'), 0);
  return out;
};

/* Подписываем браузер правильно: сначала вложенные части, потом сам браузер */
const signBrowser = (browser) => {
  const frameworks = path.join(browser, 'Contents', 'Frameworks');
  const inner = [];

  if (fs.existsSync(frameworks)) {
    const walkInner = (dir, depth) => {
      if (depth > 6) return;
      let items;
      try {
        items = fs.readdirSync(dir, { withFileTypes: true });
      } catch (e) {
        return;
      }
      for (const it of items) {
        const full = path.join(dir, it.name);
        if (it.isDirectory()) {
          if (it.name.endsWith('.app') || it.name.endsWith('.framework')) inner.push(full);
          walkInner(full, depth + 1);
        } else if (it.isFile() && (it.name.endsWith('.dylib') || it.name.endsWith('.so'))) {
          inner.push(full);
        }
      }
    };
    walkInner(frameworks, 0);
  }

  /* Глубина пути по убыванию — самые вложенные подписываем первыми */
  inner.sort((a, b) => b.split(path.sep).length - a.split(path.sep).length);

  for (const item of inner) {
    try {
      sh(`codesign --force --timestamp=none --options runtime --entitlements "${entPath}" --sign - "${item}"`);
    } catch (e) {
      /* отдельные части могут не требовать подписи — это не ошибка */
    }
  }

  sh(`codesign --force --timestamp=none --options runtime --entitlements "${entPath}" --sign - "${browser}"`);
};

const roots = ['dist/mac-arm64', 'dist/mac', '/Applications'];
const found = [];

for (const dir of roots) {
  if (!fs.existsSync(dir)) continue;
  for (const name of fs.readdirSync(dir)) {
    if (name.endsWith('.app') && (name.startsWith('MBA') || dir !== '/Applications')) {
      found.push(path.join(dir, name));
    }
  }
}

if (!found.length) {
  say('Приложение не найдено.');
  say('Соберите его: npm run build:mac');
  say('Или перетащите MBA в «Программы» из окна .dmg и запустите команду снова.');
  process.exit(1);
}

let done = 0;

for (const app of found) {
  say('');
  say('Обрабатываю: ' + app);

  try {
    sh(`xattr -cr "${app}"`);
    say('  метка «скачано из интернета» снята');
  } catch (e) {
    say('  не удалось снять метку: ' + e.message.split('\n')[0]);
  }

  /* Сначала общая подпись приложения */
  try {
    sh(`codesign --force --deep --sign - "${app}"`);
    say('  локальная подпись поставлена');
  } catch (e) {
    say('  подпись не удалась: ' + e.message.split('\n')[0]);
    say('  установите инструменты разработчика: xcode-select --install');
    continue;
  }

  /* Затем заново и правильно — встроенный браузер */
  const browsers = findBrowsers(app);

  if (!browsers.length) {
    say('  встроенный браузер не найден внутри приложения');
    say('  выполните: npm install');
  }

  for (const browser of browsers) {
    /*
     * Сначала переименовываем, потом подписываем: правка служебного файла
     * нарушает подпись, поэтому обратный порядок сломал бы запуск браузера.
     */
    try {
      const brand = brandBrowser(browser);
      if (brand.renamed) {
        say('  браузер переименован в MBA (частей: ' + brand.renamed + ')');
      }
    } catch (e) {
      say('  переименовать не удалось: ' + e.message.split('\n')[0]);
    }

    try {
      signBrowser(browser);
      say('  браузер подписан отдельно: ' + path.basename(browser));
    } catch (e) {
      say('  браузер подписать не удалось: ' + e.message.split('\n')[0]);
    }
  }

  done += 1;
}

say('');
if (done) {
  say('Готово. Приложений обработано: ' + done);
  say('Запускайте MBA обычным двойным кликом.');
  say('Если macOS всё ещё ругается — откройте:');
  say('Системные настройки → Конфиденциальность и безопасность,');
  say('пролистайте вниз и нажмите «Всё равно открыть».');
} else {
  say('Обработать не получилось. Пришлите вывод — разберём.');
  process.exit(1);
}
