const crypto = require('crypto');
const {
  DEVICES, CHROME_VERSIONS, GPU_TO_DEVICE, pickWeighted,
  KEYBOARD_LAYOUTS, VOICES_WIN, VOICES_MAC, VOICES_LOCALE,
  MEDIA_LAPTOP, MEDIA_DESKTOP,
} = require('./devices');

const LOCALES = {
  US: { locale: 'en-US', languages: ['en-US', 'en'], timezone: 'America/New_York' },
  GB: { locale: 'en-GB', languages: ['en-GB', 'en'], timezone: 'Europe/London' },
  DE: { locale: 'de-DE', languages: ['de-DE', 'de', 'en'], timezone: 'Europe/Berlin' },
  FR: { locale: 'fr-FR', languages: ['fr-FR', 'fr', 'en'], timezone: 'Europe/Paris' },
  NL: { locale: 'nl-NL', languages: ['nl-NL', 'nl', 'en'], timezone: 'Europe/Amsterdam' },
  PL: { locale: 'pl-PL', languages: ['pl-PL', 'pl', 'en'], timezone: 'Europe/Warsaw' },
  ES: { locale: 'es-ES', languages: ['es-ES', 'es', 'en'], timezone: 'Europe/Madrid' },
  IT: { locale: 'it-IT', languages: ['it-IT', 'it', 'en'], timezone: 'Europe/Rome' },
  RU: { locale: 'ru-RU', languages: ['ru-RU', 'ru', 'en'], timezone: 'Europe/Moscow' },
};

const LOCALE_TZ = {
  'en-US': 'America/New_York',
  'en-GB': 'Europe/London',
  'de-DE': 'Europe/Berlin',
  'fr-FR': 'Europe/Paris',
  'nl-NL': 'Europe/Amsterdam',
  'pl-PL': 'Europe/Warsaw',
  'es-ES': 'Europe/Madrid',
  'it-IT': 'Europe/Rome',
  'ru-RU': 'Europe/Moscow',
};

/* Языковые шрифты, которые реально доустанавливаются в системе */
const FONTS_LOCALE = {
  'ru-RU': ['PT Sans', 'PT Serif'],
  'pl-PL': ['Lato'],
};

const rng = (seed) => {
  let h = crypto.createHash('sha256').update(String(seed)).digest();
  let i = 0;
  return () => {
    if (i >= 28) {
      h = crypto.createHash('sha256').update(h).digest();
      i = 0;
    }
    const value = h.readUInt32BE(i) / 0xffffffff;
    i += 4;
    return value;
  };
};

const hashId = (r, salt) =>
  crypto
    .createHash('sha256')
    .update(String(r) + '::' + salt)
    .digest('hex');

const pick = (rand, list) => list[Math.floor(rand() * list.length) % list.length];

/* Выбор комплекта устройства с учётом ручных настроек профиля */
function selectDevice(rand, over) {
  if (over.gpu && GPU_TO_DEVICE[over.gpu]) {
    const byGpu = DEVICES.find((d) => d.id === GPU_TO_DEVICE[over.gpu]);
    if (byGpu && (!over.os || byGpu.os === over.os)) return byGpu;
  }

  let pool = DEVICES;
  if (over.os) pool = DEVICES.filter((d) => d.os === over.os);

  if (over.hardwareConcurrency) {
    const byCores = pool.filter((d) => d.cores.includes(over.hardwareConcurrency));
    if (byCores.length) pool = byCores;
  }

  if (over.deviceMemory) {
    const byMemory = pool.filter((d) => d.memory.includes(over.deviceMemory));
    if (byMemory.length) pool = byMemory;
  }

  if (!pool.length) pool = over.os ? DEVICES.filter((d) => d.os === over.os) : DEVICES;
  if (!pool.length) pool = DEVICES;

  return pickWeighted(rand, pool);
}

function buildFingerprint(profile) {
  const over = profile.fingerprint || {};
  const rand = rng(profile.id + '::' + (profile.name || ''));

  const device = selectDevice(rand, over);
  const isMac = device.os === 'mac';
  const chrome = pick(rand, CHROME_VERSIONS);

  /* Экран берётся из набора, характерного для этой машины */
  let screen = pick(rand, device.screens);
  if (over.screen && /^\d+x\d+$/.test(over.screen)) {
    const [w, h] = over.screen.split('x').map(Number);
    const known = device.screens.find((s) => s.width === w && s.height === h);
    screen = known || { width: w, height: h, ratio: isMac ? 2 : 1 };
  }

  /* Ядра и память — только из допустимых для этого устройства */
  const cores =
    over.hardwareConcurrency && device.cores.includes(over.hardwareConcurrency)
      ? over.hardwareConcurrency
      : pick(rand, device.cores);

  const memory =
    over.deviceMemory && device.memory.includes(over.deviceMemory)
      ? over.deviceMemory
      : pick(rand, device.memory);

  const geo = LOCALES[profile.country] || LOCALES.US;
  const locale = over.locale || geo.locale;
  const languages = over.locale
    ? [over.locale, over.locale.split('-')[0], 'en'].filter((v, i, a) => a.indexOf(v) === i)
    : geo.languages;
  const timezone = over.timezone || LOCALE_TZ[over.locale] || profile.timezone || geo.timezone;

  /*
   * Реальный Chrome НИКОГДА не пишет "Windows NT 11.0" — для Windows 11
   * в строке остаётся 10.0, версия различается только в Client Hints.
   * На macOS Chrome с 2021 года замораживает версию на 10_15_7.
   */
  const uaOs = isMac
    ? 'Macintosh; Intel Mac OS X 10_15_7'
    : 'Windows NT 10.0; Win64; x64';

  /* Шрифты: системный набор устройства + языковые */
  const fonts = device.fonts.concat(FONTS_LOCALE[locale] || []);

  return {
    os: device.os,
    device: device.id,
    deviceLabel: device.label,
    manual: Object.keys(over).filter((k) => k !== 'geoAuto').length > 0,
    userAgent: `Mozilla/5.0 (${uaOs}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`,
    chromeVersion: chrome,
    platform: isMac ? 'MacIntel' : 'Win32',
    /* Client Hints должны совпадать с User-Agent */
    uaData: {
      platform: isMac ? 'macOS' : 'Windows',
      platformVersion: isMac ? device.osVersion.replace(/_/g, '.') : device.osVersion === '11.0' ? '15.0.0' : '10.0.0',
      architecture: 'x86',
      bitness: '64',
      model: '',
      mobile: false,
      brands: [
        { brand: 'Chromium', version: chrome.split('.')[0] },
        { brand: 'Google Chrome', version: chrome.split('.')[0] },
        { brand: 'Not_A Brand', version: '24' },
      ],
    },
    screen: {
      width: screen.width,
      height: screen.height,
      availWidth: screen.width,
      availHeight: screen.height - (isMac ? 25 : 40),
      colorDepth: 24,
      pixelDepth: 24,
      pixelRatio: screen.ratio || 1,
    },
    hardwareConcurrency: cores,
    deviceMemory: memory,
    maxTouchPoints: 0,
    gpu: device.gpu,
    fonts,
    /* Объём диска, который браузер готов отдать сайту: зависит от машины */
    storageQuota: (memory >= 16 ? 300 : 120) * 1024 * 1024 * 1024
      + Math.round(rand() * 8 * 1024 * 1024 * 1024),
    storageUsed: Math.round(rand() * 400) / 10000,
    darkMode: rand() > 0.72,
    doNotTrack: rand() > 0.85 ? '1' : null,
    /* Домашний интернет: почти всегда 4g с небольшой задержкой */
    connection: {
      effectiveType: '4g',
      rtt: 50 + Math.round(rand() * 6) * 25,
      downlink: Math.round((6 + rand() * 4) * 10) / 10,
      saveData: false,
      type: undefined,
    },
    locale,
    languages,
    timezone,
    /* Плагины Chrome: с 2020 года набор одинаков и всегда ровно такой */
    plugins: [
      { name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
    ],

    /* Батарея: у ноутбука разряжается, у стационарного ПК всегда полная и в сети */
    battery: device.laptop
      ? {
          charging: rand() > 0.45,
          level: Math.round((0.35 + rand() * 0.6) * 100) / 100,
          chargingTime: Infinity,
          dischargingTime: Math.floor(3600 + rand() * 12000),
        }
      : { charging: true, level: 1, chargingTime: 0, dischargingTime: Infinity },

    /* Камера и микрофон: у ноутбука есть встроенная камера, у ПК обычно нет */
    mediaDevices: (device.laptop ? MEDIA_LAPTOP : MEDIA_DESKTOP).map((m, idx) => ({
      kind: m.kind,
      label: '',
      deviceId: idx === 0 ? 'default' : hashId(rand(), m.kind + idx),
      groupId: hashId(rand(), m.groupPrefix),
    })),

    keyboard: KEYBOARD_LAYOUTS[locale] || KEYBOARD_LAYOUTS['en-US'],

    voices: (isMac ? VOICES_MAC : VOICES_WIN).concat(VOICES_LOCALE[locale] || []),

    /* Смещение размеров элементов — стабильное для профиля */
    rectNoise: 1 + (rand() - 0.5) * 0.00008,

    /* Координаты в городе прокси, если сайт запросит геолокацию */
    geo: { lat: null, lon: null, accuracy: 0 },

    canvasNoise: {
      r: Math.floor(rand() * 5) - 2,
      g: Math.floor(rand() * 5) - 2,
      b: Math.floor(rand() * 5) - 2,
      seed: Math.floor(rand() * 1e9),
    },
    audioNoise: (rand() - 0.5) * 1e-7,
    webglNoise: Math.floor(rand() * 1e6),
  };
}

module.exports = { buildFingerprint, LOCALES, DEVICES };
