const crypto = require('crypto');
const {
  DEVICES, CHROME_VERSIONS, GPU_TO_DEVICE, pickWeighted,
  KEYBOARD_LAYOUTS, VOICES_WIN, VOICES_MAC, VOICES_LOCALE,
  MEDIA_LAPTOP, MEDIA_DESKTOP,
} = require('./devices');

/*
 * Соответствие страны прокси и настроек профиля. Немецкий IP с московским
 * временем — самый частый повод для блокировки, поэтому язык, часовой пояс
 * и региональные шрифты подбираются по стране автоматически.
 */
const LOCALES = {
  US: { locale: 'en-US', languages: ['en-US', 'en'], timezone: 'America/New_York' },
  CA: { locale: 'en-CA', languages: ['en-CA', 'en', 'fr'], timezone: 'America/Toronto' },
  GB: { locale: 'en-GB', languages: ['en-GB', 'en'], timezone: 'Europe/London' },
  IE: { locale: 'en-IE', languages: ['en-IE', 'en'], timezone: 'Europe/Dublin' },
  DE: { locale: 'de-DE', languages: ['de-DE', 'de', 'en'], timezone: 'Europe/Berlin' },
  AT: { locale: 'de-AT', languages: ['de-AT', 'de', 'en'], timezone: 'Europe/Vienna' },
  CH: { locale: 'de-CH', languages: ['de-CH', 'de', 'en'], timezone: 'Europe/Zurich' },
  FR: { locale: 'fr-FR', languages: ['fr-FR', 'fr', 'en'], timezone: 'Europe/Paris' },
  NL: { locale: 'nl-NL', languages: ['nl-NL', 'nl', 'en'], timezone: 'Europe/Amsterdam' },
  BE: { locale: 'nl-BE', languages: ['nl-BE', 'nl', 'fr', 'en'], timezone: 'Europe/Brussels' },
  PL: { locale: 'pl-PL', languages: ['pl-PL', 'pl', 'en'], timezone: 'Europe/Warsaw' },
  ES: { locale: 'es-ES', languages: ['es-ES', 'es', 'en'], timezone: 'Europe/Madrid' },
  PT: { locale: 'pt-PT', languages: ['pt-PT', 'pt', 'en'], timezone: 'Europe/Lisbon' },
  IT: { locale: 'it-IT', languages: ['it-IT', 'it', 'en'], timezone: 'Europe/Rome' },
  SE: { locale: 'sv-SE', languages: ['sv-SE', 'sv', 'en'], timezone: 'Europe/Stockholm' },
  NO: { locale: 'nb-NO', languages: ['nb-NO', 'nb', 'en'], timezone: 'Europe/Oslo' },
  DK: { locale: 'da-DK', languages: ['da-DK', 'da', 'en'], timezone: 'Europe/Copenhagen' },
  FI: { locale: 'fi-FI', languages: ['fi-FI', 'fi', 'en'], timezone: 'Europe/Helsinki' },
  CZ: { locale: 'cs-CZ', languages: ['cs-CZ', 'cs', 'en'], timezone: 'Europe/Prague' },
  SK: { locale: 'sk-SK', languages: ['sk-SK', 'sk', 'en'], timezone: 'Europe/Bratislava' },
  HU: { locale: 'hu-HU', languages: ['hu-HU', 'hu', 'en'], timezone: 'Europe/Budapest' },
  RO: { locale: 'ro-RO', languages: ['ro-RO', 'ro', 'en'], timezone: 'Europe/Bucharest' },
  BG: { locale: 'bg-BG', languages: ['bg-BG', 'bg', 'en'], timezone: 'Europe/Sofia' },
  GR: { locale: 'el-GR', languages: ['el-GR', 'el', 'en'], timezone: 'Europe/Athens' },
  UA: { locale: 'uk-UA', languages: ['uk-UA', 'uk', 'ru', 'en'], timezone: 'Europe/Kyiv' },
  MD: { locale: 'ro-MD', languages: ['ro-MD', 'ro', 'ru', 'en'], timezone: 'Europe/Chisinau' },
  LT: { locale: 'lt-LT', languages: ['lt-LT', 'lt', 'en'], timezone: 'Europe/Vilnius' },
  LV: { locale: 'lv-LV', languages: ['lv-LV', 'lv', 'ru', 'en'], timezone: 'Europe/Riga' },
  EE: { locale: 'et-EE', languages: ['et-EE', 'et', 'ru', 'en'], timezone: 'Europe/Tallinn' },
  RU: { locale: 'ru-RU', languages: ['ru-RU', 'ru', 'en'], timezone: 'Europe/Moscow' },
  BY: { locale: 'ru-BY', languages: ['ru-BY', 'ru', 'be', 'en'], timezone: 'Europe/Minsk' },
  KZ: { locale: 'ru-KZ', languages: ['ru-KZ', 'ru', 'kk', 'en'], timezone: 'Asia/Almaty' },
  GE: { locale: 'ka-GE', languages: ['ka-GE', 'ka', 'ru', 'en'], timezone: 'Asia/Tbilisi' },
  AM: { locale: 'hy-AM', languages: ['hy-AM', 'hy', 'ru', 'en'], timezone: 'Asia/Yerevan' },
  AZ: { locale: 'az-AZ', languages: ['az-AZ', 'az', 'ru', 'en'], timezone: 'Asia/Baku' },
  TR: { locale: 'tr-TR', languages: ['tr-TR', 'tr', 'en'], timezone: 'Europe/Istanbul' },
  IL: { locale: 'he-IL', languages: ['he-IL', 'he', 'en'], timezone: 'Asia/Jerusalem' },
  AE: { locale: 'en-AE', languages: ['en-AE', 'en', 'ar'], timezone: 'Asia/Dubai' },
  IN: { locale: 'en-IN', languages: ['en-IN', 'en', 'hi'], timezone: 'Asia/Kolkata' },
  SG: { locale: 'en-SG', languages: ['en-SG', 'en', 'zh'], timezone: 'Asia/Singapore' },
  HK: { locale: 'en-HK', languages: ['en-HK', 'en', 'zh'], timezone: 'Asia/Hong_Kong' },
  JP: { locale: 'ja-JP', languages: ['ja-JP', 'ja', 'en'], timezone: 'Asia/Tokyo' },
  KR: { locale: 'ko-KR', languages: ['ko-KR', 'ko', 'en'], timezone: 'Asia/Seoul' },
  VN: { locale: 'vi-VN', languages: ['vi-VN', 'vi', 'en'], timezone: 'Asia/Ho_Chi_Minh' },
  TH: { locale: 'th-TH', languages: ['th-TH', 'th', 'en'], timezone: 'Asia/Bangkok' },
  ID: { locale: 'id-ID', languages: ['id-ID', 'id', 'en'], timezone: 'Asia/Jakarta' },
  PH: { locale: 'en-PH', languages: ['en-PH', 'en', 'tl'], timezone: 'Asia/Manila' },
  BR: { locale: 'pt-BR', languages: ['pt-BR', 'pt', 'en'], timezone: 'America/Sao_Paulo' },
  MX: { locale: 'es-MX', languages: ['es-MX', 'es', 'en'], timezone: 'America/Mexico_City' },
  AR: { locale: 'es-AR', languages: ['es-AR', 'es', 'en'], timezone: 'America/Argentina/Buenos_Aires' },
  CL: { locale: 'es-CL', languages: ['es-CL', 'es', 'en'], timezone: 'America/Santiago' },
  CO: { locale: 'es-CO', languages: ['es-CO', 'es', 'en'], timezone: 'America/Bogota' },
  ZA: { locale: 'en-ZA', languages: ['en-ZA', 'en'], timezone: 'Africa/Johannesburg' },
  EG: { locale: 'ar-EG', languages: ['ar-EG', 'ar', 'en'], timezone: 'Africa/Cairo' },
  NG: { locale: 'en-NG', languages: ['en-NG', 'en'], timezone: 'Africa/Lagos' },
  AU: { locale: 'en-AU', languages: ['en-AU', 'en'], timezone: 'Australia/Sydney' },
  NZ: { locale: 'en-NZ', languages: ['en-NZ', 'en'], timezone: 'Pacific/Auckland' },
};

/* Обратная связь: по языку восстанавливаем часовой пояс */
const LOCALE_TZ = Object.keys(LOCALES).reduce((acc, code) => {
  const item = LOCALES[code];
  if (!acc[item.locale]) acc[item.locale] = item.timezone;
  return acc;
}, {});

/*
 * Крупные страны с несколькими поясами: по городу выбираем точный.
 * Иначе клиент из Лос-Анджелеса живёт по нью-йоркскому времени.
 */
const CITY_TZ = {
  US: {
    'new york': 'America/New_York', brooklyn: 'America/New_York', queens: 'America/New_York',
    boston: 'America/New_York', philadelphia: 'America/New_York', atlanta: 'America/New_York',
    miami: 'America/New_York', washington: 'America/New_York', newark: 'America/New_York',
    charlotte: 'America/New_York', detroit: 'America/Detroit', columbus: 'America/New_York',
    chicago: 'America/Chicago', houston: 'America/Chicago', dallas: 'America/Chicago',
    austin: 'America/Chicago', 'san antonio': 'America/Chicago', minneapolis: 'America/Chicago',
    'kansas city': 'America/Chicago', 'new orleans': 'America/Chicago', memphis: 'America/Chicago',
    denver: 'America/Denver', 'salt lake city': 'America/Denver', albuquerque: 'America/Denver',
    phoenix: 'America/Phoenix', tucson: 'America/Phoenix',
    'los angeles': 'America/Los_Angeles', 'san francisco': 'America/Los_Angeles',
    'san diego': 'America/Los_Angeles', seattle: 'America/Los_Angeles',
    portland: 'America/Los_Angeles', 'san jose': 'America/Los_Angeles',
    sacramento: 'America/Los_Angeles', 'las vegas': 'America/Los_Angeles',
    anchorage: 'America/Anchorage', honolulu: 'Pacific/Honolulu',
  },
  RU: {
    moscow: 'Europe/Moscow', 'saint petersburg': 'Europe/Moscow', kazan: 'Europe/Moscow',
    'nizhny novgorod': 'Europe/Moscow', rostov: 'Europe/Moscow', voronezh: 'Europe/Moscow',
    krasnodar: 'Europe/Moscow', sochi: 'Europe/Moscow', samara: 'Europe/Samara',
    yekaterinburg: 'Asia/Yekaterinburg', perm: 'Asia/Yekaterinburg', chelyabinsk: 'Asia/Yekaterinburg',
    ufa: 'Asia/Yekaterinburg', omsk: 'Asia/Omsk', novosibirsk: 'Asia/Novosibirsk',
    krasnoyarsk: 'Asia/Krasnoyarsk', irkutsk: 'Asia/Irkutsk', vladivostok: 'Asia/Vladivostok',
    khabarovsk: 'Asia/Vladivostok', kaliningrad: 'Europe/Kaliningrad',
  },
  CA: {
    toronto: 'America/Toronto', ottawa: 'America/Toronto', montreal: 'America/Toronto',
    quebec: 'America/Toronto', winnipeg: 'America/Winnipeg', calgary: 'America/Edmonton',
    edmonton: 'America/Edmonton', vancouver: 'America/Vancouver', victoria: 'America/Vancouver',
    halifax: 'America/Halifax',
  },
  BR: {
    'sao paulo': 'America/Sao_Paulo', 'rio de janeiro': 'America/Sao_Paulo',
    brasilia: 'America/Sao_Paulo', salvador: 'America/Bahia', fortaleza: 'America/Fortaleza',
    manaus: 'America/Manaus', recife: 'America/Recife',
  },
  AU: {
    sydney: 'Australia/Sydney', melbourne: 'Australia/Melbourne', canberra: 'Australia/Sydney',
    brisbane: 'Australia/Brisbane', adelaide: 'Australia/Adelaide', perth: 'Australia/Perth',
    hobart: 'Australia/Hobart', darwin: 'Australia/Darwin',
  },
  KZ: { almaty: 'Asia/Almaty', astana: 'Asia/Almaty', aktobe: 'Asia/Aqtobe', atyrau: 'Asia/Atyrau' },
  ID: { jakarta: 'Asia/Jakarta', surabaya: 'Asia/Jakarta', bali: 'Asia/Makassar', denpasar: 'Asia/Makassar' },
  MX: { 'mexico city': 'America/Mexico_City', guadalajara: 'America/Mexico_City', tijuana: 'America/Tijuana', cancun: 'America/Cancun' },
};

/*
 * Подбор настроек по данным прокси. Приоритет: точный пояс города,
 * затем пояс, который вернул сервис определения IP, затем средний по стране.
 */
function geoFromProxy(country, city, ipTimezone) {
  const code = String(country || '').toUpperCase();
  const base = LOCALES[code];
  if (!base) return null;

  let timezone = base.timezone;
  const cities = CITY_TZ[code];
  const key = String(city || '').toLowerCase().trim();
  if (cities && key && cities[key]) {
    timezone = cities[key];
  } else if (ipTimezone && String(ipTimezone).includes('/')) {
    timezone = ipTimezone;
  }

  return { locale: base.locale, languages: base.languages, timezone, country: code };
}

/*
 * Шрифты, которые реально стоят у жителей региона. Без них профиль с
 * японским IP не имеет ни одного японского шрифта — заметное расхождение.
 */
const FONTS_LOCALE = {
  ru: ['PT Sans', 'PT Serif', 'Tahoma'],
  uk: ['PT Sans', 'PT Serif'],
  be: ['PT Sans', 'PT Serif'],
  pl: ['Lato', 'Calibri'],
  cs: ['Calibri', 'Tahoma'],
  sk: ['Calibri', 'Tahoma'],
  hu: ['Calibri', 'Tahoma'],
  ro: ['Calibri', 'Tahoma'],
  bg: ['PT Sans', 'Tahoma'],
  el: ['Calibri', 'Tahoma'],
  tr: ['Calibri', 'Tahoma'],
  he: ['Arial Hebrew', 'David'],
  ar: ['Arial Arabic', 'Traditional Arabic', 'Tahoma'],
  ja: ['MS Gothic', 'Meiryo', 'Yu Gothic', 'Hiragino Sans'],
  ko: ['Malgun Gothic', 'Batang', 'Apple SD Gothic Neo'],
  zh: ['SimSun', 'Microsoft YaHei', 'PingFang SC'],
  th: ['Tahoma', 'Leelawadee UI'],
  vi: ['Tahoma', 'Calibri'],
  hi: ['Nirmala UI', 'Mangal'],
  ka: ['Sylfaen'],
  hy: ['Sylfaen'],
};

/* Определяем язык региона по коду локали: de-AT -> de */
const localeFonts = (locale) => {
  const lang = String(locale || '').split('-')[0].toLowerCase();
  return FONTS_LOCALE[lang] || [];
};

const rng = (seed) => {
  let h = crypto.createHash('sha256').update(String(seed)).digest();
  let i = 0;
  return () => {
    if (i >= 28) {
      h = crypto.createHash('sha256').update(h).digest();
      i = 0;
    }
    const value = h.readUInt32BE(i) / 0xffffffff;
    i += 4;
    return value;
  };
};

const hashId = (r, salt) =>
  crypto
    .createHash('sha256')
    .update(String(r) + '::' + salt)
    .digest('hex');

const pick = (rand, list) => list[Math.floor(rand() * list.length) % list.length];

/* Выбор комплекта устройства с учётом ручных настроек профиля */
function selectDevice(rand, over) {
  if (over.gpu && GPU_TO_DEVICE[over.gpu]) {
    const byGpu = DEVICES.find((d) => d.id === GPU_TO_DEVICE[over.gpu]);
    if (byGpu && (!over.os || byGpu.os === over.os)) return byGpu;
  }

  let pool = DEVICES;
  if (over.os) pool = DEVICES.filter((d) => d.os === over.os);

  if (over.hardwareConcurrency) {
    const byCores = pool.filter((d) => d.cores.includes(over.hardwareConcurrency));
    if (byCores.length) pool = byCores;
  }

  if (over.deviceMemory) {
    const byMemory = pool.filter((d) => d.memory.includes(over.deviceMemory));
    if (byMemory.length) pool = byMemory;
  }

  if (!pool.length) pool = over.os ? DEVICES.filter((d) => d.os === over.os) : DEVICES;
  if (!pool.length) pool = DEVICES;

  return pickWeighted(rand, pool);
}

function buildFingerprint(profile) {
  const over = profile.fingerprint || {};
  const rand = rng(profile.id + '::' + (profile.name || ''));

  const device = selectDevice(rand, over);
  const isMac = device.os === 'mac';
  const chrome = pick(rand, CHROME_VERSIONS);

  /* Экран берётся из набора, характерного для этой машины */
  let screen = pick(rand, device.screens);
  if (over.screen && /^\d+x\d+$/.test(over.screen)) {
    const [w, h] = over.screen.split('x').map(Number);
    const known = device.screens.find((s) => s.width === w && s.height === h);
    screen = known || { width: w, height: h, ratio: isMac ? 2 : 1 };
  }

  /* Ядра и память — только из допустимых для этого устройства */
  const cores =
    over.hardwareConcurrency && device.cores.includes(over.hardwareConcurrency)
      ? over.hardwareConcurrency
      : pick(rand, device.cores);

  const memory =
    over.deviceMemory && device.memory.includes(over.deviceMemory)
      ? over.deviceMemory
      : pick(rand, device.memory);

  /*
   * Настройки региона: если у профиля есть прокси, берём их от него —
   * город даёт точный пояс, иначе используем средний по стране.
   * Ручной выбор пользователя всегда важнее автоматического.
   */
  const fromProxy = geoFromProxy(profile.country, profile.city, profile.ipTimezone);
  const geo = fromProxy || LOCALES[profile.country] || LOCALES.US;

  const locale = over.locale || geo.locale;
  const languages = over.locale
    ? [over.locale, over.locale.split('-')[0], 'en'].filter((v, i, a) => a.indexOf(v) === i)
    : geo.languages;
  const timezone = over.timezone || LOCALE_TZ[over.locale] || profile.timezone || geo.timezone;

  /* Несовпадение страны прокси и настроек профиля — повод для блокировки */
  const geoMismatch = Boolean(
    profile.country && LOCALES[String(profile.country).toUpperCase()]
      && over.timezone && over.timezone !== geo.timezone,
  );

  /*
   * Реальный Chrome НИКОГДА не пишет "Windows NT 11.0" — для Windows 11
   * в строке остаётся 10.0, версия различается только в Client Hints.
   * На macOS Chrome с 2021 года замораживает версию на 10_15_7.
   */
  const uaOs = isMac
    ? 'Macintosh; Intel Mac OS X 10_15_7'
    : 'Windows NT 10.0; Win64; x64';

  /* Шрифты: системный набор устройства + языковые */
  const fonts = device.fonts.concat(localeFonts(locale))
    .filter((f, i, arr) => arr.indexOf(f) === i);

  return {
    os: device.os,
    device: device.id,
    deviceLabel: device.label,
    manual: Object.keys(over).filter((k) => k !== 'geoAuto').length > 0,
    userAgent: `Mozilla/5.0 (${uaOs}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`,
    chromeVersion: chrome,
    platform: isMac ? 'MacIntel' : 'Win32',
    /* Client Hints должны совпадать с User-Agent */
    uaData: {
      platform: isMac ? 'macOS' : 'Windows',
      platformVersion: isMac ? device.osVersion.replace(/_/g, '.') : device.osVersion === '11.0' ? '15.0.0' : '10.0.0',
      architecture: 'x86',
      bitness: '64',
      model: '',
      mobile: false,
      brands: [
        { brand: 'Chromium', version: chrome.split('.')[0] },
        { brand: 'Google Chrome', version: chrome.split('.')[0] },
        { brand: 'Not_A Brand', version: '24' },
      ],
    },
    screen: {
      width: screen.width,
      height: screen.height,
      availWidth: screen.width,
      availHeight: screen.height - (isMac ? 25 : 40),
      colorDepth: 24,
      pixelDepth: 24,
      pixelRatio: screen.ratio || 1,
    },
    hardwareConcurrency: cores,
    deviceMemory: memory,
    maxTouchPoints: 0,
    gpu: device.gpu,
    fonts,
    /* Объём диска, который браузер готов отдать сайту: зависит от машины */
    storageQuota: (memory >= 16 ? 300 : 120) * 1024 * 1024 * 1024
      + Math.round(rand() * 8 * 1024 * 1024 * 1024),
    storageUsed: Math.round(rand() * 400) / 10000,
    darkMode: rand() > 0.72,
    doNotTrack: rand() > 0.85 ? '1' : null,
    /* Домашний интернет: почти всегда 4g с небольшой задержкой */
    connection: {
      effectiveType: '4g',
      rtt: 50 + Math.round(rand() * 6) * 25,
      downlink: Math.round((6 + rand() * 4) * 10) / 10,
      saveData: false,
      type: undefined,
    },
    locale,
    languages,
    timezone,
    geoMismatch,
    geoCountry: geo.country || profile.country || '',
    /* Плагины Chrome: с 2020 года набор одинаков и всегда ровно такой */
    plugins: [
      { name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
      { name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
    ],

    /* Батарея: у ноутбука разряжается, у стационарного ПК всегда полная и в сети */
    battery: device.laptop
      ? {
          charging: rand() > 0.45,
          level: Math.round((0.35 + rand() * 0.6) * 100) / 100,
          chargingTime: Infinity,
          dischargingTime: Math.floor(3600 + rand() * 12000),
        }
      : { charging: true, level: 1, chargingTime: 0, dischargingTime: Infinity },

    /* Камера и микрофон: у ноутбука есть встроенная камера, у ПК обычно нет */
    mediaDevices: (device.laptop ? MEDIA_LAPTOP : MEDIA_DESKTOP).map((m, idx) => ({
      kind: m.kind,
      label: '',
      deviceId: idx === 0 ? 'default' : hashId(rand(), m.kind + idx),
      groupId: hashId(rand(), m.groupPrefix),
    })),

    keyboard: KEYBOARD_LAYOUTS[locale] || KEYBOARD_LAYOUTS['en-US'],

    voices: (isMac ? VOICES_MAC : VOICES_WIN).concat(VOICES_LOCALE[locale] || []),

    /* Смещение размеров элементов — стабильное для профиля */
    rectNoise: 1 + (rand() - 0.5) * 0.00008,

    /* Координаты в городе прокси, если сайт запросит геолокацию */
    geo: { lat: null, lon: null, accuracy: 0 },

    canvasNoise: {
      r: Math.floor(rand() * 5) - 2,
      g: Math.floor(rand() * 5) - 2,
      b: Math.floor(rand() * 5) - 2,
      seed: Math.floor(rand() * 1e9),
    },
    audioNoise: (rand() - 0.5) * 1e-7,
    webglNoise: Math.floor(rand() * 1e6),
  };
}

module.exports = { buildFingerprint, geoFromProxy, LOCALES, DEVICES };
