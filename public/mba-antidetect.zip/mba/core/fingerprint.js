const crypto = require('crypto');

const SCREENS = [
  { width: 1920, height: 1080 },
  { width: 1536, height: 864 },
  { width: 1440, height: 900 },
  { width: 1366, height: 768 },
  { width: 2560, height: 1440 },
];

const WIN_VERSIONS = ['10.0', '11.0'];
const MAC_VERSIONS = ['13_5_2', '14_4_1', '15_1'];
const CHROME_VERSIONS = ['131.0.6778.86', '132.0.6834.84', '133.0.6943.54'];

const GPU_WIN = [
  { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
  { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
  { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6600 Direct3D11 vs_5_0 ps_5_0, D3D11)' },
];

const GPU_MAC = [
  { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)' },
  { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)' },
];

const FONTS_WIN = ['Arial', 'Calibri', 'Cambria', 'Consolas', 'Georgia', 'Segoe UI', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana'];
const FONTS_MAC = ['Arial', 'Avenir', 'Geneva', 'Helvetica', 'Helvetica Neue', 'Menlo', 'Monaco', 'Optima', 'Times', 'Verdana'];

const LOCALES = {
  US: { locale: 'en-US', languages: ['en-US', 'en'], timezone: 'America/New_York' },
  DE: { locale: 'de-DE', languages: ['de-DE', 'de', 'en'], timezone: 'Europe/Berlin' },
  NL: { locale: 'nl-NL', languages: ['nl-NL', 'nl', 'en'], timezone: 'Europe/Amsterdam' },
  PL: { locale: 'pl-PL', languages: ['pl-PL', 'pl', 'en'], timezone: 'Europe/Warsaw' },
  GB: { locale: 'en-GB', languages: ['en-GB', 'en'], timezone: 'Europe/London' },
  FR: { locale: 'fr-FR', languages: ['fr-FR', 'fr', 'en'], timezone: 'Europe/Paris' },
  RU: { locale: 'ru-RU', languages: ['ru-RU', 'ru', 'en'], timezone: 'Europe/Moscow' },
};

const rng = (seed) => {
  let h = crypto.createHash('sha256').update(String(seed)).digest();
  let i = 0;
  return () => {
    if (i >= 28) {
      h = crypto.createHash('sha256').update(h).digest();
      i = 0;
    }
    const value = h.readUInt32BE(i) / 0xffffffff;
    i += 4;
    return value;
  };
};

const pick = (rand, list) => list[Math.floor(rand() * list.length) % list.length];

function buildFingerprint(profile) {
  const rand = rng(profile.id + '::' + (profile.name || ''));
  const os = profile.os || (rand() > 0.72 ? 'mac' : 'win');
  const isMac = os === 'mac';
  const chrome = pick(rand, CHROME_VERSIONS);
  const screen = pick(rand, SCREENS);
  const gpu = pick(rand, isMac ? GPU_MAC : GPU_WIN);
  const geo = LOCALES[profile.country] || LOCALES.US;

  const platformVersion = isMac ? pick(rand, MAC_VERSIONS) : pick(rand, WIN_VERSIONS);
  const uaOs = isMac
    ? `Macintosh; Intel Mac OS X ${platformVersion}`
    : `Windows NT ${platformVersion}; Win64; x64`;

  return {
    os,
    userAgent: `Mozilla/5.0 (${uaOs}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chrome} Safari/537.36`,
    platform: isMac ? 'MacIntel' : 'Win32',
    screen: {
      width: screen.width,
      height: screen.height,
      availWidth: screen.width,
      availHeight: screen.height - (isMac ? 25 : 40),
      colorDepth: 24,
      pixelDepth: 24,
    },
    hardwareConcurrency: pick(rand, [4, 8, 8, 12, 16]),
    deviceMemory: pick(rand, [4, 8, 8, 16]),
    maxTouchPoints: 0,
    gpu,
    fonts: isMac ? FONTS_MAC : FONTS_WIN,
    locale: geo.locale,
    languages: geo.languages,
    timezone: profile.timezone || geo.timezone,
    canvasNoise: {
      r: Math.floor(rand() * 5) - 2,
      g: Math.floor(rand() * 5) - 2,
      b: Math.floor(rand() * 5) - 2,
      seed: Math.floor(rand() * 1e9),
    },
    audioNoise: (rand() - 0.5) * 1e-7,
    webglNoise: Math.floor(rand() * 1e6),
  };
}

module.exports = { buildFingerprint, LOCALES };
