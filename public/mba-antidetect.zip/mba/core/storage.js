const fs = require('fs');
const path = require('path');

class Storage {
  constructor(dir) {
    this.file = path.join(dir, 'profiles.json');
    fs.mkdirSync(dir, { recursive: true });
  }

  read() {
    try {
      return JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch (e) {
      return { profiles: [], proxies: [] };
    }
  }

  write(data) {
    fs.writeFileSync(this.file, JSON.stringify(data, null, 2), 'utf8');
    return data;
  }

  listProfiles() {
    return this.read().profiles || [];
  }

  saveProfile(profile) {
    const data = this.read();
    data.profiles = data.profiles || [];
    const index = data.profiles.findIndex((p) => p.id === profile.id);
    if (index >= 0) data.profiles[index] = { ...data.profiles[index], ...profile };
    else data.profiles.push(profile);
    this.write(data);
    return profile;
  }

  deleteProfile(id) {
    const data = this.read();
    data.profiles = (data.profiles || []).filter((p) => p.id !== id);
    this.write(data);
  }

  listProxies() {
    return this.read().proxies || [];
  }

  saveProxy(proxy) {
    const data = this.read();
    data.proxies = data.proxies || [];
    const index = data.proxies.findIndex((p) => p.id === proxy.id);
    if (index >= 0) data.proxies[index] = { ...data.proxies[index], ...proxy };
    else data.proxies.push(proxy);
    this.write(data);
    return proxy;
  }

  deleteProxy(id) {
    const data = this.read();
    data.proxies = (data.proxies || []).filter((p) => p.id !== id);
    this.write(data);
  }
}

module.exports = { Storage };
