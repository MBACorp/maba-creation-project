const path = require('path');
const fs = require('fs');
const { buildFingerprint } = require('./fingerprint');
const { buildInjectScript } = require('./inject');

const sessions = new Map();

const parseProxy = (profile) => {
  if (!profile.proxyHost) return undefined;
  const scheme = (profile.proxyType || 'socks5').toLowerCase();
  const proxy = { server: `${scheme}://${profile.proxyHost}` };
  if (profile.proxyUser) {
    proxy.username = profile.proxyUser;
    proxy.password = profile.proxyPass || '';
  }
  return proxy;
};

async function launchProfile(profile, dataRoot, onClose) {
  if (sessions.has(profile.id)) return { alreadyRunning: true };

  const { chromium } = require('patchright');

  const fp = buildFingerprint(profile);
  const userDataDir = path.join(dataRoot, 'profiles', profile.id);
  fs.mkdirSync(userDataDir, { recursive: true });

  const context = await chromium.launchPersistentContext(userDataDir, {
    headless: false,
    channel: 'chromium',
    viewport: null,
    userAgent: fp.userAgent,
    locale: fp.locale,
    timezoneId: fp.timezone,
    proxy: parseProxy(profile),
    deviceScaleFactor: fp.screen.pixelRatio || 1,
    ignoreDefaultArgs: ['--enable-automation'],
    args: [
      '--no-default-browser-check',
      '--no-first-run',
      '--disable-blink-features=AutomationControlled',
      `--lang=${fp.languages[0]}`,
      `--window-size=${Math.min(fp.screen.width, 1440)},${Math.min(fp.screen.height - 80, 900)}`,
    ],
  });

  await context.addInitScript(buildInjectScript(fp));

  const pages = context.pages();
  const page = pages.length ? pages[0] : await context.newPage();
  await page.goto('https://browserleaks.com/canvas').catch(() => undefined);

  context.on('close', () => {
    sessions.delete(profile.id);
    if (onClose) onClose(profile.id);
  });

  sessions.set(profile.id, { context, fingerprint: fp, startedAt: Date.now() });
  return { fingerprint: fp };
}

async function stopProfile(id) {
  const session = sessions.get(id);
  if (!session) return false;
  sessions.delete(id);
  await session.context.close().catch(() => undefined);
  return true;
}

const isRunning = (id) => sessions.has(id);
const runningIds = () => [...sessions.keys()];

async function stopAll() {
  await Promise.all([...sessions.keys()].map(stopProfile));
}

module.exports = { launchProfile, stopProfile, isRunning, runningIds, stopAll };
