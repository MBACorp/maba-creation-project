const path = require('path');
const fs = require('fs');
const { buildFingerprint } = require('./fingerprint');
const { buildInjectScript } = require('./inject');
const cookieStore = require('./cookies');
const { auditProfile } = require('./audit');
const { applyEngineOverrides } = require('./cdp');

const sessions = new Map();

/*
 * Готовит прокси для браузера.
 * В поле адреса пользователи часто вставляют строку целиком, вместе с
 * логином и паролем: «1.2.3.4:8080:user:pass» или «user:pass@1.2.3.4:8080».
 * Браузеру адрес нужно передать чистым, иначе подключения не будет.
 */
const parseProxy = (profile) => {
  if (!profile.proxyHost) return undefined;

  const scheme = (profile.proxyType || 'socks5').toLowerCase();
  const raw = String(profile.proxyHost).trim().replace(/^[a-z0-9]+:\/\//i, '');

  let user = profile.proxyUser || '';
  let pass = profile.proxyPass || '';
  let hostPart = raw;

  const at = raw.lastIndexOf('@');
  if (at >= 0) {
    const creds = raw.slice(0, at).split(':');
    hostPart = raw.slice(at + 1);
    if (!user && creds[0]) {
      user = creds[0];
      pass = pass || creds[1] || '';
    }
  } else {
    const parts = raw.split(':');
    if (parts.length > 2 && !Number.isNaN(parseInt(parts[1], 10))) {
      hostPart = `${parts[0]}:${parts[1]}`;
      if (!user && parts[2]) {
        user = parts[2];
        pass = pass || parts[3] || '';
      }
    }
  }

  const proxy = { server: `${scheme}://${hostPart}` };
  if (user) {
    proxy.username = user;
    proxy.password = pass;
  }
  return proxy;
};

/*
 * Ищет ядро браузера на диске.
 *
 * В собранном приложении код лежит внутри архива app.asar — это один файл,
 * а не папка. Запустить браузер «изнутри» файла нельзя: система отвечает
 * ENOTDIR. Поэтому ядро распаковывается рядом, в app.asar.unpacked,
 * и путь к нему нужно указать явно.
 */
const browserRoots = () => {
  const roots = [];

  if (__dirname.includes('app.asar')) {
    const base = __dirname.split('app.asar')[0];
    roots.push(path.join(base, 'app.asar.unpacked', 'node_modules'));
  }

  roots.push(path.join(__dirname, '..', 'node_modules'));
  return roots;
};

const findChromium = () => {
  for (const root of browserRoots()) {
    const local = path.join(root, 'patchright-core', '.local-browsers');
    if (!fs.existsSync(local)) continue;

    let folders;
    try {
      folders = fs.readdirSync(local).filter((n) => n.startsWith('chromium'));
    } catch (e) {
      continue;
    }

    for (const folder of folders) {
      const candidates =
        process.platform === 'darwin'
          ? [
              path.join(local, folder, 'chrome-mac-arm64', 'Google Chrome for Testing.app', 'Contents', 'MacOS', 'Google Chrome for Testing'),
              path.join(local, folder, 'chrome-mac', 'Google Chrome for Testing.app', 'Contents', 'MacOS', 'Google Chrome for Testing'),
              path.join(local, folder, 'chrome-mac', 'Chromium.app', 'Contents', 'MacOS', 'Chromium'),
            ]
          : [
              path.join(local, folder, 'chrome-win', 'chrome.exe'),
              path.join(local, folder, 'chrome-win64', 'chrome.exe'),
            ];

      for (const file of candidates) {
        if (fs.existsSync(file)) return file;
      }
    }
  }
  return null;
};

const prepareBrowserPath = () => {
  if (!process.env.PLAYWRIGHT_BROWSERS_PATH) {
    process.env.PLAYWRIGHT_BROWSERS_PATH = '0';
  }
  return findChromium();
};

async function launchProfile(profile, dataRoot, onClose) {
  if (sessions.has(profile.id)) return { alreadyRunning: true };

  const executablePath = prepareBrowserPath();

  if (!executablePath && __dirname.includes('app.asar')) {
    throw new Error(
      'Ядро браузера не найдено внутри приложения. ' +
      'Переустановите MBA — в новой сборке ядро упаковано правильно.'
    );
  }

  const { chromium } = require('patchright');

  const fp = buildFingerprint(profile);
  const userDataDir = path.join(dataRoot, 'profiles', profile.id);
  fs.mkdirSync(userDataDir, { recursive: true });

  let context;
  try {
    context = await chromium.launchPersistentContext(userDataDir, {
    headless: false,
    ...(executablePath ? { executablePath } : { channel: 'chromium' }),
    viewport: null,
    userAgent: fp.userAgent,
    locale: fp.locale,
    timezoneId: fp.timezone,
    proxy: parseProxy(profile),
    deviceScaleFactor: fp.screen.pixelRatio || 1,
    ignoreDefaultArgs: ['--enable-automation'],
    args: [
      '--no-default-browser-check',
      '--no-first-run',
      '--disable-blink-features=AutomationControlled',
      `--lang=${fp.languages[0]}`,
      `--window-size=${Math.min(fp.screen.width, 1440)},${Math.min(fp.screen.height - 80, 900)}`,
      /* Отключаем службы, по обращениям к которым видно нестандартную сборку */
      '--disable-features=IsolateOrigins,site-per-process,TranslateUI,OptimizationHints,MediaRouter,AutomationControlled',
      '--disable-component-update',
      '--disable-background-networking',
      '--disable-sync',
      '--no-service-autorun',
      '--password-store=basic',
      '--use-mock-keychain',
      /* Единый цветовой профиль: иначе по нему различают мониторы */
      '--force-color-profile=srgb',
      '--metrics-recording-only',
      '--disable-domain-reliability',
      ],
    });
  } catch (err) {
    const text = String(err && err.message ? err.message : err);

    /*
     * Браузер стартовал и сразу закрылся. Причину видно только снаружи:
     * спрашиваем у macOS, цела ли подпись, и говорим пользователю по делу.
     */
    if (process.platform === 'darwin' && /exitCode=0|ENOTDIR|Target page|crashed|closed/i.test(text)) {
      let reason = '';

      if (executablePath) {
        const appDir = executablePath.split('/Contents/MacOS/')[0];
        try {
          require('child_process').execSync(
            `codesign --verify --deep --strict "${appDir}"`,
            { stdio: 'pipe' }
          );
          reason = 'Подпись браузера цела, но система всё равно его закрыла.';
        } catch (signErr) {
          const detail = (signErr.stderr ? signErr.stderr.toString() : '').trim().split('\n')[0];
          reason = 'Подпись браузера нарушена' + (detail ? ': ' + detail : '') + '.';
        }
      }

      throw new Error(
        'Браузер запустился и сразу закрылся. ' + reason +
        ' Откройте папку проекта в Терминале и выполните: npm run doctor — команда покажет точную причину.'
      );
    }
    throw err;
  }

  await context.addInitScript(buildInjectScript(fp));

  /* Подставляем сохранённые куки профиля до открытия страниц */
  const saved = cookieStore.readStore(dataRoot, profile.id);
  if (saved.length) {
    await context.addCookies(saved).catch(() => undefined);
  }

  const pages = context.pages();
  const page = pages.length ? pages[0] : await context.newPage();

  /*
   * Часть параметров задаём на уровне самого движка. Так они одинаковы
   * в окне, в рамках, в воркерах и в заголовках запросов — расхождений,
   * по которым обычно и ловят, не остаётся.
   */
  const engine = await applyEngineOverrides(page, fp).catch(() => ({ ok: false }));

  /* Новые вкладки должны получать те же настройки */
  context.on('page', (fresh) => {
    applyEngineOverrides(fresh, fp).catch(() => undefined);
  });

  await page.goto('https://browserleaks.com/canvas').catch(() => undefined);

  context.on('close', () => {
    const session = sessions.get(profile.id);
    if (session && session.timer) clearInterval(session.timer);
    sessions.delete(profile.id);
    if (onClose) onClose(profile.id);
  });

  /*
   * Куки сохраняем на ходу: раз в 20 секунд и перед остановкой.
   * Читать их после закрытия контекста уже нельзя — окно недоступно.
   */
  const snapshot = async () => {
    try {
      const fresh = await context.cookies();
      if (fresh && fresh.length) cookieStore.writeStore(dataRoot, profile.id, fresh);
    } catch (e) { /* окно закрыто */ }
  };

  const timer = setInterval(snapshot, 20000);
  sessions.set(profile.id, {
    context,
    fingerprint: fp,
    startedAt: Date.now(),
    snapshot,
    timer,
  });

  return { fingerprint: fp, cookies: saved.length, engine: engine && engine.applied };
}

async function stopProfile(id) {
  const session = sessions.get(id);
  if (!session) return false;
  sessions.delete(id);
  if (session.timer) clearInterval(session.timer);
  if (session.snapshot) await session.snapshot();
  await session.context.close().catch(() => undefined);
  return true;
}

async function audit(id, siteId) {
  const session = sessions.get(id);
  if (!session) return { ok: false, error: 'Сначала запустите профиль' };
  try {
    const report = await auditProfile(session, siteId);
    return { ok: true, ...report };
  } catch (error) {
    return { ok: false, error: String((error && error.message) || error) };
  }
}

const isRunning = (id) => sessions.has(id);
const runningIds = () => [...sessions.keys()];

async function stopAll() {
  await Promise.all([...sessions.keys()].map(stopProfile));
}

module.exports = { launchProfile, stopProfile, audit, isRunning, runningIds, stopAll };
