/*
 * Подмена на уровне движка браузера, а не скриптом на странице.
 * Скрипт можно поймать по следам, а эти значения браузер считает своими:
 * они одинаковы в главном окне, во вложенных рамках, в воркерах и в
 * заголовках сетевых запросов. Часть параметров иначе подменить нельзя.
 */

const applyEngineOverrides = async (page, fp) => {
  let session = null;
  try {
    session = await page.context().newCDPSession(page);
  } catch (e) {
    return { ok: false, error: 'Движок не принял настройки' };
  }

  const applied = [];
  const send = async (method, params, label) => {
    try {
      await session.send(method, params);
      applied.push(label);
      return true;
    } catch (e) {
      return false;
    }
  };

  /*
   * User-Agent вместе с Client Hints. Задаём здесь, а не в JS — тогда
   * заголовки Sec-CH-UA в запросах совпадают с тем, что видит страница.
   * Расхождение между ними — типовая проверка антифрода.
   */
  await send('Emulation.setUserAgentOverride', {
    userAgent: fp.userAgent,
    acceptLanguage: fp.languages.join(','),
    platform: fp.platform,
    userAgentMetadata: {
      brands: fp.uaData.brands,
      fullVersionList: fp.uaData.brands.map((b) => ({
        brand: b.brand,
        version: fp.chromeVersion,
      })),
      fullVersion: fp.chromeVersion,
      platform: fp.uaData.platform,
      platformVersion: fp.uaData.platformVersion,
      architecture: fp.uaData.architecture,
      model: fp.uaData.model || '',
      mobile: false,
      bitness: fp.uaData.bitness,
      wow64: false,
    },
  }, 'user-agent');

  /*
   * Число ядер на уровне движка. Это единственный способ, при котором
   * значение совпадает и в окне, и в воркерах без дополнительных патчей.
   */
  await send('Emulation.setHardwareConcurrencyOverride', {
    hardwareConcurrency: fp.hardwareConcurrency,
  }, 'ядра');

  /*
   * Плотность пикселей. Задаём здесь, а не при запуске браузера:
   * в параметрах запуска вместе с окном во весь экран она ломает старт.
   * Размеры окна не трогаем — отсюда нули в width и height.
   */
  if (fp.screen.pixelRatio && fp.screen.pixelRatio !== 1) {
    await send('Emulation.setDeviceMetricsOverride', {
      width: 0,
      height: 0,
      deviceScaleFactor: fp.screen.pixelRatio,
      mobile: false,
    }, 'плотность пикселей');
  }

  /* Часовой пояс. Влияет и на Date, и на Intl — подделать в JS полностью нельзя */
  await send('Emulation.setTimezoneOverride', {
    timezoneId: fp.timezone,
  }, 'часовой пояс');

  /* Язык интерфейса движка */
  await send('Emulation.setLocaleOverride', {
    locale: fp.locale,
  }, 'локаль');

  /* Тёмная тема и тип экрана — читаются через media-запросы */
  await send('Emulation.setEmulatedMedia', {
    media: 'screen',
    features: [
      { name: 'prefers-color-scheme', value: fp.darkMode ? 'dark' : 'light' },
      { name: 'prefers-reduced-motion', value: 'no-preference' },
      { name: 'prefers-contrast', value: 'no-preference' },
      { name: 'forced-colors', value: 'none' },
    ],
  }, 'тема');

  /* Отключаем определение автоматизации на уровне страницы */
  await send('Page.setBypassCSP', { enabled: false }, 'csp');

  return { ok: applied.length > 0, applied };
};

/*
 * Скрипт подмены должен исполняться раньше кода сайта и в каждой рамке.
 * Через протокол это надёжнее: скрипт попадает и в те рамки, которые
 * страница создаёт уже после загрузки.
 */
const injectEverywhere = async (page, script) => {
  try {
    const session = await page.context().newCDPSession(page);
    await session.send('Page.addScriptToEvaluateOnNewDocument', {
      source: script,
      runImmediately: true,
    });
    return true;
  } catch (e) {
    return false;
  }
};

module.exports = { applyEngineOverrides, injectEverywhere };
