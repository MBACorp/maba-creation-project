const http = require('http');
const https = require('https');
const net = require('net');
const tls = require('tls');
const { URL } = require('url');

/*
 * Проверка прокси до запуска профиля. Обычная библиотека тянет зависимости,
 * поэтому туннель поднимаем вручную: для HTTP через метод CONNECT,
 * для SOCKS5 — рукопожатием по протоколу.
 */

const TIMEOUT = 12000;
const IP_HOST = 'ipwho.is';
const IP_PATH = '/?fields=ip,country,country_code,city,type,connection';

const parseHost = (raw) => {
  const value = String(raw || '').trim();
  const at = value.lastIndexOf('@');
  const hostPart = at >= 0 ? value.slice(at + 1) : value;
  const idx = hostPart.lastIndexOf(':');
  if (idx < 0) return { host: hostPart, port: 8080 };
  return {
    host: hostPart.slice(0, idx),
    port: parseInt(hostPart.slice(idx + 1), 10) || 8080,
  };
};

/* Туннель через HTTP-прокси методом CONNECT */
function connectHttp(proxy, target, cb) {
  const { host, port } = parseHost(proxy.proxyHost);
  const socket = net.connect({ host, port });
  let done = false;
  const finish = (err, sock) => {
    if (done) return;
    done = true;
    cb(err, sock);
  };

  socket.setTimeout(TIMEOUT, () => {
    socket.destroy();
    finish(new Error('Прокси не отвечает'));
  });

  socket.on('error', (e) => finish(new Error(readableError(e))));

  socket.on('connect', () => {
    let req = `CONNECT ${target.host}:${target.port} HTTP/1.1\r\n`;
    req += `Host: ${target.host}:${target.port}\r\n`;
    if (proxy.proxyUser) {
      const token = Buffer.from(`${proxy.proxyUser}:${proxy.proxyPass || ''}`).toString('base64');
      req += `Proxy-Authorization: Basic ${token}\r\n`;
    }
    req += 'Connection: keep-alive\r\n\r\n';
    socket.write(req);
  });

  let buffer = Buffer.alloc(0);
  const onData = (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    const end = buffer.indexOf('\r\n\r\n');
    if (end < 0) return;
    socket.removeListener('data', onData);
    const head = buffer.slice(0, end).toString();
    const code = parseInt((head.split(' ')[1] || '0'), 10);
    if (code === 200) {
      socket.setTimeout(0);
      finish(null, socket);
    } else if (code === 407) {
      socket.destroy();
      finish(new Error('Прокси отклонил логин или пароль'));
    } else {
      socket.destroy();
      finish(new Error(`Прокси ответил кодом ${code || '—'}`));
    }
  };
  socket.on('data', onData);
}

/* Рукопожатие SOCKS5: приветствие, при необходимости логин, затем запрос */
function connectSocks(proxy, target, cb) {
  const { host, port } = parseHost(proxy.proxyHost);
  const socket = net.connect({ host, port });
  let done = false;
  let stage = 'greeting';
  const finish = (err, sock) => {
    if (done) return;
    done = true;
    cb(err, sock);
  };

  socket.setTimeout(TIMEOUT, () => {
    socket.destroy();
    finish(new Error('Прокси не отвечает'));
  });
  socket.on('error', (e) => finish(new Error(readableError(e))));

  socket.on('connect', () => {
    const methods = proxy.proxyUser ? [0x00, 0x02] : [0x00];
    socket.write(Buffer.from([0x05, methods.length, ...methods]));
  });

  const sendRequest = () => {
    stage = 'request';
    const hostBuf = Buffer.from(target.host);
    const buf = Buffer.alloc(7 + hostBuf.length);
    buf[0] = 0x05;
    buf[1] = 0x01;
    buf[2] = 0x00;
    buf[3] = 0x03;
    buf[4] = hostBuf.length;
    hostBuf.copy(buf, 5);
    buf.writeUInt16BE(target.port, 5 + hostBuf.length);
    socket.write(buf);
  };

  const onData = (data) => {
    if (stage === 'greeting') {
      if (data[0] !== 0x05) {
        socket.destroy();
        return finish(new Error('Это не SOCKS5-прокси'));
      }
      if (data[1] === 0x02) {
        stage = 'auth';
        const user = Buffer.from(proxy.proxyUser || '');
        const pass = Buffer.from(proxy.proxyPass || '');
        const buf = Buffer.alloc(3 + user.length + pass.length);
        buf[0] = 0x01;
        buf[1] = user.length;
        user.copy(buf, 2);
        buf[2 + user.length] = pass.length;
        pass.copy(buf, 3 + user.length);
        socket.write(buf);
        return undefined;
      }
      if (data[1] === 0xff) {
        socket.destroy();
        return finish(new Error('Прокси требует логин и пароль'));
      }
      return sendRequest();
    }

    if (stage === 'auth') {
      if (data[1] !== 0x00) {
        socket.destroy();
        return finish(new Error('Прокси отклонил логин или пароль'));
      }
      return sendRequest();
    }

    if (stage === 'request') {
      socket.removeListener('data', onData);
      const code = data[1];
      if (code !== 0x00) {
        const reasons = {
          0x01: 'Внутренняя ошибка прокси',
          0x02: 'Прокси запретил соединение',
          0x03: 'Сеть недоступна',
          0x04: 'Узел недоступен',
          0x05: 'Соединение отклонено',
          0x06: 'Истекло время жизни пакета',
          0x07: 'Команда не поддерживается',
          0x08: 'Тип адреса не поддерживается',
        };
        socket.destroy();
        return finish(new Error(reasons[code] || 'Прокси отклонил соединение'));
      }
      socket.setTimeout(0);
      return finish(null, socket);
    }
    return undefined;
  };
  socket.on('data', onData);
}

const readableError = (e) => {
  const code = e && e.code;
  if (code === 'ECONNREFUSED') return 'Порт закрыт или прокси выключен';
  if (code === 'ENOTFOUND') return 'Адрес прокси не найден';
  if (code === 'ETIMEDOUT') return 'Прокси не отвечает';
  if (code === 'ECONNRESET') return 'Прокси разорвал соединение';
  if (code === 'EHOSTUNREACH') return 'Узел недоступен';
  return (e && e.message) || 'Не удалось подключиться';
};

/* Запрос сведений об IP через установленный туннель */
function fetchThroughTunnel(socket, cb) {
  const secure = tls.connect({ socket, servername: IP_HOST, rejectUnauthorized: false });
  let body = '';
  let done = false;
  const finish = (err, data) => {
    if (done) return;
    done = true;
    try { secure.destroy(); } catch (e) {}
    cb(err, data);
  };

  const timer = setTimeout(() => finish(new Error('Прокси слишком медленный')), TIMEOUT);

  secure.on('error', (e) => {
    clearTimeout(timer);
    finish(new Error(readableError(e)));
  });

  secure.on('secureConnect', () => {
    secure.write(
      `GET ${IP_PATH} HTTP/1.1\r\nHost: ${IP_HOST}\r\n`
      + 'User-Agent: Mozilla/5.0\r\nAccept: application/json\r\nConnection: close\r\n\r\n',
    );
  });

  secure.on('data', (chunk) => { body += chunk.toString(); });

  secure.on('end', () => {
    clearTimeout(timer);
    const split = body.indexOf('\r\n\r\n');
    let payload = split >= 0 ? body.slice(split + 4) : body;
    /* Ответ может прийти кусками с указанием длины — собираем их */
    if (/transfer-encoding:\s*chunked/i.test(body.slice(0, Math.max(split, 0)))) {
      let rest = payload;
      let out = '';
      while (rest.length) {
        const nl = rest.indexOf('\r\n');
        if (nl < 0) break;
        const size = parseInt(rest.slice(0, nl).trim(), 16);
        if (!size || Number.isNaN(size)) break;
        out += rest.substr(nl + 2, size);
        rest = rest.slice(nl + 2 + size + 2);
      }
      payload = out;
    }
    const start = payload.indexOf('{');
    if (start < 0) return finish(new Error('Прокси вернул неожиданный ответ'));
    try {
      return finish(null, JSON.parse(payload.slice(start)));
    } catch (e) {
      return finish(new Error('Прокси вернул неожиданный ответ'));
    }
  });
}

/*
 * Основная проверка. Возвращает живой ли прокси, внешний IP, страну,
 * город, тип соединения и задержку в миллисекундах.
 */
function checkProxy(proxy) {
  return new Promise((resolve) => {
    if (!proxy || !proxy.proxyHost) {
      return resolve({ ok: false, error: 'Не указан адрес прокси' });
    }

    const { host, port } = parseHost(proxy.proxyHost);
    if (!host || !port) {
      return resolve({ ok: false, error: 'Адрес нужно указать в виде host:port' });
    }

    const scheme = String(proxy.proxyType || 'socks5').toLowerCase();
    const started = Date.now();
    const target = { host: IP_HOST, port: 443 };
    const connect = scheme.startsWith('socks') ? connectSocks : connectHttp;

    let settled = false;
    const done = (result) => {
      if (settled) return;
      settled = true;
      resolve(result);
    };

    const guard = setTimeout(() => done({ ok: false, error: 'Прокси не ответил за 15 секунд' }), 15000);

    connect(proxy, target, (err, socket) => {
      if (err) {
        clearTimeout(guard);
        return done({ ok: false, error: err.message });
      }
      const connectMs = Date.now() - started;
      return fetchThroughTunnel(socket, (err2, data) => {
        clearTimeout(guard);
        if (err2) return done({ ok: false, error: err2.message });
        if (!data || !data.ip) return done({ ok: false, error: 'Не удалось определить IP' });
        return done({
          ok: true,
          ip: data.ip,
          country: data.country || '',
          countryCode: data.country_code || '',
          city: data.city || '',
          kind: data.type === 'IPv6' ? 'IPv6' : 'IPv4',
          provider: (data.connection && data.connection.isp) || '',
          latency: connectMs,
          total: Date.now() - started,
        });
      });
    });
  });
}

/* Свой IP без прокси — нужен, чтобы поймать прокси, который не меняет адрес */
function ownIp() {
  return new Promise((resolve) => {
    const req = https.get(
      { host: IP_HOST, path: '/?fields=ip', timeout: 8000 },
      (res) => {
        let body = '';
        res.on('data', (c) => { body += c; });
        res.on('end', () => {
          try {
            resolve(JSON.parse(body).ip || null);
          } catch (e) {
            resolve(null);
          }
        });
      },
    );
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

module.exports = { checkProxy, ownIp, parseHost };
