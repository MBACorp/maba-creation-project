/*
 * Раскладка окон браузеров по экрану.
 *
 * Когда профилей запускают пачкой, окна встают одно на другое и
 * работать невозможно. Здесь считаем сетку: делим рабочую область
 * экрана на ячейки и выдаём каждому окну свои координаты и размер.
 *
 * Важно для маскировки: положение окна на экране сайтам не видно,
 * а вот его РАЗМЕР виден. Поэтому размер ячейки мы подставляем
 * только в само окно, а в отпечатке профиля остаётся его собственное
 * разрешение экрана — иначе у всех профилей совпали бы размеры, и
 * это стало бы общей приметой.
 */

/* Минимальный размер, при котором сайтом ещё можно пользоваться */
const MIN_W = 420;
const MIN_H = 330;

/*
 * Подбираем сетку: сколько колонок и рядов нужно для N окон,
 * чтобы ячейки были как можно ближе к квадрату экрана.
 */
function pickGrid(count, areaW, areaH) {
  if (count <= 1) return { cols: 1, rows: 1 };

  let best = null;

  for (let cols = 1; cols <= count; cols += 1) {
    const rows = Math.ceil(count / cols);
    const w = Math.floor(areaW / cols);
    const h = Math.floor(areaH / rows);

    /* Слишком мелкие ячейки не рассматриваем */
    if (w < MIN_W || h < MIN_H) continue;

    /* Чем ближе ячейка к пропорциям экрана, тем аккуратнее выглядит */
    const target = areaW / areaH;
    const ratio = w / h;
    const penalty = Math.abs(Math.log(ratio / target));

    if (!best || penalty < best.penalty) best = { cols, rows, penalty };
  }

  /* Ничего не подошло — экран мал для такого количества окон */
  if (!best) {
    const cols = Math.ceil(Math.sqrt(count));
    return { cols, rows: Math.ceil(count / cols), tight: true };
  }

  return { cols: best.cols, rows: best.rows };
}

/*
 * Координаты одного окна. index — номер окна по порядку (с нуля),
 * count — сколько всего окон раскладываем.
 */
function tileFor(index, count, area) {
  const areaW = area.width;
  const areaH = area.height;
  const grid = pickGrid(count, areaW, areaH);

  const col = index % grid.cols;
  const row = Math.floor(index / grid.cols) % grid.rows;

  let width = Math.floor(areaW / grid.cols);
  let height = Math.floor(areaH / grid.rows);

  let x = area.x + col * width;
  let y = area.y + row * height;

  /*
   * Окон больше, чем ячеек: лишние кладём поверх со сдвигом,
   * чтобы заголовки были видны и окна можно было растащить мышью.
   */
  const cells = grid.cols * grid.rows;
  if (index >= cells) {
    const extra = Math.floor(index / cells);
    x += extra * 28;
    y += extra * 28;
  }

  /*
   * Экран мал для такого числа окон. Сетка тут не поможет — окна стали бы
   * нечитаемо мелкими. Раскладываем лесенкой: размер рабочий, заголовки
   * видны, любое окно можно вытащить мышью.
   */
  if (grid.tight) {
    width = Math.max(width, MIN_W);
    height = Math.max(height, MIN_H);

    const stepX = Math.max(24, Math.floor((areaW - width) / Math.max(count - 1, 1)));
    const stepY = Math.max(22, Math.floor((areaH - height) / Math.max(count - 1, 1)));

    x = area.x + index * stepX;
    y = area.y + index * stepY;
  }

  /* Не выпускаем окно за пределы экрана */
  const maxX = area.x + areaW - width;
  const maxY = area.y + areaH - height;

  return {
    x: Math.max(area.x, Math.min(x, maxX)),
    y: Math.max(area.y, Math.min(y, maxY)),
    width,
    height,
    cols: grid.cols,
    rows: grid.rows,
  };
}

module.exports = { tileFor, pickGrid };
