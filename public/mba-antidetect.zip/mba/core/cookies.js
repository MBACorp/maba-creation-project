const fs = require('fs');
const path = require('path');

/*
 * Куки профиля хранятся отдельным файлом и подставляются в браузер при запуске.
 * Поддерживаются два формата: JSON (как у большинства антидетектов и расширений)
 * и Netscape cookies.txt (классический формат curl/wget).
 */

const cookiesFile = (dataRoot, profileId) =>
  path.join(dataRoot, 'profiles', profileId, 'cookies.json');

const readStore = (dataRoot, profileId) => {
  try {
    const raw = fs.readFileSync(cookiesFile(dataRoot, profileId), 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
};

const writeStore = (dataRoot, profileId, cookies) => {
  const file = cookiesFile(dataRoot, profileId);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(cookies, null, 2), 'utf8');
  return cookies;
};

const normalizeSameSite = (value) => {
  const v = String(value || '').toLowerCase();
  if (v === 'lax') return 'Lax';
  if (v === 'strict') return 'Strict';
  if (v === 'none' || v === 'no_restriction') return 'None';
  return 'Lax';
};

/* Приводим куки любого вида к единому формату Playwright */
const normalizeCookie = (raw) => {
  if (!raw || !raw.name) return null;

  const domain = String(raw.domain || raw.host || '').trim();
  if (!domain) return null;

  const expires =
    raw.expirationDate || raw.expires || raw.expiry || raw.expires_utc || 0;

  return {
    name: String(raw.name),
    value: String(raw.value == null ? '' : raw.value),
    domain,
    path: raw.path || '/',
    expires: expires ? Math.floor(Number(expires)) : -1,
    httpOnly: Boolean(raw.httpOnly || raw.http_only),
    secure: Boolean(raw.secure),
    sameSite: normalizeSameSite(raw.sameSite || raw.same_site),
  };
};

/* Формат Netscape: домен, флаг поддоменов, путь, secure, срок, имя, значение */
const parseNetscape = (text) => {
  const out = [];
  text.split(/\r?\n/).forEach((line) => {
    const clean = line.trim();
    if (!clean || (clean.startsWith('#') && !clean.startsWith('#HttpOnly_'))) return;

    let row = clean;
    let httpOnly = false;
    if (row.startsWith('#HttpOnly_')) {
      httpOnly = true;
      row = row.slice('#HttpOnly_'.length);
    }

    const parts = row.split('\t');
    if (parts.length < 7) return;

    const [domain, , cookiePath, secure, expires, name, ...valueParts] = parts;
    out.push(
      normalizeCookie({
        domain,
        path: cookiePath,
        secure: String(secure).toUpperCase() === 'TRUE',
        expirationDate: Number(expires) || 0,
        name,
        value: valueParts.join('\t'),
        httpOnly,
      }),
    );
  });
  return out.filter(Boolean);
};

const parseJson = (text) => {
  const data = JSON.parse(text);
  const list = Array.isArray(data) ? data : data.cookies || data.data || [];
  if (!Array.isArray(list)) throw new Error('В файле нет списка куки');
  return list.map(normalizeCookie).filter(Boolean);
};

function parseCookies(text) {
  const trimmed = String(text || '').trim();
  if (!trimmed) throw new Error('Файл пустой');

  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    return parseJson(trimmed);
  }
  const netscape = parseNetscape(trimmed);
  if (!netscape.length) throw new Error('Формат файла не распознан');
  return netscape;
}

/* Сводка по доменам для показа в интерфейсе */
function summarize(cookies) {
  const map = new Map();
  const now = Date.now() / 1000;

  cookies.forEach((c) => {
    const domain = c.domain.replace(/^\./, '');
    const item = map.get(domain) || { domain, count: 0, expired: 0, session: 0 };
    item.count += 1;
    if (c.expires === -1 || !c.expires) item.session += 1;
    else if (c.expires < now) item.expired += 1;
    map.set(domain, item);
  });

  return {
    total: cookies.length,
    domains: [...map.values()].sort((a, b) => b.count - a.count || a.domain.localeCompare(b.domain)),
  };
}

const toNetscape = (cookies) => {
  const lines = ['# Netscape HTTP Cookie File', '# Экспортировано из MBA', ''];
  cookies.forEach((c) => {
    const prefix = c.httpOnly ? '#HttpOnly_' : '';
    const includeSub = c.domain.startsWith('.') ? 'TRUE' : 'FALSE';
    lines.push(
      [
        prefix + c.domain,
        includeSub,
        c.path || '/',
        c.secure ? 'TRUE' : 'FALSE',
        c.expires > 0 ? String(c.expires) : '0',
        c.name,
        c.value,
      ].join('\t'),
    );
  });
  return lines.join('\n');
};

module.exports = {
  readStore,
  writeStore,
  parseCookies,
  summarize,
  toNetscape,
  normalizeCookie,
  cookiesFile,
};
