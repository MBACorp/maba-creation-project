const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
const { spawn } = require('child_process');

/*
 * Автообновление: приложение само спрашивает сервер о новой версии,
 * скачивает установщик, проверяет целостность и запускает его.
 * Пользователю остаётся только подтвердить.
 */

const platformKey = () => (process.platform === 'darwin' ? 'macos' : 'windows');
const archKey = () => (process.arch === 'arm64' ? 'arm64' : 'x64');

const getJson = (url, redirects = 0) =>
  new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Слишком много переадресаций'));

    /* GitHub отклоняет запросы без User-Agent */
    const options = {
      timeout: 15000,
      headers: { 'User-Agent': 'MBA-Updater', Accept: 'application/vnd.github+json' },
    };

    https
      .get(url, options, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          return resolve(getJson(res.headers.location, redirects + 1));
        }

        if (res.statusCode === 404) {
          res.resume();
          return reject(new Error('Обновлений пока нет: не опубликовано ни одного выпуска'));
        }

        if (res.statusCode === 403) {
          res.resume();
          return reject(new Error('GitHub временно ограничил частоту проверок, попробуйте позже'));
        }

        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error('Сервер обновлений вернул код ' + res.statusCode));
        }

        let raw = '';
        res.on('data', (c) => { raw += c; });
        res.on('end', () => {
          try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('Ответ сервера обновлений непонятен')); }
        });
      })
      .on('error', reject)
      .on('timeout', function () { this.destroy(new Error('Сервер обновлений не отвечает')); });
  });

/* Сравнение версий вида 1.0.10 — по числам, а не по алфавиту */
function isNewer(candidate, current) {
  const parse = (v) => String(v).replace(/^v/, '').split('.').map((n) => parseInt(n, 10) || 0);
  const a = parse(candidate);
  const b = parse(current);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const x = a[i] || 0;
    const y = b[i] || 0;
    if (x !== y) return x > y;
  }
  return false;
}

/* Скачивание с отслеживанием прогресса и поддержкой переадресаций */
function download(url, destination, onProgress, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Слишком много переадресаций'));

    const file = fs.createWriteStream(destination);
    const request = https.get(url, { timeout: 60000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        fs.unlink(destination, () => undefined);
        return resolve(download(res.headers.location, destination, onProgress, redirects + 1));
      }

      if (res.statusCode !== 200) {
        file.close();
        fs.unlink(destination, () => undefined);
        return reject(new Error(`Сервер вернул код ${res.statusCode}`));
      }

      const total = Number(res.headers['content-length'] || 0);
      let loaded = 0;
      let lastPercent = -1;

      res.on('data', (chunk) => {
        loaded += chunk.length;
        if (!total || !onProgress) return;
        const percent = Math.floor((loaded / total) * 100);
        if (percent !== lastPercent) {
          lastPercent = percent;
          onProgress({ percent, loaded, total });
        }
      });

      res.pipe(file);
      file.on('finish', () => file.close(() => resolve({ path: destination, size: loaded })));
    });

    request.on('error', (error) => {
      file.close();
      fs.unlink(destination, () => undefined);
      reject(error);
    });

    request.on('timeout', () => request.destroy(new Error('Загрузка прервана по времени')));
  });
}

const sha256File = (file) =>
  new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(file);
    stream.on('data', (d) => hash.update(d));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });

/*
 * Проверка обновлений через GitHub Releases.
 * Берём последний выпуск и ищем в нём файл для текущей системы:
 * на macOS это .dmg, на Windows — .exe.
 */
async function checkUpdate(source, currentVersion) {
  const repo = String(source || '').trim();
  if (!repo) throw new Error('Не указан репозиторий с обновлениями');

  const api = repo.startsWith('http')
    ? repo
    : `https://api.github.com/repos/${repo}/releases/latest`;

  const release = await getJson(api);

  if (release.draft) {
    return { available: false, current: currentVersion };
  }

  const version = String(release.tag_name || release.name || '').replace(/^v/, '');
  if (!version) return { available: false, current: currentVersion };

  if (!isNewer(version, currentVersion)) {
    return { available: false, current: currentVersion, latest: version };
  }

  const wanted = process.platform === 'darwin' ? '.dmg' : '.exe';
  const assets = Array.isArray(release.assets) ? release.assets : [];

  /* Для Apple-процессоров предпочитаем сборку arm64, если она есть */
  const matching = assets.filter((a) => String(a.name || '').toLowerCase().endsWith(wanted));
  const preferred =
    matching.find((a) => String(a.name).toLowerCase().includes(archKey())) || matching[0];

  if (!preferred) {
    throw new Error(
      'Выпуск ' + version + ' найден, но в нём нет файла для вашей системы (' + wanted + ')'
    );
  }

  return {
    available: true,
    version,
    fileName: preferred.name,
    fileUrl: preferred.browser_download_url,
    fileSize: preferred.size,
    notes: release.body ? String(release.body).slice(0, 700) : '',
    mandatory: false,
  };
}

async function downloadUpdate(info, onProgress) {
  const dir = path.join(os.tmpdir(), 'mba-updates');
  fs.mkdirSync(dir, { recursive: true });

  const target = path.join(dir, info.fileName || `MBA-${info.version}`);

  /* Если файл уже скачан и целый — не качаем заново */
  if (fs.existsSync(target) && info.sha256) {
    const existing = await sha256File(target).catch(() => null);
    if (existing === info.sha256) return { path: target, cached: true };
  }

  const result = await download(info.fileUrl, target, onProgress);

  if (info.sha256) {
    const actual = await sha256File(target);
    if (actual !== info.sha256) {
      fs.unlink(target, () => undefined);
      throw new Error('Файл повреждён при загрузке. Попробуйте ещё раз.');
    }
  }

  return { path: result.path, cached: false };
}

/*
 * Запуск установщика. На Windows открываем .exe и закрываем приложение,
 * на macOS монтируем .dmg и показываем окно с приложением.
 */
function runInstaller(filePath, app) {
  if (process.platform === 'darwin') {
    /*
     * Приложение собрано без сертификата Apple, поэтому macOS вешает на
     * скачанный образ метку карантина и отказывается его открывать.
     * Снимаем метку — иначе пользователь увидит «файл повреждён».
     */
    try {
      require('child_process').execSync(`xattr -cr "${filePath}"`, { stdio: 'ignore' });
    } catch (e) {
      /* Метки могло и не быть — это нормально */
    }

    spawn('open', [filePath], { detached: true, stdio: 'ignore' }).unref();
    setTimeout(() => app.quit(), 1200);
    return;
  }

  spawn(filePath, [], { detached: true, stdio: 'ignore', shell: false }).unref();
  setTimeout(() => app.quit(), 800);
}

module.exports = {
  checkUpdate,
  downloadUpdate,
  runInstaller,
  platformKey,
  archKey,
};
