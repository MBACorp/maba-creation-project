const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
const { spawn } = require('child_process');

/*
 * Автообновление: приложение само спрашивает сервер о новой версии,
 * скачивает установщик, проверяет целостность и запускает его.
 * Пользователю остаётся только подтвердить.
 */

const platformKey = () => (process.platform === 'darwin' ? 'macos' : 'windows');
const archKey = () => (process.arch === 'arm64' ? 'arm64' : 'x64');

const getJson = (url) =>
  new Promise((resolve, reject) => {
    https
      .get(url, { timeout: 15000 }, (res) => {
        let raw = '';
        res.on('data', (c) => { raw += c; });
        res.on('end', () => {
          try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
        });
      })
      .on('error', reject)
      .on('timeout', function () { this.destroy(new Error('Сервер обновлений не отвечает')); });
  });

/* Скачивание с отслеживанием прогресса и поддержкой переадресаций */
function download(url, destination, onProgress, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error('Слишком много переадресаций'));

    const file = fs.createWriteStream(destination);
    const request = https.get(url, { timeout: 60000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        fs.unlink(destination, () => undefined);
        return resolve(download(res.headers.location, destination, onProgress, redirects + 1));
      }

      if (res.statusCode !== 200) {
        file.close();
        fs.unlink(destination, () => undefined);
        return reject(new Error(`Сервер вернул код ${res.statusCode}`));
      }

      const total = Number(res.headers['content-length'] || 0);
      let loaded = 0;
      let lastPercent = -1;

      res.on('data', (chunk) => {
        loaded += chunk.length;
        if (!total || !onProgress) return;
        const percent = Math.floor((loaded / total) * 100);
        if (percent !== lastPercent) {
          lastPercent = percent;
          onProgress({ percent, loaded, total });
        }
      });

      res.pipe(file);
      file.on('finish', () => file.close(() => resolve({ path: destination, size: loaded })));
    });

    request.on('error', (error) => {
      file.close();
      fs.unlink(destination, () => undefined);
      reject(error);
    });

    request.on('timeout', () => request.destroy(new Error('Загрузка прервана по времени')));
  });
}

const sha256File = (file) =>
  new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(file);
    stream.on('data', (d) => hash.update(d));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });

async function checkUpdate(releasesUrl, currentVersion) {
  const url =
    `${releasesUrl}?action=check&platform=${platformKey()}` +
    `&arch=${archKey()}&version=${encodeURIComponent(currentVersion)}`;
  return getJson(url);
}

async function downloadUpdate(info, onProgress) {
  const dir = path.join(os.tmpdir(), 'mba-updates');
  fs.mkdirSync(dir, { recursive: true });

  const target = path.join(dir, info.fileName || `MBA-${info.version}`);

  /* Если файл уже скачан и целый — не качаем заново */
  if (fs.existsSync(target) && info.sha256) {
    const existing = await sha256File(target).catch(() => null);
    if (existing === info.sha256) return { path: target, cached: true };
  }

  const result = await download(info.fileUrl, target, onProgress);

  if (info.sha256) {
    const actual = await sha256File(target);
    if (actual !== info.sha256) {
      fs.unlink(target, () => undefined);
      throw new Error('Файл повреждён при загрузке. Попробуйте ещё раз.');
    }
  }

  return { path: result.path, cached: false };
}

/*
 * Запуск установщика. На Windows открываем .exe и закрываем приложение,
 * на macOS монтируем .dmg и показываем окно с приложением.
 */
function runInstaller(filePath, app) {
  if (process.platform === 'darwin') {
    spawn('open', [filePath], { detached: true, stdio: 'ignore' }).unref();
    setTimeout(() => app.quit(), 1200);
    return;
  }

  spawn(filePath, [], { detached: true, stdio: 'ignore', shell: false }).unref();
  setTimeout(() => app.quit(), 800);
}

module.exports = {
  checkUpdate,
  downloadUpdate,
  runInstaller,
  platformKey,
  archKey,
};
