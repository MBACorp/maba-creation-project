/*
 * Бот прогрева профиля.
 *
 * Открывает в профиле сайты из списка, читает их как человек — со
 * скроллом, паузами и переходами по внутренним ссылкам — и копит куки.
 *
 * Зачем медленно: профиль, обежавший полсотни сайтов за минуту, выглядит
 * подозрительнее пустого. Поэтому темп неспешный, паузы случайные, а
 * порядок сайтов каждый раз новый.
 *
 * Прогрев НЕ создаёт доверие сам по себе. Он лишь убирает приметы
 * пустого профиля: историю, куки, локальное хранилище.
 */

const rnd = (min, max) => min + Math.random() * (max - min);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

/*
 * Пользователь вводит адреса как удобно: "ozon.ru", "ozon,ru",
 * "https://ozon.ru/", "www.ozon.ru". Приводим к рабочей ссылке.
 */
function normalizeSite(raw) {
  let s = String(raw || '').trim().toLowerCase();
  if (!s) return null;

  /* Запятая вместо точки — частая привычка при вводе списка */
  s = s.replace(/\s+/g, '');
  if (!s.includes('.') && s.includes(',')) s = s.replace(/,/g, '.');

  s = s.replace(/^https?:\/\//, '').replace(/\/+$/, '');
  if (!s || !s.includes('.')) return null;
  if (!/^[a-z0-9.\-/_а-яё]+$/i.test(s)) return null;

  return 'https://' + s;
}

/* Разбираем строку со списком: запятые как разделитель, переносы строк тоже */
function parseSites(input) {
  const raw = Array.isArray(input) ? input : String(input || '').split(/[\n;]+/);

  const out = [];
  for (const chunk of raw) {
    const line = String(chunk).trim();
    if (!line) continue;

    /*
     * "ozon,ru" — это один адрес, а "ozon.ru, avito.ru" — два.
     * Отличаем по наличию точек: если точка уже есть, запятая разделяет.
     */
    const parts = line.includes('.') ? line.split(',') : [line];
    for (const p of parts) {
      const url = normalizeSite(p);
      if (url && !out.includes(url)) out.push(url);
    }
  }
  return out;
}

/* Перемешиваем список — одинаковый порядок обхода сам по себе примета */
function shuffle(list) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/*
 * Плавная прокрутка. Живой человек листает рывками с остановками,
 * а не телепортируется в конец страницы.
 */
async function humanScroll(page, seconds) {
  const until = Date.now() + seconds * 1000;

  while (Date.now() < until) {
    const step = Math.round(rnd(250, 700));

    await page
      .evaluate((dy) => window.scrollBy({ top: dy, behavior: 'smooth' }), step)
      .catch(() => undefined);

    await wait(rnd(900, 2600));

    /* Иногда человек возвращается назад — перечитать абзац */
    if (Math.random() < 0.2) {
      await page
        .evaluate(() => window.scrollBy({ top: -220, behavior: 'smooth' }))
        .catch(() => undefined);
      await wait(rnd(700, 1600));
    }
  }
}

/* Двигаем мышь по странице: без движений курсора поведение выглядит машинным */
async function moveMouse(page) {
  const box = page.viewportSize() || { width: 1200, height: 800 };
  const steps = Math.round(rnd(2, 5));

  for (let i = 0; i < steps; i += 1) {
    await page.mouse
      .move(rnd(60, box.width - 60), rnd(60, box.height - 60), { steps: Math.round(rnd(8, 22)) })
      .catch(() => undefined);
    await wait(rnd(200, 800));
  }
}

/*
 * Переход по внутренней ссылке. Именно переходы вглубь сайта дают
 * настоящие куки сессии — от одной главной страницы их почти нет.
 */
async function followInnerLink(page, origin) {
  const links = await page
    .evaluate((host) => {
      const all = Array.from(document.querySelectorAll('a[href]'));
      return all
        .map((a) => a.href)
        .filter((h) => {
          try {
            const u = new URL(h);
            return (
              u.hostname.includes(host) &&
              !/\.(pdf|zip|jpg|png|mp4|exe|dmg)$/i.test(u.pathname) &&
              u.pathname.length > 1
            );
          } catch (e) {
            return false;
          }
        })
        .slice(0, 40);
    }, origin)
    .catch(() => []);

  if (!links.length) return false;

  const target = links[Math.floor(Math.random() * links.length)];
  await page.goto(target, { waitUntil: 'domcontentloaded', timeout: 35000 }).catch(() => undefined);
  return true;
}

/*
 * Прогрев одного профиля.
 *
 * session — активная сессия браузера, sites — список адресов,
 * minutes — сколько всего греть, onProgress — отчёт для окна приложения,
 * shouldStop — проверка «пользователь нажал стоп».
 */
async function warmupProfile(session, options) {
  const sites = parseSites(options.sites);
  if (!sites.length) return { ok: false, error: 'Не указано ни одного сайта' };

  const minutes = Math.min(Math.max(Number(options.minutes) || 20, 1), 180);
  const deadline = Date.now() + minutes * 60 * 1000;
  const onProgress = options.onProgress || (() => undefined);
  const shouldStop = options.shouldStop || (() => false);

  const context = session.context;
  const page = context.pages()[0] || (await context.newPage());

  const visited = [];
  let cookiesBefore = 0;
  try {
    cookiesBefore = (await context.cookies()).length;
  } catch (e) { /* окно недоступно */ }

  const queue = shuffle(sites);
  let index = 0;

  while (Date.now() < deadline && !shouldStop()) {
    const url = queue[index % queue.length];
    index += 1;

    /* Сколько побыть на сайте: делим остаток времени, но держим живые рамки */
    const left = deadline - Date.now();
    const slice = Math.min(Math.max(left / Math.max(queue.length - (index - 1), 1), 25000), 150000);

    onProgress({
      site: url.replace('https://', ''),
      visited: visited.length,
      total: queue.length,
      leftMs: left,
    });

    const opened = await page
      .goto(url, { waitUntil: 'domcontentloaded', timeout: 40000 })
      .then(() => true)
      .catch(() => false);

    if (!opened) continue;

    visited.push(url);
    await wait(rnd(1500, 4000));
    await moveMouse(page);

    /* Основное чтение страницы */
    await humanScroll(page, Math.round(slice / 2000));

    if (shouldStop() || Date.now() >= deadline) break;

    /* Заходим вглубь сайта: 1-2 внутренние страницы */
    const hops = Math.random() < 0.65 ? 2 : 1;
    const host = new URL(url).hostname.replace('www.', '');

    for (let h = 0; h < hops; h += 1) {
      if (shouldStop() || Date.now() >= deadline) break;

      const went = await followInnerLink(page, host);
      if (!went) break;

      await wait(rnd(1200, 3200));
      await moveMouse(page);
      await humanScroll(page, Math.round(rnd(6, 16)));
    }

    /* Сохраняем куки после каждого сайта — прогрев могут прервать */
    if (session.snapshot) await session.snapshot().catch(() => undefined);

    /* Пауза между сайтами */
    await wait(rnd(2000, 6000));
  }

  let cookiesAfter = cookiesBefore;
  try {
    cookiesAfter = (await context.cookies()).length;
  } catch (e) { /* окно закрыто */ }

  if (session.snapshot) await session.snapshot().catch(() => undefined);

  return {
    ok: true,
    visited: visited.length,
    sites: visited.map((u) => u.replace('https://', '')),
    cookiesBefore,
    cookiesAfter,
    gained: Math.max(cookiesAfter - cookiesBefore, 0),
    stopped: shouldStop(),
  };
}

module.exports = { warmupProfile, parseSites, normalizeSite };
