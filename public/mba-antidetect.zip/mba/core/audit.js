/*
 * Проверка отпечатка: открывает страницу внутри профиля, снимает реальные
 * значения глазами сайта и сравнивает с тем, что задумано в профиле.
 */

const TEST_SITES = {
  creepjs: { url: 'https://abrahamjuliot.github.io/creepjs/', label: 'CreepJS' },
  pixelscan: { url: 'https://pixelscan.net/', label: 'Pixelscan' },
  iphey: { url: 'https://iphey.com/', label: 'Iphey' },
  browserleaks: { url: 'https://browserleaks.com/javascript', label: 'BrowserLeaks' },
};

/* Скрипт снимает показания прямо в странице — так же, как это делает сайт-детектор */
const PROBE = `(() => {
  const out = {};

  out.userAgent = navigator.userAgent;
  out.platform = navigator.platform;
  out.languages = Array.from(navigator.languages || []);
  out.language = navigator.language;
  out.cores = navigator.hardwareConcurrency;
  out.memory = navigator.deviceMemory;
  out.touch = navigator.maxTouchPoints;
  out.webdriver = navigator.webdriver;
  out.screen = {
    width: screen.width,
    height: screen.height,
    availHeight: screen.availHeight,
    depth: screen.colorDepth,
    ratio: window.devicePixelRatio,
  };

  try {
    const tz = Intl.DateTimeFormat().resolvedOptions();
    out.timezone = tz.timeZone;
    out.locale = tz.locale;
    out.offset = new Date().getTimezoneOffset();
  } catch (e) { out.timezone = null; }

  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl) {
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      out.gpuVendor = dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR);
      out.gpuRenderer = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
    }
  } catch (e) { out.gpuRenderer = null; }

  try {
    const c = document.createElement('canvas');
    c.width = 260; c.height = 60;
    const ctx = c.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = "16px 'Arial'";
    ctx.fillStyle = '#f60';
    ctx.fillRect(0, 0, 120, 30);
    ctx.fillStyle = '#069';
    ctx.fillText('MBA fingerprint \\u2601', 4, 8);
    const data = c.toDataURL();
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      hash = ((hash << 5) - hash + data.charCodeAt(i)) | 0;
    }
    out.canvasHash = Math.abs(hash).toString(16);
  } catch (e) { out.canvasHash = null; }

  try {
    const probeFonts = ['Segoe UI', 'Calibri', 'Helvetica Neue', 'SF Pro', 'Menlo', 'PT Sans', 'Consolas'];
    out.fonts = probeFonts.filter((f) => {
      try { return document.fonts.check('12px "' + f + '"'); } catch (e) { return false; }
    });
  } catch (e) { out.fonts = []; }

  try {
    if (navigator.userAgentData) {
      out.uaPlatform = navigator.userAgentData.platform;
      out.uaMobile = navigator.userAgentData.mobile;
    }
  } catch (e) {}

  out.automationTraces = [
    'cdc_adoQpoasnfa76pfcZLmcfl_Array' in window,
    'cdc_adoQpoasnfa76pfcZLmcfl_Promise' in window,
    '__webdriver_evaluate' in document,
    '__selenium_unwrapped' in document,
    navigator.webdriver === true,
  ].filter(Boolean).length;

  return out;
})()`;

const label = (ok) => (ok ? 'ok' : 'fail');

/* Сравниваем то, что увидел сайт, с тем, что задано в профиле */
function compare(expected, actual) {
  const checks = [];

  const push = (name, title, ok, want, got, weight = 1) =>
    checks.push({ name, title, status: label(ok), want: String(want), got: String(got), weight });

  const isMac = expected.os === 'mac';

  push(
    'os',
    'Операционная система',
    isMac ? /Mac OS X/.test(actual.userAgent) : /Windows NT/.test(actual.userAgent),
    isMac ? 'macOS' : 'Windows',
    /Mac OS X/.test(actual.userAgent) ? 'macOS' : /Windows/.test(actual.userAgent) ? 'Windows' : '—',
    2,
  );

  push(
    'platform',
    'Платформа',
    actual.platform === expected.platform,
    expected.platform,
    actual.platform,
  );

  push(
    'uaPlatform',
    'Client Hints',
    !actual.uaPlatform || actual.uaPlatform === expected.uaData.platform,
    expected.uaData.platform,
    actual.uaPlatform || 'нет данных',
    2,
  );

  push(
    'screen',
    'Разрешение экрана',
    actual.screen.width === expected.screen.width && actual.screen.height === expected.screen.height,
    `${expected.screen.width}×${expected.screen.height}`,
    `${actual.screen.width}×${actual.screen.height}`,
  );

  push(
    'ratio',
    'Масштаб экрана',
    Math.abs((actual.screen.ratio || 1) - (expected.screen.pixelRatio || 1)) < 0.01,
    `${expected.screen.pixelRatio || 1}x`,
    `${actual.screen.ratio}x`,
  );

  push('cores', 'Ядра процессора', actual.cores === expected.hardwareConcurrency, expected.hardwareConcurrency, actual.cores);
  push('memory', 'Оперативная память', actual.memory === expected.deviceMemory, `${expected.deviceMemory} ГБ`, `${actual.memory} ГБ`);
  push('timezone', 'Часовой пояс', actual.timezone === expected.timezone, expected.timezone, actual.timezone || '—', 2);
  push('language', 'Язык', actual.language === expected.locale, expected.locale, actual.language);

  const gpuOk = actual.gpuRenderer === expected.gpu.renderer;
  push('gpu', 'Видеокарта', gpuOk, shortGpu(expected.gpu.renderer), shortGpu(actual.gpuRenderer || '—'), 2);

  /* Связка система + видеокарта — то, на чём чаще всего палятся */
  const rendererText = String(actual.gpuRenderer || '');
  const coherent = isMac
    ? !/NVIDIA|Radeon RX|Direct3D/.test(rendererText)
    : !/Metal Renderer/.test(rendererText);
  push('coherence', 'Система и видеокарта сходятся', coherent, isMac ? 'Apple или Intel' : 'без Apple Metal', coherent ? 'сходятся' : 'противоречие', 3);

  /* Шрифты должны соответствовать системе */
  const fonts = actual.fonts || [];
  const fontsOk = isMac
    ? !fonts.includes('Segoe UI') && !fonts.includes('Calibri')
    : !fonts.includes('Helvetica Neue') && !fonts.includes('SF Pro');
  push('fonts', 'Шрифты соответствуют системе', fontsOk, isMac ? 'без Segoe UI' : 'без Helvetica Neue', fonts.length ? fonts.join(', ') : '—', 2);

  push('webdriver', 'Признак автоматизации скрыт', !actual.webdriver, 'false', String(actual.webdriver), 3);
  push('traces', 'Следы управления браузером', actual.automationTraces === 0, '0', String(actual.automationTraces), 3);
  push('canvas', 'Canvas подменяется', Boolean(actual.canvasHash), 'уникальный', actual.canvasHash || '—');

  const totalWeight = checks.reduce((s, c) => s + c.weight, 0);
  const okWeight = checks.filter((c) => c.status === 'ok').reduce((s, c) => s + c.weight, 0);
  const score = Math.round((okWeight / totalWeight) * 100);

  return { checks, score, passed: checks.filter((c) => c.status === 'ok').length, total: checks.length };
}

const shortGpu = (value) => {
  const m = String(value).match(/(NVIDIA[^,()]*|AMD[^,()]*|Intel\(R\)[^,()]*|Apple M\d[^,()]*)/);
  return m ? m[0].trim() : String(value).slice(0, 42);
};

/*
 * Проверка идёт внутри уже работающего профиля: та же сессия, тот же прокси,
 * тот же отпечаток. Иначе результат не имел бы смысла.
 */
async function auditProfile(session, siteId) {
  const { context, fingerprint } = session;
  const site = TEST_SITES[siteId] || TEST_SITES.creepjs;

  const page = await context.newPage();
  let actual;
  let publicIp = null;

  try {
    /* Снимаем показания на нейтральной странице — без помех от скриптов сайта */
    await page.goto('https://example.com', { waitUntil: 'domcontentloaded', timeout: 20000 });
    actual = await page.evaluate(PROBE);

    publicIp = await page
      .evaluate(async () => {
        try {
          const res = await fetch('https://api.ipify.org?format=json');
          const data = await res.json();
          return data.ip;
        } catch (e) {
          return null;
        }
      })
      .catch(() => null);

    /* А теперь открываем сам детектор, чтобы можно было посмотреть глазами */
    await page.goto(site.url, { waitUntil: 'domcontentloaded', timeout: 40000 }).catch(() => undefined);
  } catch (error) {
    await page.close().catch(() => undefined);
    throw error;
  }

  const result = compare(fingerprint, actual);

  return {
    ...result,
    site: site.label,
    siteUrl: site.url,
    publicIp,
    actual: {
      userAgent: actual.userAgent,
      timezone: actual.timezone,
      gpu: shortGpu(actual.gpuRenderer || '—'),
      screen: `${actual.screen.width}×${actual.screen.height}`,
      canvasHash: actual.canvasHash,
    },
  };
}

module.exports = { auditProfile, TEST_SITES, compare, PROBE };
