function buildInjectScript(fp) {
  return `(() => {
  const FP = ${JSON.stringify(fp)};

  const define = (obj, prop, getter) => {
    try {
      Object.defineProperty(obj, prop, { get: getter, configurable: true, enumerable: true });
    } catch (e) {}
  };

  const proxyFn = (target, name, handler) => {
    const original = target[name];
    if (typeof original !== 'function') return;
    const wrapped = new Proxy(original, { apply: handler });
    try {
      Object.defineProperty(target, name, { value: wrapped, configurable: true, writable: true });
    } catch (e) {}
  };

  /* --- navigator --- */
  define(navigator, 'userAgent', () => FP.userAgent);
  define(navigator, 'appVersion', () => FP.userAgent.replace('Mozilla/', ''));
  define(navigator, 'platform', () => FP.platform);
  define(navigator, 'hardwareConcurrency', () => FP.hardwareConcurrency);
  define(navigator, 'deviceMemory', () => FP.deviceMemory);
  define(navigator, 'maxTouchPoints', () => FP.maxTouchPoints);

  /* Client Hints — должны совпадать с User-Agent, иначе детект мгновенный */
  if (navigator.userAgentData) {
    const data = FP.uaData;
    const high = {
      architecture: data.architecture,
      bitness: data.bitness,
      brands: data.brands,
      fullVersionList: data.brands.map((b) => ({ brand: b.brand, version: FP.chromeVersion })),
      mobile: data.mobile,
      model: data.model,
      platform: data.platform,
      platformVersion: data.platformVersion,
      uaFullVersion: FP.chromeVersion,
      wow64: false,
    };
    const stub = {
      brands: data.brands,
      mobile: data.mobile,
      platform: data.platform,
      getHighEntropyValues: (hints) => {
        const out = { brands: data.brands, mobile: data.mobile, platform: data.platform };
        (hints || []).forEach((h) => {
          if (h in high) out[h] = high[h];
        });
        return Promise.resolve(out);
      },
      toJSON: () => ({ brands: data.brands, mobile: data.mobile, platform: data.platform }),
    };
    define(navigator, 'userAgentData', () => stub);
  }
  define(navigator, 'language', () => FP.languages[0]);
  define(navigator, 'languages', () => Object.freeze([...FP.languages]));
  define(navigator, 'webdriver', () => false);

  /* --- screen --- */
  for (const key of ['width', 'height', 'availWidth', 'availHeight', 'colorDepth', 'pixelDepth']) {
    define(screen, key, () => FP.screen[key]);
  }
  define(window, 'outerWidth', () => FP.screen.width);
  define(window, 'outerHeight', () => FP.screen.height);
  define(window, 'devicePixelRatio', () => FP.screen.pixelRatio || 1);

  /* --- canvas: детерминированный шум --- */
  const noisify = (data, w, h) => {
    const n = FP.canvasNoise;
    let s = n.seed;
    for (let i = 0; i < data.length; i += 4) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      if ((s & 63) !== 0) continue;
      data[i] = Math.max(0, Math.min(255, data[i] + n.r));
      data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + n.g));
      data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + n.b));
    }
    return data;
  };

  proxyFn(CanvasRenderingContext2D.prototype, 'getImageData', (t, ctx, args) => {
    const result = Reflect.apply(t, ctx, args);
    noisify(result.data, result.width, result.height);
    return result;
  });

  const shotWithNoise = (t, canvas, args) => {
    try {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        ctx.putImageData(img, 0, 0);
      }
    } catch (e) {}
    return Reflect.apply(t, canvas, args);
  };
  proxyFn(HTMLCanvasElement.prototype, 'toDataURL', shotWithNoise);
  proxyFn(HTMLCanvasElement.prototype, 'toBlob', shotWithNoise);

  /* --- WebGL --- */
  const patchGL = (proto) => {
    if (!proto) return;
    proxyFn(proto, 'getParameter', (t, ctx, args) => {
      const p = args[0];
      if (p === 37445) return FP.gpu.vendor;
      if (p === 37446) return FP.gpu.renderer;
      if (p === 7936) return 'WebKit';
      if (p === 7937) return 'WebKit WebGL';
      return Reflect.apply(t, ctx, args);
    });
    proxyFn(proto, 'readPixels', (t, ctx, args) => {
      const out = Reflect.apply(t, ctx, args);
      const buf = args[6];
      if (buf && buf.length) {
        let s = FP.webglNoise;
        for (let i = 0; i < buf.length; i += 400) {
          s = (s * 1103515245 + 12345) & 0x7fffffff;
          buf[i] = (buf[i] + (s & 1)) & 255;
        }
      }
      return out;
    });
  };
  patchGL(window.WebGLRenderingContext && WebGLRenderingContext.prototype);
  patchGL(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype);

  /* --- AudioContext --- */
  if (window.AnalyserNode) {
    proxyFn(AnalyserNode.prototype, 'getFloatFrequencyData', (t, ctx, args) => {
      const out = Reflect.apply(t, ctx, args);
      const arr = args[0];
      for (let i = 0; i < arr.length; i += 50) arr[i] += FP.audioNoise;
      return out;
    });
  }
  if (window.AudioBuffer) {
    proxyFn(AudioBuffer.prototype, 'getChannelData', (t, ctx, args) => {
      const arr = Reflect.apply(t, ctx, args);
      for (let i = 0; i < arr.length; i += 500) arr[i] += FP.audioNoise;
      return arr;
    });
  }

  /* --- шрифты: разрешаем только список профиля --- */
  const allowed = new Set(FP.fonts.map((f) => f.toLowerCase()));
  if (document.fonts && document.fonts.check) {
    proxyFn(document.fonts, 'check', (t, ctx, args) => {
      const spec = String(args[0] || '').toLowerCase();
      const name = spec.replace(/^[^a-zа-я"']*/i, '').replace(/["']/g, '').trim();
      for (const f of allowed) if (name.includes(f)) return true;
      return false;
    });
  }

  /* --- WebRTC: убираем локальные адреса --- */
  if (window.RTCPeerConnection) {
    const RTC = window.RTCPeerConnection;
    const Patched = function (...args) {
      const pc = new RTC(...args);
      const origAdd = pc.addIceCandidate.bind(pc);
      pc.addIceCandidate = (cand, ...rest) => {
        if (cand && cand.candidate && /(\\b10\\.|\\b192\\.168\\.|\\b172\\.(1[6-9]|2\\d|3[01])\\.|\\.local)/.test(cand.candidate)) {
          return Promise.resolve();
        }
        return origAdd(cand, ...rest);
      };
      return pc;
    };
    Patched.prototype = RTC.prototype;
    window.RTCPeerConnection = Patched;
    if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = Patched;
  }

  /* --- маскируем сами патчи --- */
  const nativeToString = Function.prototype.toString;
  Function.prototype.toString = new Proxy(nativeToString, {
    apply(t, ctx, args) {
      try {
        return Reflect.apply(t, ctx, args);
      } catch (e) {
        return 'function () { [native code] }';
      }
    },
  });
})();`;
}

module.exports = { buildInjectScript };
