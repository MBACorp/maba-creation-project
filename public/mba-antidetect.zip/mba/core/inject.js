/*
 * Общий блок маскировки. Одинаково работает на странице и внутри воркера.
 * Задача: подменённые геттеры и методы должны быть неотличимы от встроенных —
 * правильное имя, длина и текст "[native code]" при toString().
 */
const MASK_HELPERS = `
  const nativeToString = Function.prototype.toString;
  const nativeMap = new WeakMap();

  const markNative = (fn, name, len) => {
    try {
      Object.defineProperty(fn, 'name', { value: name, configurable: true });
      Object.defineProperty(fn, 'length', { value: len || 0, configurable: true });
    } catch (e) {}
    nativeMap.set(fn, 'function ' + name + '() { [native code] }');
    return fn;
  };

  /*
   * toString перехватываем первым делом. Детектор читает дескриптор свойства
   * и вызывает toString у геттера — теперь он получает ровно тот же ответ,
   * что и от настоящего браузера.
   */
  const toStringProxy = new Proxy(nativeToString, {
    apply(target, ctx, args) {
      if (nativeMap.has(ctx)) return nativeMap.get(ctx);
      return Reflect.apply(target, ctx, args);
    },
  });
  nativeMap.set(toStringProxy, 'function toString() { [native code] }');
  try {
    Object.defineProperty(Function.prototype, 'toString', {
      value: toStringProxy, writable: true, configurable: true, enumerable: false,
    });
  } catch (e) {}

  /*
   * Подменяем свойство там, где оно объявлено — на прототипе. Геттер маскируем
   * под встроенный, флаги дескриптора повторяем за оригиналом: иначе подмена
   * видна через Object.getOwnPropertyDescriptor.
   */
  const define = (obj, prop, getter) => {
    let target = obj;
    let proto = obj;
    let original = null;
    while (proto) {
      const desc = Object.getOwnPropertyDescriptor(proto, prop);
      if (desc) { target = proto; original = desc; break; }
      proto = Object.getPrototypeOf(proto);
    }

    markNative(getter, 'get ' + prop, 0);

    try {
      Object.defineProperty(target, prop, {
        get: getter,
        set: original && original.set ? original.set : undefined,
        configurable: original ? original.configurable !== false : true,
        enumerable: original ? original.enumerable : true,
      });
    } catch (e) {
      try {
        Object.defineProperty(obj, prop, { get: getter, configurable: true, enumerable: true });
      } catch (e2) {}
    }
  };

  /* Подмена метода с сохранением имени, длины и флагов оригинала */
  const proxyFn = (target, name, handler) => {
    const original = target && target[name];
    if (typeof original !== 'function') return;
    const own = Object.getOwnPropertyDescriptor(target, name);
    const wrapped = new Proxy(original, { apply: handler });
    nativeMap.set(wrapped, 'function ' + name + '() { [native code] }');
    try {
      Object.defineProperty(target, name, {
        value: wrapped,
        configurable: true,
        writable: true,
        enumerable: own ? own.enumerable : false,
      });
    } catch (e) {}
  };
`;

/*
 * Патч для Web Worker. Внутри воркера нет window, document и screen, поэтому
 * подменяем доступное: navigator, WebGL и canvas. Без этого сайт создаёт
 * воркер, читает настоящие параметры машины и по расхождению со страницей
 * понимает, что отпечаток подменён.
 */
function buildWorkerPatch(fp) {
  return `(() => {
  if (self.__mbaPatched) return;
  self.__mbaPatched = true;
  const FP = ${JSON.stringify(fp)};
${MASK_HELPERS}

  define(navigator, 'userAgent', () => FP.userAgent);
  define(navigator, 'appVersion', () => FP.userAgent.replace('Mozilla/', ''));
  define(navigator, 'platform', () => FP.platform);
  define(navigator, 'hardwareConcurrency', () => FP.hardwareConcurrency);
  define(navigator, 'deviceMemory', () => FP.deviceMemory);
  define(navigator, 'language', () => FP.languages[0]);
  define(navigator, 'languages', () => Object.freeze([...FP.languages]));

  if (navigator.userAgentData) {
    const data = FP.uaData;
    const high = {
      architecture: data.architecture, bitness: data.bitness, brands: data.brands,
      fullVersionList: data.brands.map((b) => ({ brand: b.brand, version: FP.chromeVersion })),
      mobile: data.mobile, model: data.model, platform: data.platform,
      platformVersion: data.platformVersion, uaFullVersion: FP.chromeVersion, wow64: false,
    };
    const stub = {
      brands: data.brands, mobile: data.mobile, platform: data.platform,
      getHighEntropyValues: (hints) => {
        const out = { brands: data.brands, mobile: data.mobile, platform: data.platform };
        (hints || []).forEach((h) => { if (h in high) out[h] = high[h]; });
        return Promise.resolve(out);
      },
      toJSON: () => ({ brands: data.brands, mobile: data.mobile, platform: data.platform }),
    };
    define(navigator, 'userAgentData', () => stub);
  }

  /* WebGL в воркере доступен через OffscreenCanvas */
  const patchGL = (proto) => {
    if (!proto) return;
    proxyFn(proto, 'getParameter', (t, ctx, args) => {
      const p = args[0];
      if (p === 37445) return FP.gpu.vendor;
      if (p === 37446) return FP.gpu.renderer;
      if (p === 7936) return 'WebKit';
      if (p === 7937) return 'WebKit WebGL';
      return Reflect.apply(t, ctx, args);
    });
  };
  patchGL(self.WebGLRenderingContext && WebGLRenderingContext.prototype);
  patchGL(self.WebGL2RenderingContext && WebGL2RenderingContext.prototype);

  /* Canvas: тот же шум, что и на странице, иначе отпечатки не совпадут */
  const noisify = (data) => {
    const n = FP.canvasNoise;
    let s = n.seed;
    for (let i = 0; i < data.length; i += 4) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      if ((s & 63) !== 0) continue;
      data[i] = Math.max(0, Math.min(255, data[i] + n.r));
      data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + n.g));
      data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + n.b));
    }
    return data;
  };
  if (self.OffscreenCanvasRenderingContext2D) {
    proxyFn(OffscreenCanvasRenderingContext2D.prototype, 'getImageData', (t, ctx, args) => {
      const result = Reflect.apply(t, ctx, args);
      noisify(result.data);
      return result;
    });
  }

  /* Воркер, запущенный из воркера, тоже должен получить патч */
  const SRC = self.__mbaPatchSrc;
  if (SRC && self.Worker) {
    const OrigWorker = self.Worker;
    const Patched = function Worker(url, opts) {
      try {
        const abs = new URL(url, self.location.href).href;
        const isModule = opts && opts.type === 'module';
        const body = 'self.__mbaPatchSrc=' + JSON.stringify(SRC) + ';\\n' + SRC + '\\n'
          + (isModule ? 'import ' + JSON.stringify(abs) + ';' : 'importScripts(' + JSON.stringify(abs) + ');');
        const blob = URL.createObjectURL(new Blob([body], { type: 'text/javascript' }));
        return new OrigWorker(blob, opts);
      } catch (e) {
        return new OrigWorker(url, opts);
      }
    };
    Patched.prototype = OrigWorker.prototype;
    markNative(Patched, 'Worker', 1);
    self.Worker = Patched;
  }
})();`;
}

function buildInjectScript(fp) {
  const workerPatch = buildWorkerPatch(fp);
  return `(() => {
  const FP = ${JSON.stringify(fp)};
${MASK_HELPERS}

  /* --- navigator --- */
  define(navigator, 'userAgent', () => FP.userAgent);
  define(navigator, 'appVersion', () => FP.userAgent.replace('Mozilla/', ''));
  define(navigator, 'platform', () => FP.platform);
  define(navigator, 'hardwareConcurrency', () => FP.hardwareConcurrency);
  define(navigator, 'deviceMemory', () => FP.deviceMemory);
  define(navigator, 'maxTouchPoints', () => FP.maxTouchPoints);

  /* Client Hints — должны совпадать с User-Agent, иначе детект мгновенный */
  if (navigator.userAgentData) {
    const data = FP.uaData;
    const high = {
      architecture: data.architecture,
      bitness: data.bitness,
      brands: data.brands,
      fullVersionList: data.brands.map((b) => ({ brand: b.brand, version: FP.chromeVersion })),
      mobile: data.mobile,
      model: data.model,
      platform: data.platform,
      platformVersion: data.platformVersion,
      uaFullVersion: FP.chromeVersion,
      wow64: false,
    };
    const stub = {
      brands: data.brands,
      mobile: data.mobile,
      platform: data.platform,
      getHighEntropyValues: (hints) => {
        const out = { brands: data.brands, mobile: data.mobile, platform: data.platform };
        (hints || []).forEach((h) => {
          if (h in high) out[h] = high[h];
        });
        return Promise.resolve(out);
      },
      toJSON: () => ({ brands: data.brands, mobile: data.mobile, platform: data.platform }),
    };
    define(navigator, 'userAgentData', () => stub);
  }
  define(navigator, 'language', () => FP.languages[0]);
  define(navigator, 'languages', () => Object.freeze([...FP.languages]));
  define(navigator, 'webdriver', () => false);

  /* --- screen --- */
  for (const key of ['width', 'height', 'availWidth', 'availHeight', 'colorDepth', 'pixelDepth']) {
    define(screen, key, () => FP.screen[key]);
  }
  define(window, 'outerWidth', () => FP.screen.width);
  define(window, 'outerHeight', () => FP.screen.height);
  define(window, 'devicePixelRatio', () => FP.screen.pixelRatio || 1);

  /* --- canvas: детерминированный шум --- */
  const noisify = (data, w, h) => {
    const n = FP.canvasNoise;
    let s = n.seed;
    for (let i = 0; i < data.length; i += 4) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      if ((s & 63) !== 0) continue;
      data[i] = Math.max(0, Math.min(255, data[i] + n.r));
      data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + n.g));
      data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + n.b));
    }
    return data;
  };

  proxyFn(CanvasRenderingContext2D.prototype, 'getImageData', (t, ctx, args) => {
    const result = Reflect.apply(t, ctx, args);
    noisify(result.data, result.width, result.height);
    return result;
  });

  const shotWithNoise = (t, canvas, args) => {
    try {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
        ctx.putImageData(img, 0, 0);
      }
    } catch (e) {}
    return Reflect.apply(t, canvas, args);
  };
  proxyFn(HTMLCanvasElement.prototype, 'toDataURL', shotWithNoise);
  proxyFn(HTMLCanvasElement.prototype, 'toBlob', shotWithNoise);

  /* --- WebGL --- */
  const patchGL = (proto) => {
    if (!proto) return;
    proxyFn(proto, 'getParameter', (t, ctx, args) => {
      const p = args[0];
      if (p === 37445) return FP.gpu.vendor;
      if (p === 37446) return FP.gpu.renderer;
      if (p === 7936) return 'WebKit';
      if (p === 7937) return 'WebKit WebGL';
      return Reflect.apply(t, ctx, args);
    });
    proxyFn(proto, 'readPixels', (t, ctx, args) => {
      const out = Reflect.apply(t, ctx, args);
      const buf = args[6];
      if (buf && buf.length) {
        let s = FP.webglNoise;
        for (let i = 0; i < buf.length; i += 400) {
          s = (s * 1103515245 + 12345) & 0x7fffffff;
          buf[i] = (buf[i] + (s & 1)) & 255;
        }
      }
      return out;
    });
  };
  patchGL(window.WebGLRenderingContext && WebGLRenderingContext.prototype);
  patchGL(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype);

  /* --- AudioContext --- */
  if (window.AnalyserNode) {
    proxyFn(AnalyserNode.prototype, 'getFloatFrequencyData', (t, ctx, args) => {
      const out = Reflect.apply(t, ctx, args);
      const arr = args[0];
      for (let i = 0; i < arr.length; i += 50) arr[i] += FP.audioNoise;
      return out;
    });
  }
  if (window.AudioBuffer) {
    proxyFn(AudioBuffer.prototype, 'getChannelData', (t, ctx, args) => {
      const arr = Reflect.apply(t, ctx, args);
      for (let i = 0; i < arr.length; i += 500) arr[i] += FP.audioNoise;
      return arr;
    });
  }

  /* --- шрифты: разрешаем только список профиля --- */
  const allowed = new Set(FP.fonts.map((f) => f.toLowerCase()));

  /*
   * Определяют шрифты не через fonts.check, а измерением: рисуют текст
   * нужным шрифтом и запасным, затем сравнивают ширину. Совпало — шрифта нет.
   * Поэтому мало отвечать на check, надо ещё и правдоподобно менять ширину.
   */
  const fontKey = (family) => {
    const parts = String(family || '').split(',');
    for (const raw of parts) {
      const name = raw.replace(/["']/g, '').trim().toLowerCase();
      if (!name) continue;
      if (allowed.has(name)) return name;
      for (const f of allowed) if (name === f) return f;
    }
    return null;
  };

  /* Стабильный для профиля коэффициент ширины: у каждого шрифта свой */
  const fontScale = (name) => {
    if (!name) return null;
    let h = FP.canvasNoise.seed >>> 0;
    for (let i = 0; i < name.length; i++) {
      h = (h * 31 + name.charCodeAt(i)) >>> 0;
    }
    /* Разброс в пределах пары процентов — как у разных гарнитур */
    return 1 + ((h % 400) - 200) / 10000;
  };

  if (document.fonts && document.fonts.check) {
    proxyFn(document.fonts, 'check', (t, ctx, args) => {
      const spec = String(args[0] || '').toLowerCase();
      const name = spec.replace(/^[^a-zа-я"']*/i, '').replace(/["']/g, '').trim();
      for (const f of allowed) if (name.includes(f)) return true;
      return false;
    });
  }

  /* Ширина текста на canvas — самый частый способ перебора шрифтов */
  if (window.CanvasRenderingContext2D) {
    proxyFn(CanvasRenderingContext2D.prototype, 'measureText', (t, ctx, args) => {
      const metrics = Reflect.apply(t, ctx, args);
      const key = fontKey(ctx.font ? ctx.font.replace(/^.*?\\d+\\w*\\s+/, '') : '');
      const k = fontScale(key);
      if (!k) return metrics;
      const patched = Object.create(Object.getPrototypeOf(metrics));
      ['width', 'actualBoundingBoxLeft', 'actualBoundingBoxRight',
       'actualBoundingBoxAscent', 'actualBoundingBoxDescent',
       'fontBoundingBoxAscent', 'fontBoundingBoxDescent'].forEach((p) => {
        try {
          const v = metrics[p];
          Object.defineProperty(patched, p, {
            value: typeof v === 'number' ? v * k : v,
            enumerable: true, configurable: true,
          });
        } catch (e) {}
      });
      return patched;
    });
  }

  /*
   * Второй способ: вставляют элемент с нужным шрифтом и меряют размер.
   * Подмешиваем тот же коэффициент, чтобы результат сходился с canvas.
   */
  try {
    const styleScale = (el) => {
      try {
        const cs = window.getComputedStyle(el);
        return fontScale(fontKey(cs && cs.fontFamily));
      } catch (e) { return null; }
    };

    ['offsetWidth', 'offsetHeight'].forEach((prop) => {
      const desc = Object.getOwnPropertyDescriptor(HTMLElement.prototype, prop);
      if (!desc || !desc.get) return;
      const original = desc.get;
      const getter = function () {
        const raw = original.call(this);
        const k = styleScale(this);
        return Math.round(raw * FP.rectNoise * (k || 1));
      };
      markNative(getter, 'get ' + prop, 0);
      Object.defineProperty(HTMLElement.prototype, prop, {
        get: getter, configurable: true, enumerable: desc.enumerable,
      });
    });
  } catch (e) {}

  /* --- WebRTC: убираем локальные адреса --- */
  if (window.RTCPeerConnection) {
    const RTC = window.RTCPeerConnection;
    const Patched = function (...args) {
      const pc = new RTC(...args);
      const origAdd = pc.addIceCandidate.bind(pc);
      pc.addIceCandidate = (cand, ...rest) => {
        if (cand && cand.candidate && /(\\b10\\.|\\b192\\.168\\.|\\b172\\.(1[6-9]|2\\d|3[01])\\.|\\.local)/.test(cand.candidate)) {
          return Promise.resolve();
        }
        return origAdd(cand, ...rest);
      };
      return pc;
    };
    Patched.prototype = RTC.prototype;
    window.RTCPeerConnection = Patched;
    if (window.webkitRTCPeerConnection) window.webkitRTCPeerConnection = Patched;
  }

  /* --- плагины и типы файлов --- */
  try {
    const mimeData = [
      { type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format' },
      { type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format' },
    ];

    const makePlugin = (info) => {
      const plugin = Object.create(Plugin.prototype);
      Object.defineProperties(plugin, {
        name: { value: info.name, enumerable: true },
        filename: { value: info.filename, enumerable: true },
        description: { value: info.description, enumerable: true },
        length: { value: mimeData.length, enumerable: true },
      });
      return plugin;
    };

    const list = FP.plugins.map(makePlugin);
    const pluginArray = Object.create(PluginArray.prototype);
    list.forEach((p, i) => { pluginArray[i] = p; });
    Object.defineProperties(pluginArray, {
      length: { value: list.length, enumerable: false },
      item: { value: (i) => list[i] || null },
      namedItem: { value: (n) => list.find((p) => p.name === n) || null },
      refresh: { value: () => undefined },
    });

    const mimes = mimeData.map((m) => {
      const mime = Object.create(MimeType.prototype);
      Object.defineProperties(mime, {
        type: { value: m.type, enumerable: true },
        suffixes: { value: m.suffixes, enumerable: true },
        description: { value: m.description, enumerable: true },
        enabledPlugin: { value: list[0], enumerable: true },
      });
      return mime;
    });

    const mimeArray = Object.create(MimeTypeArray.prototype);
    mimes.forEach((m, i) => { mimeArray[i] = m; });
    Object.defineProperties(mimeArray, {
      length: { value: mimes.length, enumerable: false },
      item: { value: (i) => mimes[i] || null },
      namedItem: { value: (t) => mimes.find((m) => m.type === t) || null },
    });

    define(navigator, 'plugins', () => pluginArray);
    define(navigator, 'mimeTypes', () => mimeArray);
    define(navigator, 'pdfViewerEnabled', () => true);
  } catch (e) {}

  /* --- батарея --- */
  if (navigator.getBattery) {
    const battery = {
      charging: FP.battery.charging,
      chargingTime: FP.battery.chargingTime === null ? Infinity : FP.battery.chargingTime,
      dischargingTime: FP.battery.dischargingTime === null ? Infinity : FP.battery.dischargingTime,
      level: FP.battery.level,
      onchargingchange: null,
      onchargingtimechange: null,
      ondischargingtimechange: null,
      onlevelchange: null,
      addEventListener: () => undefined,
      removeEventListener: () => undefined,
      dispatchEvent: () => false,
    };
    proxyFn(navigator, 'getBattery', () => Promise.resolve(battery));
  }

  /* --- камера и микрофон --- */
  if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
    const devices = FP.mediaDevices.map((d) => ({
      deviceId: d.deviceId,
      kind: d.kind,
      label: d.label,
      groupId: d.groupId,
      toJSON() { return { deviceId: d.deviceId, kind: d.kind, label: d.label, groupId: d.groupId }; },
    }));
    proxyFn(navigator.mediaDevices, 'enumerateDevices', () => Promise.resolve(devices));
  }

  /* --- геолокация: не выдаём настоящее место --- */
  if (navigator.geolocation) {
    const denied = (_ok, fail) => {
      if (typeof fail === 'function') {
        fail({ code: 1, message: 'User denied Geolocation', PERMISSION_DENIED: 1 });
      }
    };
    proxyFn(navigator.geolocation, 'getCurrentPosition', (t, ctx, args) => denied(args[0], args[1]));
    proxyFn(navigator.geolocation, 'watchPosition', (t, ctx, args) => { denied(args[0], args[1]); return 0; });
  }

  /* --- разрешения: ответы как у обычного браузера --- */
  if (navigator.permissions && navigator.permissions.query) {
    const STATE = {
      geolocation: 'prompt', notifications: 'prompt', camera: 'prompt',
      microphone: 'prompt', 'clipboard-read': 'prompt', 'background-sync': 'granted',
      midi: 'granted', 'persistent-storage': 'prompt', 'payment-handler': 'granted',
    };
    proxyFn(navigator.permissions, 'query', (t, ctx, args) => {
      const name = args[0] && args[0].name;
      const state = STATE[name];
      if (!state) return Reflect.apply(t, ctx, args);
      return Promise.resolve({
        name, state, status: state, onchange: null,
        addEventListener: () => undefined,
        removeEventListener: () => undefined,
        dispatchEvent: () => false,
      });
    });
  }
  if (window.Notification) {
    define(Notification, 'permission', () => 'default');
  }

  /* --- размеры элементов: микросмещение, стабильное для профиля --- */
  try {
    const k = FP.rectNoise;
    const shift = (rect) => ({
      x: rect.x * k, y: rect.y * k,
      width: rect.width * k, height: rect.height * k,
      top: rect.top * k, right: rect.right * k,
      bottom: rect.bottom * k, left: rect.left * k,
      toJSON() { return this; },
    });

    proxyFn(Element.prototype, 'getBoundingClientRect', (t, ctx, args) =>
      shift(Reflect.apply(t, ctx, args)));

    proxyFn(Element.prototype, 'getClientRects', (t, ctx, args) => {
      const rects = Reflect.apply(t, ctx, args);
      const list = Array.from(rects).map(shift);
      list.item = (i) => list[i] || null;
      return list;
    });

    if (window.Range) {
      proxyFn(Range.prototype, 'getBoundingClientRect', (t, ctx, args) =>
        shift(Reflect.apply(t, ctx, args)));
    }

    /* offsetWidth и offsetHeight обрабатываются в блоке шрифтов выше */
  } catch (e) {}

  /* --- раскладка клавиатуры --- */
  if (navigator.keyboard && navigator.keyboard.getLayoutMap) {
    const entries = Object.entries(FP.keyboard);
    const layout = new Map(entries);
    layout.get = (code) => FP.keyboard[code];
    layout.has = (code) => code in FP.keyboard;
    proxyFn(navigator.keyboard, 'getLayoutMap', () => Promise.resolve(layout));
  }

  /* --- голоса синтеза речи --- */
  if (window.speechSynthesis) {
    const voices = FP.voices.map((v) => {
      const voice = Object.create(
        window.SpeechSynthesisVoice ? SpeechSynthesisVoice.prototype : Object.prototype,
      );
      Object.defineProperties(voice, {
        voiceURI: { value: v.name, enumerable: true },
        name: { value: v.name, enumerable: true },
        lang: { value: v.lang, enumerable: true },
        localService: { value: v.localService, enumerable: true },
        default: { value: v.default, enumerable: true },
      });
      return voice;
    });
    proxyFn(speechSynthesis, 'getVoices', () => voices);
  }

  /*
   * Мелкие параметры. По отдельности незаметны, но вместе дают заметную
   * добавку к отпечатку — и выдают, что железо не то, что заявлено.
   */
  try {
    /* Геймпады: у обычного пользователя их нет */
    if (navigator.getGamepads) {
      proxyFn(navigator, 'getGamepads', () => []);
    }

    /* Свободное место на диске: настоящее выдаёт конкретную машину */
    if (navigator.storage && navigator.storage.estimate) {
      const quota = FP.storageQuota;
      proxyFn(navigator.storage, 'estimate', () => Promise.resolve({
        quota,
        usage: Math.round(quota * FP.storageUsed),
        usageDetails: {},
      }));
    }

    /*
     * Датчики движения. На настольном компьютере их не бывает, поэтому
     * события просто не приходят — а не приходят с ошибкой.
     */
    ['DeviceOrientationEvent', 'DeviceMotionEvent'].forEach((name) => {
      if (!window[name]) return;
      try {
        if (window[name].requestPermission) {
          proxyFn(window[name], 'requestPermission', () => Promise.resolve('denied'));
        }
      } catch (e) {}
    });
    ['ondeviceorientation', 'ondevicemotion', 'ondeviceorientationabsolute'].forEach((prop) => {
      try { define(window, prop, () => null); } catch (e) {}
    });

    /* Сеть: скорость соединения должна соответствовать обычному каналу */
    if (navigator.connection) {
      const conn = FP.connection;
      ['effectiveType', 'rtt', 'downlink', 'saveData', 'type'].forEach((p) => {
        if (conn[p] === undefined) return;
        try { define(navigator.connection, p, () => conn[p]); } catch (e) {}
      });
    }

    /* Точки касания и указатель: у ПК мышь, а не палец */
    if (window.matchMedia) {
      const origMatch = window.matchMedia;
      const mmWrap = new Proxy(origMatch, {
        apply(t, ctx, args) {
          const q = String(args[0] || '');
          const res = Reflect.apply(t, ctx, args);
          try {
            if (/pointer:\\s*coarse|any-pointer:\\s*coarse|hover:\\s*none/.test(q)) {
              Object.defineProperty(res, 'matches', { value: false, configurable: true });
            }
            if (/pointer:\\s*fine|any-hover:\\s*hover|hover:\\s*hover/.test(q)) {
              Object.defineProperty(res, 'matches', { value: true, configurable: true });
            }
            if (/prefers-color-scheme:\\s*dark/.test(q)) {
              Object.defineProperty(res, 'matches', { value: FP.darkMode, configurable: true });
            }
          } catch (e) {}
          return res;
        },
      });
      nativeMap.set(mmWrap, 'function matchMedia() { [native code] }');
      Object.defineProperty(window, 'matchMedia', {
        value: mmWrap, writable: true, configurable: true,
      });
    }

    /* Виртуальная клавиатура и вибрация — признаки телефона, у ПК их нет */
    if (navigator.vibrate) proxyFn(navigator, 'vibrate', () => false);

    /* Число одновременных сетевых соединений и прочие устаревшие поля */
    try { define(navigator, 'productSub', () => '20030107'); } catch (e) {}
    try { define(navigator, 'vendor', () => 'Google Inc.'); } catch (e) {}
    try { define(navigator, 'vendorSub', () => ''); } catch (e) {}
    try { define(navigator, 'appCodeName', () => 'Mozilla'); } catch (e) {}
    try { define(navigator, 'appName', () => 'Netscape'); } catch (e) {}
    try { define(navigator, 'oscpu', () => undefined); } catch (e) {}
    try { define(navigator, 'doNotTrack', () => FP.doNotTrack); } catch (e) {}

    /* Часовой пояс: смещение должно совпадать с заявленным регионом */
    if (window.Intl && Intl.DateTimeFormat) {
      const origResolved = Intl.DateTimeFormat.prototype.resolvedOptions;
      const wrapped = new Proxy(origResolved, {
        apply(t, ctx, args) {
          const out = Reflect.apply(t, ctx, args);
          out.timeZone = FP.timezone;
          out.locale = FP.locale;
          return out;
        },
      });
      nativeMap.set(wrapped, 'function resolvedOptions() { [native code] }');
      Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
        value: wrapped, writable: true, configurable: true,
      });
    }
  } catch (e) {}

  /*
   * Метки автоматизации. Их оставляют драйверы: chromedriver добавляет
   * в document свойства вида $cdc_asdjflasutopfhvcZLmcfl_, selenium и
   * webdriver — свои. Антифрод перебирает ключи window и document и ловит
   * по ним в первую очередь. Удаляем и не даём появиться снова.
   */
  try {
    /* Точные имена меток, которые ставят драйверы */
    const EXACT = new Set([
      'webdriver', '__webdriver_evaluate', '__selenium_evaluate', '__webdriver_script_function',
      '__webdriver_script_func', '__webdriver_script_fn', '__fxdriver_evaluate',
      '__driver_unwrapped', '__webdriver_unwrapped', '__driver_evaluate',
      '__selenium_unwrapped', '__fxdriver_unwrapped', '__wdc_', '_WEBDRIVER_ELEM_CACHE',
      'webdriver-evaluate', 'webdriver-evaluate-response', 'selenium-evaluate',
      '_Selenium_IDE_Recorder', 'calledSelenium', '$chrome_asyncScriptInfo',
      '$cdc_asdjflasutopfhvcZLmcfl_', 'cdc_adoQpoasnfa76pfcZLmcfl_Array',
      'cdc_adoQpoasnfa76pfcZLmcfl_Promise', 'cdc_adoQpoasnfa76pfcZLmcfl_Symbol',
      'cdc_adoQpoasnfa76pfcZLmcfl_JSON', 'cdc_adoQpoasnfa76pfcZLmcfl_Object',
      'cdc_adoQpoasnfa76pfcZLmcfl_Proxy', 'cdc_adoQpoasnfa76pfcZLmcfl_Reflect',
      '__$webdriverAsyncExecutor', '__lastWatirAlert', '__lastWatirConfirm',
      '__lastWatirPrompt', '__playwright', '__pw_manual', '__PW_inspect',
      '__pwInitScripts', '_playwright_target_', '__puppeteer_evaluation_script__',
    ]);

    const isBad = (key) => {
      const k = String(key);
      if (EXACT.has(k)) return true;
      return /^\\$?cdc_|^__?(webdriver|selenium|fxdriver|driver_|wdc_|playwright|pw_|pwInitScripts|puppeteer)|^_Selenium_IDE|^_WEBDRIVER_/i.test(k);
    };

    /* Убираем то, что уже успели добавить до нашего скрипта */
    const scrub = (obj) => {
      if (!obj) return;
      try {
        Object.getOwnPropertyNames(obj).forEach((key) => {
          if (isBad(key)) {
            const d = Object.getOwnPropertyDescriptor(obj, key);
            if (d && d.get && d.get.__mbaTrap) return;
            try { delete obj[key]; } catch (e) {}
          }
        });
      } catch (e) {}
    };
    scrub(window);
    scrub(document);
    if (window.document && document.documentElement) {
      try {
        ['webdriver', 'selenium', 'driver'].forEach((a) => {
          if (document.documentElement.hasAttribute(a)) document.documentElement.removeAttribute(a);
        });
      } catch (e) {}
    }

    /*
     * Драйвер дописывает метки уже после старта страницы. Перехватываем
     * defineProperty: попытку создать такое свойство молча принимаем,
     * но само свойство не появляется.
     */
    const origDefine = Object.defineProperty;
    const guard = function defineProperty(obj, prop, desc) {
      if ((obj === window || obj === document) && isBad(prop)) return obj;
      return origDefine(obj, prop, desc);
    };
    markNative(guard, 'defineProperty', 3);
    origDefine(Object, 'defineProperty', {
      value: guard, writable: true, configurable: true, enumerable: false,
    });

    const origDefineProps = Object.defineProperties;
    const guardMany = function defineProperties(obj, props) {
      if (obj === window || obj === document) {
        const clean = {};
        Object.keys(props || {}).forEach((k) => { if (!isBad(k)) clean[k] = props[k]; });
        return origDefineProps(obj, clean);
      }
      return origDefineProps(obj, props);
    };
    markNative(guardMany, 'defineProperties', 2);
    origDefine(Object, 'defineProperties', {
      value: guardMany, writable: true, configurable: true, enumerable: false,
    });

    /*
     * Если метку всё же успели записать напрямую, она не должна попасть
     * в перечисление ключей — именно так её обычно и находят.
     */
    const filterKeys = (fnName, original) => {
      const wrapped = new Proxy(original, {
        apply(t, ctx, args) {
          const out = Reflect.apply(t, ctx, args);
          if (args[0] === window || args[0] === document) {
            return out.filter((k) => !isBad(k));
          }
          return out;
        },
      });
      nativeMap.set(wrapped, 'function ' + fnName + '() { [native code] }');
      return wrapped;
    };

    origDefine(Object, 'getOwnPropertyNames', {
      value: filterKeys('getOwnPropertyNames', Object.getOwnPropertyNames),
      writable: true, configurable: true, enumerable: false,
    });
    origDefine(Object, 'keys', {
      value: filterKeys('keys', Object.keys),
      writable: true, configurable: true, enumerable: false,
    });
    origDefine(Reflect, 'ownKeys', {
      value: filterKeys('ownKeys', Reflect.ownKeys),
      writable: true, configurable: true, enumerable: false,
    });

    /* Проверка "имя in window" тоже не должна подтверждать метку */
    const origHas = Object.prototype.hasOwnProperty;
    const hasGuard = new Proxy(origHas, {
      apply(t, ctx, args) {
        if ((ctx === window || ctx === document) && isBad(args[0])) return false;
        return Reflect.apply(t, ctx, args);
      },
    });
    nativeMap.set(hasGuard, 'function hasOwnProperty() { [native code] }');
    origDefine(Object.prototype, 'hasOwnProperty', {
      value: hasGuard, writable: true, configurable: true, enumerable: false,
    });

    /*
     * Прямое присваивание window.__selenium_evaluate = 1 обходит defineProperty.
     * Заранее ставим на известные имена ловушку: запись молча принимается,
     * чтение всегда возвращает undefined.
     */
    const installTraps = () => {
      EXACT.forEach((name) => {
        try {
          const cur = Object.getOwnPropertyDescriptor(window, name);
          if (cur && cur.get && cur.get.__mbaTrap) return;
          const trap = function () { return undefined; };
          trap.__mbaTrap = true;
          markNative(trap, 'get ' + name, 0);
          const setter = function () { return undefined; };
          markNative(setter, 'set ' + name, 1);
          origDefine(window, name, {
            get: trap, set: setter, configurable: true, enumerable: false,
          });
        } catch (e) {}
      });
    };
    installTraps();

    /* Дочищаем на случай, если драйвер добавит метку позже загрузки */
    let passes = 0;
    const sweep = () => {
      scrub(window);
      scrub(document);
      installTraps();
      if (++passes > 40) clearInterval(timerId);
    };
    const timerId = setInterval(sweep, 250);
    if (document.readyState !== 'complete') {
      window.addEventListener('load', sweep);
    }
  } catch (e) {}

  /*
   * Воркеры: сайт создаёт Worker и читает оттуда настоящие параметры машины.
   * Подкладываем свой скрипт перед оригиналом — воркер стартует уже с
   * подменённым отпечатком. Для blob и data URL патч дописываем в начало,
   * для обычных файлов подключаем оригинал через importScripts.
   */
  try {
    const SRC = ${JSON.stringify(workerPatch)};

    const makeShim = (url, opts) => {
      const abs = new URL(url, location.href).href;
      const isModule = opts && opts.type === 'module';
      const body = 'self.__mbaPatchSrc=' + JSON.stringify(SRC) + ';\\n' + SRC + '\\n'
        + (isModule ? 'import ' + JSON.stringify(abs) + ';' : 'importScripts(' + JSON.stringify(abs) + ');');
      return URL.createObjectURL(new Blob([body], { type: 'text/javascript' }));
    };

    if (window.Worker) {
      const OrigWorker = window.Worker;
      const PatchedWorker = function Worker(url, opts) {
        try {
          return new OrigWorker(makeShim(url, opts), opts);
        } catch (e) {
          return new OrigWorker(url, opts);
        }
      };
      PatchedWorker.prototype = OrigWorker.prototype;
      Object.setPrototypeOf(PatchedWorker, OrigWorker);
      markNative(PatchedWorker, 'Worker', 1);
      window.Worker = PatchedWorker;
    }

    if (window.SharedWorker) {
      const OrigShared = window.SharedWorker;
      const PatchedShared = function SharedWorker(url, opts) {
        try {
          return new OrigShared(makeShim(url, opts), opts);
        } catch (e) {
          return new OrigShared(url, opts);
        }
      };
      PatchedShared.prototype = OrigShared.prototype;
      Object.setPrototypeOf(PatchedShared, OrigShared);
      markNative(PatchedShared, 'SharedWorker', 1);
      window.SharedWorker = PatchedShared;
    }
  } catch (e) {}

  /*
   * Свежий iframe отдаёт нетронутые navigator и screen — через него легко
   * достать настоящие значения. Патчим каждый вновь созданный документ.
   */
  try {
    const desc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow');
    if (desc && desc.get) {
      const origGet = desc.get;
      Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
        get: markNative(function contentWindow() {
          const win = origGet.call(this);
          try {
            if (win && !win.__mbaSync) {
              win.__mbaSync = true;
              /* Значения копируем из текущего окна: оно уже пропатчено */
              ['userAgent', 'platform', 'hardwareConcurrency', 'deviceMemory', 'language', 'webdriver']
                .forEach((k) => {
                  try {
                    Object.defineProperty(win.navigator, k, {
                      get: () => navigator[k], configurable: true,
                    });
                  } catch (e) {}
                });
              ['width', 'height', 'availWidth', 'availHeight', 'colorDepth', 'pixelDepth']
                .forEach((k) => {
                  try {
                    Object.defineProperty(win.screen, k, {
                      get: () => screen[k], configurable: true,
                    });
                  } catch (e) {}
                });
            }
          } catch (e) {}
          return win;
        }, 'get contentWindow', 0),
        configurable: desc.configurable,
        enumerable: desc.enumerable,
      });
    }
  } catch (e) {}
})();`;
}

module.exports = { buildInjectScript, buildWorkerPatch };
