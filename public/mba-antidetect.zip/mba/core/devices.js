/*
 * База реальных конфигураций устройств.
 * Каждый пресет — цельная машина: система, железо, экран, шрифты.
 * weight — как часто такая машина встречается в реальности.
 */

const FONTS_WIN_BASE = [
  'Arial', 'Arial Black', 'Calibri', 'Cambria', 'Candara', 'Comic Sans MS',
  'Consolas', 'Constantia', 'Corbel', 'Courier New', 'Ebrima', 'Franklin Gothic Medium',
  'Gabriola', 'Georgia', 'Impact', 'Lucida Console', 'Lucida Sans Unicode',
  'Microsoft Sans Serif', 'Palatino Linotype', 'Segoe Print', 'Segoe Script',
  'Segoe UI', 'Sylfaen', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana', 'Webdings',
];

const FONTS_WIN11_EXTRA = ['Bahnschrift', 'Segoe UI Variable', 'Cascadia Code', 'Sitka'];
const FONTS_WIN10_EXTRA = ['MS Gothic', 'MV Boli', 'Nirmala UI'];

const FONTS_MAC_BASE = [
  'American Typewriter', 'Andale Mono', 'Arial', 'Arial Black', 'Avenir',
  'Avenir Next', 'Baskerville', 'Big Caslon', 'Bodoni 72', 'Bradley Hand',
  'Chalkboard', 'Cochin', 'Copperplate', 'Courier New', 'Didot', 'Futura',
  'Geneva', 'Georgia', 'Gill Sans', 'Helvetica', 'Helvetica Neue', 'Herculanum',
  'Hoefler Text', 'Impact', 'Lucida Grande', 'Luminari', 'Menlo', 'Monaco',
  'Optima', 'Palatino', 'Papyrus', 'Phosphate', 'Rockwell', 'Savoye LET',
  'SignPainter', 'Skia', 'Snell Roundhand', 'Times', 'Trattatello',
  'Trebuchet MS', 'Verdana', 'Zapfino',
];

const FONTS_MAC_MODERN = ['SF Pro', 'SF Mono', 'New York'];

/* Экраны, характерные для конкретного класса машин */
const SCREENS_DESKTOP_WIN = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 2560, height: 1440, ratio: 1 },
  { width: 1920, height: 1080, ratio: 1 },
  { width: 3840, height: 2160, ratio: 1.5 },
];

const SCREENS_LAPTOP_WIN = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 1536, height: 864, ratio: 1.25 },
  { width: 1366, height: 768, ratio: 1 },
  { width: 1600, height: 900, ratio: 1 },
];

/*
 * Экраны конкретных моделей. У каждой серии свои характерные разрешения:
 * ThinkPad — рабочие 1920x1080, Zenbook — OLED 2880x1800, XPS — 3.5K.
 * Именно по паре «экран + видеокарта» модель и опознаётся.
 */
const SCREENS_THINKPAD = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 1920, height: 1200, ratio: 1 },
  { width: 2560, height: 1600, ratio: 1.25 },
];

const SCREENS_ZENBOOK = [
  { width: 1920, height: 1080, ratio: 1.5 },
  { width: 2880, height: 1800, ratio: 2 },
  { width: 2560, height: 1600, ratio: 1.5 },
];

const SCREENS_PAVILION = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 1536, height: 864, ratio: 1.25 },
];

const SCREENS_XPS = [
  { width: 1920, height: 1200, ratio: 1.25 },
  { width: 3456, height: 2160, ratio: 2 },
  { width: 2560, height: 1600, ratio: 1.5 },
];

const SCREENS_GAMING_LAPTOP = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 2560, height: 1440, ratio: 1.25 },
];

const SCREENS_MACBOOK_AIR = [
  { width: 1470, height: 956, ratio: 2 },
  { width: 1512, height: 982, ratio: 2 },
];

const SCREENS_MACBOOK_PRO = [
  { width: 1512, height: 982, ratio: 2 },
  { width: 1728, height: 1117, ratio: 2 },
];

const SCREENS_IMAC = [
  { width: 2560, height: 1440, ratio: 1 },
  { width: 1920, height: 1080, ratio: 1 },
];

/*
 * DEVICES — комплекты. Внутри одного пресета всё согласовано:
 * не бывает Apple M2 с NVIDIA, не бывает Windows с Apple Metal Renderer,
 * не бывает RTX 4070 с 4 ГБ памяти.
 */
const DEVICES = [
  /* ===== Готовые модели ноутбуков: всё согласовано под конкретную серию ===== */
  {
    id: 'thinkpad-t14', laptop: true, brand: 'Lenovo ThinkPad T14',
    os: 'win', osVersion: '11.0', label: 'Lenovo ThinkPad T14 — рабочий',
    weight: 8,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon(TM) Graphics (0x00001638) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_THINKPAD,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'thinkpad-x1', laptop: true, brand: 'Lenovo ThinkPad X1 Carbon',
    os: 'win', osVersion: '11.0', label: 'Lenovo ThinkPad X1 Carbon — бизнес',
    weight: 6,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00009A49) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_THINKPAD,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'thinkpad-e15', laptop: true, brand: 'Lenovo ThinkPad E15',
    os: 'win', osVersion: '10.0', label: 'Lenovo ThinkPad E15 — бюджетный',
    weight: 7,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics (0x00009A78) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_PAVILION,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'zenbook-14', laptop: true, brand: 'ASUS Zenbook 14',
    os: 'win', osVersion: '11.0', label: 'ASUS Zenbook 14 — ультрабук OLED',
    weight: 7,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00007D55) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_ZENBOOK,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'zenbook-pro', laptop: true, brand: 'ASUS Zenbook Pro',
    os: 'win', osVersion: '11.0', label: 'ASUS Zenbook Pro — для работы с графикой',
    weight: 4,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Laptop GPU (0x000028E0) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [16, 24], memory: [16, 32],
    screens: SCREENS_ZENBOOK,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'asus-tuf', laptop: true, brand: 'ASUS TUF Gaming',
    os: 'win', osVersion: '11.0', label: 'ASUS TUF Gaming — игровой',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4050 Laptop GPU (0x000028A1) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_GAMING_LAPTOP,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'hp-pavilion', laptop: true, brand: 'HP Pavilion 15',
    os: 'win', osVersion: '11.0', label: 'HP Pavilion 15 — домашний',
    weight: 9,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x000046A8) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_PAVILION,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'hp-pavilion-amd', laptop: true, brand: 'HP Pavilion 15 AMD',
    os: 'win', osVersion: '10.0', label: 'HP Pavilion 15 AMD — домашний',
    weight: 7,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon(TM) Vega 8 Graphics (0x000015D8) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_PAVILION,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'hp-envy', laptop: true, brand: 'HP Envy',
    os: 'win', osVersion: '11.0', label: 'HP Envy — премиальный',
    weight: 5,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00007D45) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_ZENBOOK,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'dell-xps-13', laptop: true, brand: 'Dell XPS 13',
    os: 'win', osVersion: '11.0', label: 'Dell XPS 13 — компактный премиум',
    weight: 6,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00009A49) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_XPS,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'dell-xps-15', laptop: true, brand: 'Dell XPS 15',
    os: 'win', osVersion: '11.0', label: 'Dell XPS 15 — мощный премиум',
    weight: 5,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4050 Laptop GPU (0x000028A1) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [14, 16, 24], memory: [16, 32, 64],
    screens: SCREENS_XPS,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'dell-inspiron', laptop: true, brand: 'Dell Inspiron 15',
    os: 'win', osVersion: '11.0', label: 'Dell Inspiron 15 — офисный',
    weight: 8,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics (0x000046A3) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_PAVILION,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'acer-aspire', laptop: true, brand: 'Acer Aspire 5',
    os: 'win', osVersion: '11.0', label: 'Acer Aspire 5 — бюджетный',
    weight: 8,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics (0x000046A3) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_PAVILION,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'msi-katana', laptop: true, brand: 'MSI Katana',
    os: 'win', osVersion: '11.0', label: 'MSI Katana — игровой',
    weight: 4,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Laptop GPU (0x000028E0) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16, 24], memory: [16, 32],
    screens: SCREENS_GAMING_LAPTOP,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },

  /* ===== Windows 11, игровые и мощные ПК ===== */
  {
    id: 'win11-rtx4090',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 4090',
    weight: 3,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 (0x00002684) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [16, 24, 32], memory: [32, 64],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx4080',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 4080',
    weight: 4,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4080 (0x00002704) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [16, 24], memory: [32, 64],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx4070',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 4070',
    weight: 7,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 (0x00002786) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx3080',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 3080',
    weight: 5,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 (0x00002206) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx3070',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 3070',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 (0x00002484) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx4060ti',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 4060 Ti',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Ti (0x00002803) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rx7800xt',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и Radeon RX 7800 XT',
    weight: 4,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 7800 XT (0x0000747E) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [32, 64],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rx7600',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и Radeon RX 7600',
    weight: 5,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 7600 (0x00007480) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rx6700xt',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и Radeon RX 6700 XT',
    weight: 5,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6700 XT (0x000073DF) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-arc-a750',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и Intel Arc A750',
    weight: 2,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Arc(TM) A750 Graphics (0x000056A1) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-uhd770',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 без видеокарты',
    weight: 7,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 770 (0x00004680) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx4060-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и RTX 4060',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Laptop GPU (0x000028E0) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx4050-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и RTX 4050',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4050 Laptop GPU (0x000028A1) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-radeon-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и AMD Radeon 780M',
    weight: 5,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon(TM) 780M Graphics (0x000015BF) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },

  {
    id: 'win11-rtx4060',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 4060',
    weight: 9,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 (0x00002882) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx3060',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 3060',
    weight: 10,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002503) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rx6600',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и Radeon RX 6600',
    weight: 5,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6600 (0x000073FF) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-iris-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и Intel Iris Xe',
    weight: 14,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x000046A8) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx3050-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и RTX 3050',
    weight: 7,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3050 Laptop GPU (0x000025A2) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },

  /* ===== Windows 10, массовые машины ===== */
  {
    id: 'win10-rtx2060',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и RTX 2060',
    weight: 5,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 2060 (0x00001F08) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [6, 8, 12], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-gtx1660',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и GTX 1660 Super',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER (0x000021C4) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [6, 8, 12], memory: [8, 16],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-rx580',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и Radeon RX 580',
    weight: 5,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 580 2048SP (0x00006FDF) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-uhd620', laptop: true,
    os: 'win', osVersion: '10.0', label: 'Офисный ноутбук с Windows 10',
    weight: 7,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 620 (0x00003EA0) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 8], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-uhd630',
    os: 'win', osVersion: '10.0', label: 'Офисный ПК с Windows 10',
    weight: 13,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-gtx1650',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и GTX 1650',
    weight: 8,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 (0x00001F82) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-gtx1060',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и GTX 1060',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1060 6GB (0x00001C03) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-vega', laptop: true,
    os: 'win', osVersion: '10.0', label: 'Ноутбук с Windows 10 и AMD Vega',
    weight: 4,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon(TM) Vega 8 Graphics (0x000015D8) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 8], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },

  /* ===== macOS, Apple Silicon ===== */
  {
    id: 'mac-m1-air', laptop: true,
    os: 'mac', osVersion: '14_4_1', label: 'MacBook Air M1',
    weight: 9,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)' },
    cores: [8], memory: [8, 16],
    screens: SCREENS_MACBOOK_AIR,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m2-air', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Air M2',
    weight: 8,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)' },
    cores: [8], memory: [8, 16, 24],
    screens: SCREENS_MACBOOK_AIR,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m2pro', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Pro M2 Pro',
    weight: 5,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)' },
    cores: [10, 12], memory: [16, 32],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m3', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Pro M3',
    weight: 5,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3, Unspecified Version)' },
    cores: [8, 11], memory: [16, 24],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m1pro', laptop: true,
    os: 'mac', osVersion: '14_6_1', label: 'MacBook Pro M1 Pro',
    weight: 6,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1 Pro, Unspecified Version)' },
    cores: [8, 10], memory: [16, 32],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m1max', laptop: true,
    os: 'mac', osVersion: '14_6_1', label: 'MacBook Pro M1 Max',
    weight: 3,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1 Max, Unspecified Version)' },
    cores: [10], memory: [32, 64],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m3pro', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Pro M3 Pro',
    weight: 6,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3 Pro, Unspecified Version)' },
    cores: [11, 12], memory: [18, 36],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m3max', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Pro M3 Max',
    weight: 3,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3 Max, Unspecified Version)' },
    cores: [14, 16], memory: [36, 64],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m4', laptop: true,
    os: 'mac', osVersion: '15_2', label: 'MacBook Pro M4',
    weight: 5,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M4, Unspecified Version)' },
    cores: [10], memory: [16, 24, 32],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m4pro', laptop: true,
    os: 'mac', osVersion: '15_2', label: 'MacBook Pro M4 Pro',
    weight: 4,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M4 Pro, Unspecified Version)' },
    cores: [12, 14], memory: [24, 48],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m2-mini',
    os: 'mac', osVersion: '15_1', label: 'Mac mini M2',
    weight: 4,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)' },
    cores: [8], memory: [8, 16, 24],
    screens: SCREENS_IMAC,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m3-imac',
    os: 'mac', osVersion: '15_1', label: 'iMac M3',
    weight: 3,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3, Unspecified Version)' },
    cores: [8], memory: [8, 16, 24],
    screens: SCREENS_IMAC,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-intel-mbp', laptop: true,
    os: 'mac', osVersion: '13_6_9', label: 'MacBook Pro на Intel',
    weight: 3,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(TM) Plus Graphics 655, OpenGL 4.1)' },
    cores: [4, 8], memory: [8, 16],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE,
  },
  {
    id: 'mac-intel-imac',
    os: 'mac', osVersion: '13_5_2', label: 'iMac на Intel',
    weight: 3,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630, OpenGL 4.1)' },
    cores: [6, 8], memory: [8, 16],
    screens: SCREENS_IMAC,
    fonts: FONTS_MAC_BASE,
    intel: true,
  },
];

const CHROME_VERSIONS = ['131.0.6778.86', '132.0.6834.84', '133.0.6943.54'];

/* Соответствие ручного выбора видеокарты пресету устройства */
/* Связь выбранной видеокарты с комплектом устройства */
const GPU_TO_DEVICE = {
  /* Готовые модели ноутбуков */
  'lenovo-thinkpad-t14': 'thinkpad-t14',
  'lenovo-thinkpad-x1': 'thinkpad-x1',
  'lenovo-thinkpad-e15': 'thinkpad-e15',
  'asus-zenbook-14': 'zenbook-14',
  'asus-zenbook-pro': 'zenbook-pro',
  'asus-tuf': 'asus-tuf',
  'hp-pavilion': 'hp-pavilion',
  'hp-pavilion-amd': 'hp-pavilion-amd',
  'hp-envy': 'hp-envy',
  'dell-xps-13': 'dell-xps-13',
  'dell-xps-15': 'dell-xps-15',
  'dell-inspiron': 'dell-inspiron',
  'acer-aspire': 'acer-aspire',
  'msi-katana': 'msi-katana',

  'nvidia-rtx4090': 'win11-rtx4090',
  'nvidia-rtx4080': 'win11-rtx4080',
  'nvidia-rtx4070': 'win11-rtx4070',
  'nvidia-rtx4060ti': 'win11-rtx4060ti',
  'nvidia-rtx4060': 'win11-rtx4060',
  'nvidia-rtx3080': 'win11-rtx3080',
  'nvidia-rtx3070': 'win11-rtx3070',
  'nvidia-rtx3060': 'win11-rtx3060',
  'nvidia-rtx2060': 'win10-rtx2060',
  'nvidia-gtx1660': 'win10-gtx1660',
  'nvidia-gtx1650': 'win10-gtx1650',
  'nvidia-gtx1060': 'win10-gtx1060',
  'nvidia-rtx4060-laptop': 'win11-rtx4060-laptop',
  'nvidia-rtx4050-laptop': 'win11-rtx4050-laptop',
  'nvidia-rtx3050-laptop': 'win11-rtx3050-laptop',
  'amd-rx7800xt': 'win11-rx7800xt',
  'amd-rx7600': 'win11-rx7600',
  'amd-rx6700xt': 'win11-rx6700xt',
  'amd-rx6600': 'win11-rx6600',
  'amd-rx580': 'win10-rx580',
  'amd-780m': 'win11-radeon-laptop',
  'amd-vega8': 'win10-vega',
  'intel-arc-a750': 'win11-arc-a750',
  'intel-uhd770': 'win11-uhd770',
  'intel-uhd630': 'win10-uhd630',
  'intel-uhd620': 'win10-uhd620',
  'intel-iris': 'win11-iris-laptop',
  'apple-m1': 'mac-m1-air',
  'apple-m1pro': 'mac-m1pro',
  'apple-m1max': 'mac-m1max',
  'apple-m2': 'mac-m2-air',
  'apple-m2pro': 'mac-m2pro',
  'apple-m2-mini': 'mac-m2-mini',
  'apple-m3': 'mac-m3',
  'apple-m3pro': 'mac-m3pro',
  'apple-m3max': 'mac-m3max',
  'apple-m3-imac': 'mac-m3-imac',
  'apple-m4': 'mac-m4',
  'apple-m4pro': 'mac-m4pro',
  'mac-intel-mbp': 'mac-intel-mbp',
  'mac-intel-imac': 'mac-intel-imac',
};


const pickWeighted = (rand, list) => {
  const total = list.reduce((sum, item) => sum + (item.weight || 1), 0);
  let point = rand() * total;
  for (const item of list) {
    point -= item.weight || 1;
    if (point <= 0) return item;
  }
  return list[list.length - 1];
};

/* Раскладки клавиатуры по странам — реальные коды KeyboardLayoutMap */
const KEYBOARD_LAYOUTS = {
  'en-US': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'en-GB': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'de-DE': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'y', Semicolon: 'ö', Quote: 'ä', BracketLeft: 'ü', Comma: ',', Slash: '-' },
  'fr-FR': { KeyQ: 'a', KeyW: 'z', KeyE: 'e', KeyA: 'q', KeyZ: 'w', Semicolon: 'm', Quote: 'ù', BracketLeft: '^', Comma: ';', Slash: '!' },
  'pl-PL': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'nl-NL': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'es-ES': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: 'ñ', Quote: "'", BracketLeft: '`', Comma: ',', Slash: '-' },
  'it-IT': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: 'ò', Quote: 'à', BracketLeft: 'è', Comma: ',', Slash: '-' },
  'ru-RU': { KeyQ: 'й', KeyW: 'ц', KeyE: 'у', KeyA: 'ф', KeyZ: 'я', Semicolon: 'ж', Quote: 'э', BracketLeft: 'х', Comma: 'б', Slash: '.' },
};

/* Голоса синтеза речи — набор жёстко привязан к системе */
const VOICES_WIN = [
  { name: 'Microsoft David - English (United States)', lang: 'en-US', localService: true, default: true },
  { name: 'Microsoft Zira - English (United States)', lang: 'en-US', localService: true, default: false },
  { name: 'Microsoft Mark - English (United States)', lang: 'en-US', localService: true, default: false },
];

const VOICES_MAC = [
  { name: 'Samantha', lang: 'en-US', localService: true, default: true },
  { name: 'Alex', lang: 'en-US', localService: true, default: false },
  { name: 'Daniel', lang: 'en-GB', localService: true, default: false },
  { name: 'Karen', lang: 'en-AU', localService: true, default: false },
];

const VOICES_LOCALE = {
  'de-DE': [{ name: 'Anna', lang: 'de-DE', localService: true, default: false }],
  'fr-FR': [{ name: 'Thomas', lang: 'fr-FR', localService: true, default: false }],
  'ru-RU': [{ name: 'Milena', lang: 'ru-RU', localService: true, default: false }],
  'pl-PL': [{ name: 'Zosia', lang: 'pl-PL', localService: true, default: false }],
  'es-ES': [{ name: 'Monica', lang: 'es-ES', localService: true, default: false }],
  'it-IT': [{ name: 'Alice', lang: 'it-IT', localService: true, default: false }],
  'nl-NL': [{ name: 'Xander', lang: 'nl-NL', localService: true, default: false }],
};

/* Устройства ввода: реальные наборы для ноутбука и стационарного ПК */
const MEDIA_LAPTOP = [
  { kind: 'audioinput', label: '', groupPrefix: 'g1' },
  { kind: 'videoinput', label: '', groupPrefix: 'g2' },
  { kind: 'audiooutput', label: '', groupPrefix: 'g1' },
];

const MEDIA_DESKTOP = [
  { kind: 'audioinput', label: '', groupPrefix: 'g1' },
  { kind: 'audiooutput', label: '', groupPrefix: 'g1' },
];

module.exports = { DEVICES, CHROME_VERSIONS, GPU_TO_DEVICE, pickWeighted, KEYBOARD_LAYOUTS, VOICES_WIN, VOICES_MAC, VOICES_LOCALE, MEDIA_LAPTOP, MEDIA_DESKTOP };
