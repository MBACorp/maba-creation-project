/*
 * База реальных конфигураций устройств.
 * Каждый пресет — цельная машина: система, железо, экран, шрифты.
 * weight — как часто такая машина встречается в реальности.
 */

const FONTS_WIN_BASE = [
  'Arial', 'Arial Black', 'Calibri', 'Cambria', 'Candara', 'Comic Sans MS',
  'Consolas', 'Constantia', 'Corbel', 'Courier New', 'Ebrima', 'Franklin Gothic Medium',
  'Gabriola', 'Georgia', 'Impact', 'Lucida Console', 'Lucida Sans Unicode',
  'Microsoft Sans Serif', 'Palatino Linotype', 'Segoe Print', 'Segoe Script',
  'Segoe UI', 'Sylfaen', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana', 'Webdings',
];

const FONTS_WIN11_EXTRA = ['Bahnschrift', 'Segoe UI Variable', 'Cascadia Code', 'Sitka'];
const FONTS_WIN10_EXTRA = ['MS Gothic', 'MV Boli', 'Nirmala UI'];

const FONTS_MAC_BASE = [
  'American Typewriter', 'Andale Mono', 'Arial', 'Arial Black', 'Avenir',
  'Avenir Next', 'Baskerville', 'Big Caslon', 'Bodoni 72', 'Bradley Hand',
  'Chalkboard', 'Cochin', 'Copperplate', 'Courier New', 'Didot', 'Futura',
  'Geneva', 'Georgia', 'Gill Sans', 'Helvetica', 'Helvetica Neue', 'Herculanum',
  'Hoefler Text', 'Impact', 'Lucida Grande', 'Luminari', 'Menlo', 'Monaco',
  'Optima', 'Palatino', 'Papyrus', 'Phosphate', 'Rockwell', 'Savoye LET',
  'SignPainter', 'Skia', 'Snell Roundhand', 'Times', 'Trattatello',
  'Trebuchet MS', 'Verdana', 'Zapfino',
];

const FONTS_MAC_MODERN = ['SF Pro', 'SF Mono', 'New York'];

/* Экраны, характерные для конкретного класса машин */
const SCREENS_DESKTOP_WIN = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 2560, height: 1440, ratio: 1 },
  { width: 1920, height: 1080, ratio: 1 },
  { width: 3840, height: 2160, ratio: 1.5 },
];

const SCREENS_LAPTOP_WIN = [
  { width: 1920, height: 1080, ratio: 1 },
  { width: 1536, height: 864, ratio: 1.25 },
  { width: 1366, height: 768, ratio: 1 },
  { width: 1600, height: 900, ratio: 1 },
];

const SCREENS_MACBOOK_AIR = [
  { width: 1470, height: 956, ratio: 2 },
  { width: 1512, height: 982, ratio: 2 },
];

const SCREENS_MACBOOK_PRO = [
  { width: 1512, height: 982, ratio: 2 },
  { width: 1728, height: 1117, ratio: 2 },
];

const SCREENS_IMAC = [
  { width: 2560, height: 1440, ratio: 1 },
  { width: 1920, height: 1080, ratio: 1 },
];

/*
 * DEVICES — комплекты. Внутри одного пресета всё согласовано:
 * не бывает Apple M2 с NVIDIA, не бывает Windows с Apple Metal Renderer,
 * не бывает RTX 4070 с 4 ГБ памяти.
 */
const DEVICES = [
  /* ===== Windows 11, игровые и мощные ПК ===== */
  {
    id: 'win11-rtx4060',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 4060',
    weight: 9,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 (0x00002882) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx3060',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и RTX 3060',
    weight: 10,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002503) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12, 16], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rx6600',
    os: 'win', osVersion: '11.0', label: 'ПК с Windows 11 и Radeon RX 6600',
    weight: 5,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon RX 6600 (0x000073FF) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [16, 32],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-iris-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и Intel Iris Xe',
    weight: 14,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x000046A8) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },
  {
    id: 'win11-rtx3050-laptop', laptop: true,
    os: 'win', osVersion: '11.0', label: 'Ноутбук с Windows 11 и RTX 3050',
    weight: 7,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3050 Laptop GPU (0x000025A2) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [8, 12], memory: [16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN11_EXTRA),
  },

  /* ===== Windows 10, массовые машины ===== */
  {
    id: 'win10-uhd630',
    os: 'win', osVersion: '10.0', label: 'Офисный ПК с Windows 10',
    weight: 13,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E92) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-gtx1650',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и GTX 1650',
    weight: 8,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 (0x00001F82) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-gtx1060',
    os: 'win', osVersion: '10.0', label: 'ПК с Windows 10 и GTX 1060',
    weight: 6,
    gpu: { vendor: 'Google Inc. (NVIDIA)', renderer: 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1060 6GB (0x00001C03) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 6, 8], memory: [8, 16],
    screens: SCREENS_DESKTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },
  {
    id: 'win10-vega', laptop: true,
    os: 'win', osVersion: '10.0', label: 'Ноутбук с Windows 10 и AMD Vega',
    weight: 4,
    gpu: { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon(TM) Vega 8 Graphics (0x000015D8) Direct3D11 vs_5_0 ps_5_0, D3D11)' },
    cores: [4, 8], memory: [8, 16],
    screens: SCREENS_LAPTOP_WIN,
    fonts: FONTS_WIN_BASE.concat(FONTS_WIN10_EXTRA),
  },

  /* ===== macOS, Apple Silicon ===== */
  {
    id: 'mac-m1-air', laptop: true,
    os: 'mac', osVersion: '14_4_1', label: 'MacBook Air M1',
    weight: 9,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)' },
    cores: [8], memory: [8, 16],
    screens: SCREENS_MACBOOK_AIR,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m2-air', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Air M2',
    weight: 8,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)' },
    cores: [8], memory: [8, 16, 24],
    screens: SCREENS_MACBOOK_AIR,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m2pro', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Pro M2 Pro',
    weight: 5,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)' },
    cores: [10, 12], memory: [16, 32],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-m3', laptop: true,
    os: 'mac', osVersion: '15_1', label: 'MacBook Pro M3',
    weight: 5,
    gpu: { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3, Unspecified Version)' },
    cores: [8, 11], memory: [16, 24],
    screens: SCREENS_MACBOOK_PRO,
    fonts: FONTS_MAC_BASE.concat(FONTS_MAC_MODERN),
  },
  {
    id: 'mac-intel-imac',
    os: 'mac', osVersion: '13_5_2', label: 'iMac на Intel',
    weight: 3,
    gpu: { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Intel(R) UHD Graphics 630, OpenGL 4.1)' },
    cores: [6, 8], memory: [8, 16],
    screens: SCREENS_IMAC,
    fonts: FONTS_MAC_BASE,
    intel: true,
  },
];

const CHROME_VERSIONS = ['131.0.6778.86', '132.0.6834.84', '133.0.6943.54'];

/* Соответствие ручного выбора видеокарты пресету устройства */
const GPU_TO_DEVICE = {
  'nvidia-rtx3060': 'win11-rtx3060',
  'nvidia-gtx1650': 'win10-gtx1650',
  'intel-uhd630': 'win10-uhd630',
  'intel-iris': 'win11-iris-laptop',
  'amd-rx6600': 'win11-rx6600',
  'apple-m1': 'mac-m1-air',
  'apple-m2pro': 'mac-m2pro',
  'apple-m3': 'mac-m3',
};

const pickWeighted = (rand, list) => {
  const total = list.reduce((sum, item) => sum + (item.weight || 1), 0);
  let point = rand() * total;
  for (const item of list) {
    point -= item.weight || 1;
    if (point <= 0) return item;
  }
  return list[list.length - 1];
};

/* Раскладки клавиатуры по странам — реальные коды KeyboardLayoutMap */
const KEYBOARD_LAYOUTS = {
  'en-US': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'en-GB': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'de-DE': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'y', Semicolon: 'ö', Quote: 'ä', BracketLeft: 'ü', Comma: ',', Slash: '-' },
  'fr-FR': { KeyQ: 'a', KeyW: 'z', KeyE: 'e', KeyA: 'q', KeyZ: 'w', Semicolon: 'm', Quote: 'ù', BracketLeft: '^', Comma: ';', Slash: '!' },
  'pl-PL': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'nl-NL': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: ';', Quote: "'", BracketLeft: '[', Comma: ',', Slash: '/' },
  'es-ES': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: 'ñ', Quote: "'", BracketLeft: '`', Comma: ',', Slash: '-' },
  'it-IT': { KeyQ: 'q', KeyW: 'w', KeyE: 'e', KeyA: 'a', KeyZ: 'z', Semicolon: 'ò', Quote: 'à', BracketLeft: 'è', Comma: ',', Slash: '-' },
  'ru-RU': { KeyQ: 'й', KeyW: 'ц', KeyE: 'у', KeyA: 'ф', KeyZ: 'я', Semicolon: 'ж', Quote: 'э', BracketLeft: 'х', Comma: 'б', Slash: '.' },
};

/* Голоса синтеза речи — набор жёстко привязан к системе */
const VOICES_WIN = [
  { name: 'Microsoft David - English (United States)', lang: 'en-US', localService: true, default: true },
  { name: 'Microsoft Zira - English (United States)', lang: 'en-US', localService: true, default: false },
  { name: 'Microsoft Mark - English (United States)', lang: 'en-US', localService: true, default: false },
];

const VOICES_MAC = [
  { name: 'Samantha', lang: 'en-US', localService: true, default: true },
  { name: 'Alex', lang: 'en-US', localService: true, default: false },
  { name: 'Daniel', lang: 'en-GB', localService: true, default: false },
  { name: 'Karen', lang: 'en-AU', localService: true, default: false },
];

const VOICES_LOCALE = {
  'de-DE': [{ name: 'Anna', lang: 'de-DE', localService: true, default: false }],
  'fr-FR': [{ name: 'Thomas', lang: 'fr-FR', localService: true, default: false }],
  'ru-RU': [{ name: 'Milena', lang: 'ru-RU', localService: true, default: false }],
  'pl-PL': [{ name: 'Zosia', lang: 'pl-PL', localService: true, default: false }],
  'es-ES': [{ name: 'Monica', lang: 'es-ES', localService: true, default: false }],
  'it-IT': [{ name: 'Alice', lang: 'it-IT', localService: true, default: false }],
  'nl-NL': [{ name: 'Xander', lang: 'nl-NL', localService: true, default: false }],
};

/* Устройства ввода: реальные наборы для ноутбука и стационарного ПК */
const MEDIA_LAPTOP = [
  { kind: 'audioinput', label: '', groupPrefix: 'g1' },
  { kind: 'videoinput', label: '', groupPrefix: 'g2' },
  { kind: 'audiooutput', label: '', groupPrefix: 'g1' },
];

const MEDIA_DESKTOP = [
  { kind: 'audioinput', label: '', groupPrefix: 'g1' },
  { kind: 'audiooutput', label: '', groupPrefix: 'g1' },
];

module.exports = { DEVICES, CHROME_VERSIONS, GPU_TO_DEVICE, pickWeighted, KEYBOARD_LAYOUTS, VOICES_WIN, VOICES_MAC, VOICES_LOCALE, MEDIA_LAPTOP, MEDIA_DESKTOP };
