const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('MBA', {
  isDesktop: true,
  platform: process.platform,

  listProfiles: () => ipcRenderer.invoke('profiles:list'),
  saveProfile: (profile) => ipcRenderer.invoke('profiles:save', profile),
  deleteProfile: (id) => ipcRenderer.invoke('profiles:delete', id),
  startProfile: (profile) => ipcRenderer.invoke('profiles:start', profile),
  startProfiles: (list) => ipcRenderer.invoke('profiles:startMany', list),
  onStartProgress: (cb) => ipcRenderer.on('profiles:progress', (_e, p) => cb(p)),
  stopProfile: (id) => ipcRenderer.invoke('profiles:stop', id),

  checkUpdate: (opts) => ipcRenderer.invoke('update:check', opts),
  updateState: () => ipcRenderer.invoke('update:state'),
  onUpdateState: (cb) => ipcRenderer.on('update:state', (_e, s) => cb(s)),

  auditProfile: (payload) => ipcRenderer.invoke('profiles:audit', payload),

  listCookies: (profileId) => ipcRenderer.invoke('cookies:list', profileId),
  importCookies: (payload) => ipcRenderer.invoke('cookies:import', payload),
  exportCookies: (payload) => ipcRenderer.invoke('cookies:export', payload),
  clearCookies: (profileId) => ipcRenderer.invoke('cookies:clear', profileId),
  pickCookieFile: () => ipcRenderer.invoke('cookies:pickFile'),

  listProxies: () => ipcRenderer.invoke('proxies:list'),
  saveProxy: (proxy) => ipcRenderer.invoke('proxies:save', proxy),
  deleteProxy: (id) => ipcRenderer.invoke('proxies:delete', id),
  checkProxy: (proxy) => ipcRenderer.invoke('proxies:check', proxy),
  myIp: () => ipcRenderer.invoke('proxies:myip'),

  appInfo: () => ipcRenderer.invoke('app:info'),
  openDataFolder: () => ipcRenderer.invoke('app:openData'),

  onProfileStarted: (cb) => ipcRenderer.on('profile:started', (_e, id) => cb(id)),
  onProfileStopped: (cb) => ipcRenderer.on('profile:stopped', (_e, id) => cb(id)),
});
