const path = require('path');
const fs = require('fs');
const { app, BrowserWindow, Menu, ipcMain, shell, dialog, protocol, net } = require('electron');
const { pathToFileURL } = require('url');
const { Storage } = require('./core/storage');
const launcher = require('./core/launcher');
const cookieStore = require('./core/cookies');
const updater = require('./core/updater');
const proxyCheck = require('./core/proxycheck');
const config = require('./config.json');

let mainWindow = null;
let storage = null;

const dataRoot = () => app.getPath('userData');

const send = (channel, payload) => {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
};

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: '#0D0B08',
    show: false,
    autoHideMenuBar: process.platform !== 'darwin',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  /*
   * Если указан адрес сайта — берём интерфейс оттуда: правки появляются
   * сразу, пересобирать приложение не нужно. Нет интернета или сайт не
   * ответил — открываем встроенную копию, приложение работает как раньше.
   */
  const remote = (config.appUrl || '').trim();

  if (remote) {
    mainWindow.loadURL(remote).catch(() => mainWindow.loadURL('mba://app/'));
    mainWindow.webContents.on('did-fail-load', (_e, code) => {
      if (code === -3) return;
      mainWindow.loadURL('mba://app/');
    });
  } else {
    mainWindow.loadURL('mba://app/');
  }

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.on('closed', () => { mainWindow = null; });
};

const buildMenu = () => {
  const template = [
    ...(process.platform === 'darwin'
      ? [{
          label: 'MBA',
          submenu: [
            { role: 'about', label: 'О программе MBA' },
            { type: 'separator' },
            { role: 'hide', label: 'Скрыть MBA' },
            { role: 'quit', label: 'Выйти' },
          ],
        }]
      : []),
    {
      label: 'Файл',
      submenu: [
        {
          label: 'Проверить обновления…',
          click: () => runUpdateCheck({ silent: false }),
        },
        {
          label: 'Папка с данными профилей',
          click: () => shell.openPath(dataRoot()),
        },
        {
          label: 'Загрузить свежую версию интерфейса',
          accelerator: 'CmdOrCtrl+Shift+R',
          click: () => {
            if (!mainWindow || mainWindow.isDestroyed()) return;
            /* Чистим сохранённые файлы, чтобы точно взялась новая версия */
            mainWindow.webContents.session.clearCache().then(() => {
              mainWindow.webContents.reloadIgnoringCache();
            });
          },
        },
        { role: 'reload', label: 'Обновить окно' },
        { type: 'separator' },
        { role: 'quit', label: 'Выход' },
      ],
    },
    {
      label: 'Правка',
      submenu: [
        { role: 'undo', label: 'Отменить' },
        { role: 'redo', label: 'Повторить' },
        { type: 'separator' },
        { role: 'cut', label: 'Вырезать' },
        { role: 'copy', label: 'Копировать' },
        { role: 'paste', label: 'Вставить' },
        { role: 'selectAll', label: 'Выделить всё' },
      ],
    },
    {
      label: 'Вид',
      submenu: [
        { role: 'zoomIn', label: 'Увеличить' },
        { role: 'zoomOut', label: 'Уменьшить' },
        { role: 'resetZoom', label: 'Обычный размер' },
        { type: 'separator' },
        { role: 'toggleDevTools', label: 'Инструменты разработчика' },
        { role: 'togglefullscreen', label: 'Во весь экран' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
};

ipcMain.handle('profiles:list', () => ({
  profiles: storage.listProfiles(),
  running: launcher.runningIds(),
}));

ipcMain.handle('profiles:save', (_e, profile) => storage.saveProfile(profile));
ipcMain.handle('profiles:delete', async (_e, id) => {
  await launcher.stopProfile(id);
  storage.deleteProfile(id);
  return true;
});

ipcMain.handle('profiles:start', async (_e, profile) => {
  try {
    const result = await launcher.launchProfile(profile, dataRoot(), (id) => {
      send('profile:stopped', id);
    });
    send('profile:started', profile.id);
    return { ok: true, ...result };
  } catch (error) {
    return { ok: false, error: String((error && error.message) || error) };
  }
});

ipcMain.handle('profiles:stop', async (_e, id) => {
  const stopped = await launcher.stopProfile(id);
  send('profile:stopped', id);
  return { ok: stopped };
});

let updateState = { status: 'idle' };

const sendUpdate = (payload) => {
  updateState = payload;
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('update:state', payload);
  }
};

/* Скачивает обновление и предлагает установить */
async function downloadAndInstall(info) {
  sendUpdate({ status: 'downloading', version: info.version, percent: 0 });

  try {
    const file = await updater.downloadUpdate(info, (p) => {
      sendUpdate({
        status: 'downloading',
        version: info.version,
        percent: p.percent,
        loaded: p.loaded,
        total: p.total,
      });
    });

    sendUpdate({ status: 'ready', version: info.version, path: file.path });

    const answer = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      buttons: ['Установить и перезапустить', 'Позже'],
      defaultId: 0,
      cancelId: 1,
      title: 'Обновление готово',
      message: 'Версия ' + info.version + ' загружена',
      detail: info.notes
        ? info.notes + '\n\nПрофили и куки сохранятся.'
        : 'Профили и куки сохранятся. Приложение закроется и откроется установщик.',
    });

    if (answer.response === 0) {
      await launcher.stopAll().catch(() => undefined);
      updater.runInstaller(file.path, app);
    }
  } catch (error) {
    const message = String((error && error.message) || error);
    sendUpdate({ status: 'error', error: message });
    dialog.showMessageBox(mainWindow, {
      type: 'error',
      title: 'Обновление',
      message: 'Не удалось загрузить обновление',
      detail: message,
    });
  }
}

async function runUpdateCheck(opts) {
  const silent = !opts || opts.silent !== false;
  sendUpdate({ status: 'checking' });

  try {
    const info = await updater.checkUpdate(config.releasesUrl, app.getVersion());

    if (!info.available) {
      sendUpdate({ status: 'idle', current: app.getVersion() });
      if (!silent) {
        dialog.showMessageBox(mainWindow, {
          type: 'info',
          title: 'Обновления',
          message: 'У вас последняя версия',
          detail: 'Установлена версия ' + app.getVersion() + '.',
        });
      }
      return { available: false };
    }

    sendUpdate({ status: 'available', version: info.version, notes: info.notes, size: info.fileSize });

    const sizeMb = info.fileSize ? ' (' + (info.fileSize / 1048576).toFixed(0) + ' МБ)' : '';
    const answer = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      buttons: info.mandatory ? ['Обновить'] : ['Обновить сейчас', 'Позже'],
      defaultId: 0,
      cancelId: info.mandatory ? 0 : 1,
      title: 'Доступно обновление',
      message: 'Вышла версия ' + info.version + sizeMb,
      detail: info.notes || 'Приложение скачает и установит обновление само.',
    });

    if (answer.response === 0) {
      downloadAndInstall(info);
      return { available: true, downloading: true };
    }

    sendUpdate({ status: 'postponed', version: info.version });
    return { available: true, downloading: false };
  } catch (error) {
    const message = String((error && error.message) || error);
    sendUpdate({ status: 'error', error: message });
    if (!silent) {
      dialog.showMessageBox(mainWindow, {
        type: 'error',
        title: 'Обновления',
        message: 'Не удалось проверить обновления',
        detail: message,
      });
    }
    return { available: false, error: true };
  }
}

ipcMain.handle('update:check', (_e, opts) => runUpdateCheck(opts));
ipcMain.handle('update:state', () => updateState);

ipcMain.handle('profiles:audit', async (_e, { id, site }) => {
  return launcher.audit(id, site);
});

ipcMain.handle('cookies:list', (_e, profileId) => {
  const cookies = cookieStore.readStore(dataRoot(), profileId);
  return cookieStore.summarize(cookies);
});

ipcMain.handle('cookies:import', (_e, { profileId, text, replace }) => {
  try {
    const parsed = cookieStore.parseCookies(text);
    if (!parsed.length) return { ok: false, error: 'В файле не найдено ни одной куки' };

    const current = replace ? [] : cookieStore.readStore(dataRoot(), profileId);
    const map = new Map();
    current.concat(parsed).forEach((c) => {
      map.set(`${c.domain}|${c.path}|${c.name}`, c);
    });
    const merged = [...map.values()];

    cookieStore.writeStore(dataRoot(), profileId, merged);
    return { ok: true, added: parsed.length, total: merged.length, summary: cookieStore.summarize(merged) };
  } catch (error) {
    return { ok: false, error: String((error && error.message) || error) };
  }
});

ipcMain.handle('cookies:export', async (_e, { profileId, profileName, format }) => {
  const cookies = cookieStore.readStore(dataRoot(), profileId);
  if (!cookies.length) return { ok: false, error: 'У профиля нет сохранённых куки' };

  const isNetscape = format === 'netscape';
  const safeName = String(profileName || profileId).replace(/[^A-Za-z0-9_-]+/g, '_');
  const { canceled, filePath } = await dialog.showSaveDialog({
    title: 'Сохранить куки',
    defaultPath: `${safeName}-cookies.${isNetscape ? 'txt' : 'json'}`,
    filters: isNetscape
      ? [{ name: 'Netscape cookies', extensions: ['txt'] }]
      : [{ name: 'JSON', extensions: ['json'] }],
  });
  if (canceled || !filePath) return { ok: false, canceled: true };

  const body = isNetscape
    ? cookieStore.toNetscape(cookies)
    : JSON.stringify(cookies, null, 2);
  fs.writeFileSync(filePath, body, 'utf8');
  return { ok: true, count: cookies.length, filePath };
});

ipcMain.handle('cookies:clear', (_e, profileId) => {
  cookieStore.writeStore(dataRoot(), profileId, []);
  return { ok: true };
});

ipcMain.handle('cookies:pickFile', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog({
    title: 'Выберите файл с куки',
    properties: ['openFile'],
    filters: [
      { name: 'Куки', extensions: ['json', 'txt'] },
      { name: 'Все файлы', extensions: ['*'] },
    ],
  });
  if (canceled || !filePaths.length) return { ok: false, canceled: true };
  return { ok: true, text: fs.readFileSync(filePaths[0], 'utf8'), name: path.basename(filePaths[0]) };
});

ipcMain.handle('proxies:list', () => storage.listProxies());
ipcMain.handle('proxies:save', (_e, proxy) => storage.saveProxy(proxy));
/* Проверка прокси до запуска профиля: живой ли, какой IP и откуда */
ipcMain.handle('proxies:check', async (_e, proxy) => {
  const result = await proxyCheck.checkProxy(proxy);
  if (result.ok) {
    const real = await proxyCheck.ownIp();
    /* Совпал внешний адрес с нашим — значит трафик идёт мимо прокси */
    result.leaking = Boolean(real && real === result.ip);
  }
  return result;
});

ipcMain.handle('proxies:myip', () => proxyCheck.ownIp());

ipcMain.handle('proxies:delete', (_e, id) => {
  storage.deleteProxy(id);
  return true;
});

ipcMain.handle('app:info', () => ({
  version: app.getVersion(),
  dataPath: dataRoot(),
  platform: process.platform,
}));

ipcMain.handle('app:openData', () => shell.openPath(dataRoot()));

/*
 * Интерфейс отдаём через собственный протокол mba://, а не открытием файла.
 * Причина: современная сборка использует модули, а из файла напрямую
 * браузер их блокирует правилами безопасности — окно остаётся чёрным.
 */
protocol.registerSchemesAsPrivileged([
  { scheme: 'mba', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } },
]);

const registerAppProtocol = () => {
  protocol.handle('mba', (request) => {
    const root = path.join(__dirname, 'app');
    const { pathname } = new URL(request.url);
    const relative = decodeURIComponent(pathname).replace(/^\/+/, '');
    const target = path.join(root, relative);

    if (!target.startsWith(root)) {
      return new Response('Доступ запрещён', { status: 403 });
    }

    /* Любой адрес, кроме реального файла, отдаём как главную страницу:
       навигацией внутри приложения занимается сам интерфейс */
    const isFile = relative && fs.existsSync(target) && fs.statSync(target).isFile();
    const file = isFile ? target : path.join(root, 'index.html');
    return net.fetch(pathToFileURL(file).toString());
  });
};

app.whenReady().then(() => {
  registerAppProtocol();
  storage = new Storage(dataRoot());
  buildMenu();
  createWindow();
  /* Проверяем обновления через 6 секунд после запуска и далее раз в 4 часа */
  setTimeout(() => runUpdateCheck({ silent: true }), 6000);
  setInterval(() => runUpdateCheck({ silent: true }), 4 * 60 * 60 * 1000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', async (event) => {
  if (launcher.runningIds().length) {
    event.preventDefault();
    await launcher.stopAll();
    app.exit(0);
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
