const path = require('path');
const { app, BrowserWindow, Menu, ipcMain, shell, dialog } = require('electron');
const { Storage } = require('./core/storage');
const launcher = require('./core/launcher');

let mainWindow = null;
let storage = null;

const dataRoot = () => app.getPath('userData');

const send = (channel, payload) => {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
};

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: '#0D0B08',
    show: false,
    autoHideMenuBar: process.platform !== 'darwin',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'app', 'index.html'));
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.on('closed', () => { mainWindow = null; });
};

const buildMenu = () => {
  const template = [
    ...(process.platform === 'darwin'
      ? [{
          label: 'MBA',
          submenu: [
            { role: 'about', label: 'О программе MBA' },
            { type: 'separator' },
            { role: 'hide', label: 'Скрыть MBA' },
            { role: 'quit', label: 'Выйти' },
          ],
        }]
      : []),
    {
      label: 'Файл',
      submenu: [
        {
          label: 'Папка с данными профилей',
          click: () => shell.openPath(dataRoot()),
        },
        { role: 'reload', label: 'Обновить' },
        { type: 'separator' },
        { role: 'quit', label: 'Выход' },
      ],
    },
    {
      label: 'Правка',
      submenu: [
        { role: 'undo', label: 'Отменить' },
        { role: 'redo', label: 'Повторить' },
        { type: 'separator' },
        { role: 'cut', label: 'Вырезать' },
        { role: 'copy', label: 'Копировать' },
        { role: 'paste', label: 'Вставить' },
        { role: 'selectAll', label: 'Выделить всё' },
      ],
    },
    {
      label: 'Вид',
      submenu: [
        { role: 'zoomIn', label: 'Увеличить' },
        { role: 'zoomOut', label: 'Уменьшить' },
        { role: 'resetZoom', label: 'Обычный размер' },
        { type: 'separator' },
        { role: 'toggleDevTools', label: 'Инструменты разработчика' },
        { role: 'togglefullscreen', label: 'Во весь экран' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
};

ipcMain.handle('profiles:list', () => ({
  profiles: storage.listProfiles(),
  running: launcher.runningIds(),
}));

ipcMain.handle('profiles:save', (_e, profile) => storage.saveProfile(profile));
ipcMain.handle('profiles:delete', async (_e, id) => {
  await launcher.stopProfile(id);
  storage.deleteProfile(id);
  return true;
});

ipcMain.handle('profiles:start', async (_e, profile) => {
  try {
    const result = await launcher.launchProfile(profile, dataRoot(), (id) => {
      send('profile:stopped', id);
    });
    send('profile:started', profile.id);
    return { ok: true, ...result };
  } catch (error) {
    return { ok: false, error: String((error && error.message) || error) };
  }
});

ipcMain.handle('profiles:stop', async (_e, id) => {
  const stopped = await launcher.stopProfile(id);
  send('profile:stopped', id);
  return { ok: stopped };
});

ipcMain.handle('proxies:list', () => storage.listProxies());
ipcMain.handle('proxies:save', (_e, proxy) => storage.saveProxy(proxy));
ipcMain.handle('proxies:delete', (_e, id) => {
  storage.deleteProxy(id);
  return true;
});

ipcMain.handle('app:info', () => ({
  version: app.getVersion(),
  dataPath: dataRoot(),
  platform: process.platform,
}));

ipcMain.handle('app:openData', () => shell.openPath(dataRoot()));

app.whenReady().then(() => {
  storage = new Storage(dataRoot());
  buildMenu();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', async (event) => {
  if (launcher.runningIds().length) {
    event.preventDefault();
    await launcher.stopAll();
    app.exit(0);
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
